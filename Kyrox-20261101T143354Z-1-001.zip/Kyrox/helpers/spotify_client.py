"""
helpers/spotify_client.py
=========================
Spotify metadata helper for rich Now Playing displays.

This module extracts Spotify metadata from Lavalink track objects
(using LavaSrc plugin data) instead of requiring direct Spotify API
credentials. LavaSrc handles all Spotify resolution on the Lavalink
server side and includes artwork, album names, and other metadata
in the track's extra/plugin_info fields.

No Spotify API credentials required!
"""

from __future__ import annotations

import logging
import re
from typing import Optional, Any

log = logging.getLogger("music.spotify")

SPOTIFY_URL_RE = re.compile(
    r"https?://open\.spotify\.com/(?P<type>track|album|playlist)/(?P<id>[a-zA-Z0-9]+)"
)


# ─────────────────────────────────────────────────────────────────────────────
# Initialization (no-op for backward compatibility)
# ─────────────────────────────────────────────────────────────────────────────

def init_spotify(client_id: str = None, client_secret: str = None) -> bool:
    """
    No-op for backward compatibility.
    
    Spotify metadata is now handled entirely by Lavalink's LavaSrc plugin.
    No Spotify API credentials are needed.
    """
    log.info("Spotify metadata handled by Lavalink (LavaSrc) — no credentials needed.")
    return True


# ─────────────────────────────────────────────────────────────────────────────
# URL Utilities
# ─────────────────────────────────────────────────────────────────────────────

def is_spotify_url(url: str) -> bool:
    """Check if a URL is a Spotify URL."""
    return bool(SPOTIFY_URL_RE.match(url))


def get_spotify_id(url: str) -> Optional[str]:
    """Extract Spotify ID from URL."""
    m = SPOTIFY_URL_RE.match(url)
    return m.group("id") if m else None


def get_spotify_type(url: str) -> Optional[str]:
    """Extract Spotify resource type (track/album/playlist) from URL."""
    m = SPOTIFY_URL_RE.match(url)
    return m.group("type") if m else None


# ─────────────────────────────────────────────────────────────────────────────
# Track Metadata Extraction from Lavalink Objects
# ─────────────────────────────────────────────────────────────────────────────

def extract_artwork_from_track(track: Any) -> str:
    """
    Extract artwork URL from a Lavalink track object.
    LavaSrc includes artwork in various locations depending on version.
    """
    if not track:
        return ""

    artwork = None

    # Direct attribute (newer LavaSrc versions)
    if hasattr(track, "artwork_url") and track.artwork_url:
        artwork = track.artwork_url

    # Plugin info dict (most common location)
    if not artwork and hasattr(track, "plugin_info") and isinstance(track.plugin_info, dict):
        artwork = (
            track.plugin_info.get("artworkUrl") or
            track.plugin_info.get("artwork_url") or
            track.plugin_info.get("image")
        )

    # Extra dict
    if not artwork and hasattr(track, "extra") and isinstance(track.extra, dict):
        artwork = (
            track.extra.get("artworkUrl") or
            track.extra.get("artwork_url") or
            track.extra.get("image")
        )

    # Info dict (some versions)
    if not artwork and hasattr(track, "info") and isinstance(track.info, dict):
        artwork = track.info.get("artworkUrl") or track.info.get("artwork_url")

    # YouTube fallback for non-Spotify tracks
    if not artwork:
        uri = getattr(track, "uri", "") or ""
        identifier = getattr(track, "identifier", "") or ""
        if "youtube.com" in uri or "youtu.be" in uri:
            if identifier:
                artwork = f"https://img.youtube.com/vi/{identifier}/maxresdefault.jpg"

    return artwork or ""


def extract_album_from_track(track: Any) -> str:
    """Extract album name from Lavalink track object."""
    if not track:
        return ""

    # Plugin info dict
    if hasattr(track, "plugin_info") and isinstance(track.plugin_info, dict):
        album = track.plugin_info.get("albumName") or track.plugin_info.get("album_name")
        if album:
            return album

    # Extra dict
    if hasattr(track, "extra") and isinstance(track.extra, dict):
        album = (
            track.extra.get("albumName") or
            track.extra.get("album_name") or
            track.extra.get("album")
        )
        if album:
            return album

    # Info dict
    if hasattr(track, "info") and isinstance(track.info, dict):
        album = track.info.get("albumName") or track.info.get("album_name")
        if album:
            return album

    return ""


def extract_artist_image_from_track(track: Any) -> str:
    """Extract artist image URL from Lavalink track object."""
    if not track:
        return ""

    if hasattr(track, "plugin_info") and isinstance(track.plugin_info, dict):
        return (
            track.plugin_info.get("artistImageUrl") or
            track.plugin_info.get("artist_image_url") or
            ""
        )

    if hasattr(track, "extra") and isinstance(track.extra, dict):
        return (
            track.extra.get("artistImageUrl") or
            track.extra.get("artist_image_url") or
            ""
        )

    return ""


def extract_isrc_from_track(track: Any) -> str:
    """Extract ISRC (International Standard Recording Code) if available."""
    if not track:
        return ""

    if hasattr(track, "plugin_info") and isinstance(track.plugin_info, dict):
        return track.plugin_info.get("isrc") or ""

    if hasattr(track, "extra") and isinstance(track.extra, dict):
        return track.extra.get("isrc") or ""

    return ""


def get_track_info_from_lavalink(track: Any) -> Optional[dict]:
    """
    Extract all available metadata from a Lavalink track object.
    
    Returns dict with keys:
        - title, artist, album, artwork_url, artist_image_url
        - duration_ms, uri, source_name, identifier, isrc
    """
    if not track:
        return None

    return {
        "title": getattr(track, "title", None) or "",
        "artist": getattr(track, "author", None) or "",
        "album": extract_album_from_track(track),
        "artwork_url": extract_artwork_from_track(track),
        "artist_image_url": extract_artist_image_from_track(track),
        "duration_ms": getattr(track, "duration", 0) or 0,
        "uri": getattr(track, "uri", None) or "",
        "source_name": getattr(track, "source_name", None) or "",
        "identifier": getattr(track, "identifier", None) or "",
        "isrc": extract_isrc_from_track(track),
    }


def is_spotify_track(track: Any) -> bool:
    """Check if a track was resolved from Spotify."""
    if not track:
        return False

    source = getattr(track, "source_name", "") or ""
    uri = getattr(track, "uri", "") or ""

    return "spotify" in source.lower() or "open.spotify.com" in uri


# ─────────────────────────────────────────────────────────────────────────────
# Legacy Compatibility (deprecated — do not use in new code)
# ─────────────────────────────────────────────────────────────────────────────

def get_track_info(url: str) -> Optional[dict]:
    """
    Legacy function — returns None.
    
    Use get_track_info_from_lavalink(track) instead to get metadata
    directly from Lavalink track objects.
    """
    log.debug("get_track_info(url) is deprecated — use get_track_info_from_lavalink(track)")
    return None


def get_playlist_tracks(url: str) -> list:
    """
    Legacy function — returns empty list.
    
    Lavalink handles playlist loading directly via LavaSrc.
    """
    log.debug("get_playlist_tracks(url) is deprecated — Lavalink handles playlists directly")
    return []


def get_artwork_url(url: str) -> str:
    """
    Legacy function — returns empty string.
    
    Use extract_artwork_from_track(track) instead.
    """
    log.debug("get_artwork_url(url) is deprecated — use extract_artwork_from_track(track)")
    return ""