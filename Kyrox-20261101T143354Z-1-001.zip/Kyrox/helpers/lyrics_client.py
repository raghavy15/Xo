"""
helpers/lyrics_client.py
========================
Robust lyrics fetching with multiple fallback sources.

Sources tried (in order):
  1. Lavalink lyrics plugin (LavaLyrics) — fastest if available
  2. LRCLIB.net API (exact match)
  3. LRCLIB.net API (search with query variations)
  4. Lyrist API
  5. Genius API

Features:
  - Multiple query variations for better matching
  - Concurrent API requests
  - Intelligent fallback chain
  - Synced lyrics support
  - Clean text parsing
"""

from __future__ import annotations

import logging
import aiohttp
import re
import asyncio
import urllib.parse
from typing import Optional, Any

log = logging.getLogger("music.lyrics")


# ─────────────────────────────────────────────────────────────────────────────
# Track Name Parsing
# ─────────────────────────────────────────────────────────────────────────────

def parse_track(title: str, author: str) -> dict[str, str]:
    """
    Parse track title and author into clean song name and artist name
    optimized for lyrics search.
    """
    if not title:
        return {"songName": "", "artistName": ""}

    song_name = title.strip()
    artist_name = (author or "").strip()

    # Remove common suffixes like (Official Video), [Lyrics], etc.
    song_name = re.sub(
        r"\s*[\(\[]\s*(official|lyrics|video|audio|hd|hq|4k|8k|remastered|remaster|"
        r"extended|clean|explicit|radio\s*edit|album\s*version|music\s*video|"
        r"mv|clip|official\s*music\s*video|visualizer)\s*[\)\]]\s*",
        " ",
        song_name,
        flags=re.IGNORECASE,
    )

    # Handle "Artist - Song" format in title
    dash_split = re.split(r"\s*[-–—]\s*", song_name, maxsplit=1)
    if len(dash_split) >= 2:
        potential_artist = dash_split[0].strip()
        potential_song = dash_split[1].strip()

        # Only swap if first part looks like an artist (shorter, no song-related words)
        if (
            len(potential_artist) < len(potential_song)
            and not re.search(r"\b(lyrics|song|track|feat)\b", potential_artist, re.IGNORECASE)
        ):
            if not artist_name or artist_name.lower() in potential_artist.lower():
                artist_name = potential_artist
                song_name = potential_song

    # Remove featured artists from song name for cleaner search
    feat_match = re.split(r"\s*[\(\[]?\s*(?:ft\.?|feat\.?|featuring)\s+", song_name, flags=re.IGNORECASE)
    if len(feat_match) >= 2:
        song_name = feat_match[0].strip()

    # Clean featured artists from artist name too
    artist_name = re.split(
        r"\s*[\(\[]?\s*(?:ft\.?|feat\.?|featuring)\s+", artist_name, flags=re.IGNORECASE
    )[0].strip()

    # Remove label/channel names from artist
    label_pattern = re.compile(
        r"\b(universal|sony|warner|emi|atlantic|republic|zee\s*music|t-series|saregama|"
        r"venus|tips|yrf|dharma|music\s*india|records|entertainment|official|channel|"
        r"vevo|topic)\b",
        re.IGNORECASE,
    )
    artist_name = label_pattern.sub("", artist_name).strip()

    # Final cleanup: normalize whitespace and remove trailing punctuation
    song_name = re.sub(r"\s+", " ", song_name).strip().rstrip(".,;:-")
    artist_name = re.sub(r"\s+", " ", artist_name).strip().rstrip(".,;:-")

    return {"songName": song_name, "artistName": artist_name}


def build_search_queries(title: str, author: str) -> list[str]:
    """
    Build multiple query variations for better search results.
    Returns deduplicated list preserving priority order.
    """
    parsed = parse_track(title, author)
    song = parsed["songName"]
    artist = parsed["artistName"]

    queries = []

    # Primary: "Artist Song" (best for most APIs)
    if artist and song:
        queries.append(f"{artist} {song}")

    # Secondary: Just song name (useful if artist is mislabeled)
    if song:
        queries.append(song)

    # Tertiary: Original unparsed combo
    if title and author:
        original = f"{author} {title}"
        if original.lower() not in [q.lower() for q in queries]:
            queries.append(original)

    # Deduplicate while preserving order
    seen: set[str] = set()
    unique_queries: list[str] = []
    for q in queries:
        q_clean = q.lower().strip()
        if q_clean and q_clean not in seen:
            seen.add(q_clean)
            unique_queries.append(q)

    return unique_queries


# ─────────────────────────────────────────────────────────────────────────────
# Lavalink Lyrics Source
# ─────────────────────────────────────────────────────────────────────────────

async def fetch_lyrics_from_lavalink(node: Any, current_track: Any) -> Optional[dict[str, Any]]:
    """
    Fetch lyrics from Lavalink's LavaLyrics plugin.
    Supports direct track lookup by encoded track or video ID.
    """
    if not node:
        return None

    # Build base URL
    scheme = "https" if getattr(node, "_ssl", False) else "http"
    host = getattr(node, "_host", "localhost")
    port = getattr(node, "_port", 2333)
    base = getattr(node, "http_uri", None) or f"{scheme}://{host}:{port}"
    password = getattr(node, "password", None) or getattr(node, "_password", "")
    headers = {"Authorization": password}

    timeout = aiohttp.ClientTimeout(total=5)

    async with aiohttp.ClientSession(timeout=timeout, trust_env=True) as session:
        if current_track:
            # Method 1: Direct lookup by encoded track (Spotify tracks)
            encoded = getattr(current_track, "track", None) or getattr(current_track, "encoded", None)
            if encoded:
                try:
                    url = f"{base}/v4/lyrics/{encoded}"
                    async with session.get(url, headers=headers) as resp:
                        if resp.status == 200:
                            data = await resp.json()
                            text = data.get("text") or data.get("lyrics") or ""
                            if text.strip():
                                return {
                                    "title": getattr(current_track, "title", "Unknown"),
                                    "artist": getattr(current_track, "author", "Unknown"),
                                    "lyrics": text.strip(),
                                    "synced": data.get("synced") or None,
                                    "source": "Lavalink (Spotify)",
                                }
                except Exception as e:
                    log.debug("Lavalink direct track lyrics failed: %s", e)

            # Method 2: YouTube tracks by video ID
            identifier = getattr(current_track, "identifier", None)
            source_name = getattr(current_track, "source_name", "") or ""
            if identifier and "youtube" in source_name.lower():
                try:
                    url = f"{base}/v4/lyrics/{identifier}"
                    async with session.get(url, headers=headers) as resp:
                        if resp.status == 200:
                            data = await resp.json()
                            lines = data.get("lines", [])
                            if lines:
                                plain_lines = [line.get("line", "") for line in lines if line.get("line")]
                                plain_lyrics = "\n".join(plain_lines)

                                if plain_lyrics.strip():
                                    synced_lines = []
                                    for line in lines:
                                        start_ms = (
                                            line.get("start", 0)
                                            or line.get("range", {}).get("start", 0)
                                        )
                                        seconds = start_ms / 1000
                                        minutes = int(seconds // 60)
                                        secs = seconds % 60
                                        text = line.get("line", "")
                                        if text:
                                            synced_lines.append(f"[{minutes:02d}:{secs:05.2f}] {text}")

                                    return {
                                        "title": getattr(current_track, "title", "Unknown"),
                                        "artist": getattr(current_track, "author", "Unknown"),
                                        "lyrics": plain_lyrics.strip(),
                                        "synced": "\n".join(synced_lines) if synced_lines else None,
                                        "source": "Lavalink (YouTube)",
                                    }
                except Exception as e:
                    log.debug("Lavalink YouTube lyrics failed: %s", e)

    return None


# ─────────────────────────────────────────────────────────────────────────────
# LRCLIB Source
# ─────────────────────────────────────────────────────────────────────────────

async def fetch_lyrics_from_lrclib(
    queries: list[str], track_name: str, artist_name: str
) -> Optional[dict[str, Any]]:
    """
    Fetch lyrics from LRCLIB.net API.
    Tries exact match first, then search with query variations.
    """
    timeout = aiohttp.ClientTimeout(total=8)

    async with aiohttp.ClientSession(timeout=timeout, trust_env=True) as session:
        # Attempt 1: Exact match
        if track_name:
            try:
                params: dict[str, str] = {}
                if track_name:
                    params["track_name"] = track_name
                if artist_name:
                    params["artist_name"] = artist_name

                async with session.get("https://lrclib.net/api/get", params=params) as resp:
                    if resp.status == 200:
                        data = await resp.json()
                        result = _parse_lrclib_response(data, track_name, artist_name)
                        if result:
                            return result
            except Exception as e:
                log.debug("LRCLIB exact match failed: %s", e)

        # Attempt 2: Search with each query variation
        for query in queries:
            try:
                async with session.get(
                    "https://lrclib.net/api/search", params={"q": query}
                ) as resp:
                    if resp.status == 200:
                        results = await resp.json()
                        if results and isinstance(results, list):
                            # Prefer results with synced lyrics
                            best = next((r for r in results if r.get("syncedLyrics")), results[0])
                            result = _parse_lrclib_response(best, track_name, artist_name)
                            if result:
                                return result
            except Exception as e:
                log.debug("LRCLIB search for '%s' failed: %s", query, e)
                continue

    return None


def _parse_lrclib_response(
    data: dict, fallback_title: str, fallback_artist: str
) -> Optional[dict[str, Any]]:
    """Parse a single LRCLIB API response into standard lyrics dict."""
    if not data:
        return None

    plain = data.get("plainLyrics", "") or ""
    synced = data.get("syncedLyrics", "") or ""

    if not plain and not synced:
        return None

    lyrics_body = plain if plain else re.sub(r"\[.*?\]", "", synced)
    lyrics_body = lyrics_body.strip()

    if not lyrics_body or len(lyrics_body) < 30:
        return None

    return {
        "title": data.get("trackName") or fallback_title,
        "artist": data.get("artistName") or fallback_artist,
        "lyrics": lyrics_body,
        "synced": synced or None,
        "image": None,
        "source": "LRCLIB",
    }


# ─────────────────────────────────────────────────────────────────────────────
# Lyrist Source
# ─────────────────────────────────────────────────────────────────────────────

async def fetch_lyrics_from_lyrist(queries: list[str]) -> Optional[dict[str, Any]]:
    """Fetch lyrics from Lyrist API."""
    timeout = aiohttp.ClientTimeout(total=8)

    async with aiohttp.ClientSession(timeout=timeout, trust_env=True) as session:
        for query in queries:
            try:
                encoded_query = urllib.parse.quote(query)
                url = f"https://lyrist.vercel.app/api/{encoded_query}"

                async with session.get(url) as resp:
                    if resp.status == 200:
                        data = await resp.json()
                        lyrics = data.get("lyrics", "")

                        # Check for actual lyrics content
                        if lyrics and isinstance(lyrics, str):
                            lyrics = lyrics.strip()
                            # Filter out error messages
                            error_patterns = [
                                "lyrics not found",
                                "sorry, we don't have lyrics",
                                "we couldn't find",
                                "no lyrics available",
                                "instrumental",
                            ]
                            if any(pattern in lyrics.lower() for pattern in error_patterns):
                                continue

                            if len(lyrics) > 30:
                                return {
                                    "title": data.get("title", ""),
                                    "artist": data.get("artist", ""),
                                    "lyrics": lyrics,
                                    "image": data.get("image") or None,
                                    "synced": None,
                                    "source": "Lyrist",
                                }
            except Exception as e:
                log.debug("Lyrist search for '%s' failed: %s", query, e)
                continue

    return None


# ─────────────────────────────────────────────────────────────────────────────
# Genius Source
# ─────────────────────────────────────────────────────────────────────────────

async def fetch_lyrics_from_genius(queries: list[str]) -> Optional[dict[str, Any]]:
    """Fetch lyrics from Genius via public API."""
    timeout = aiohttp.ClientTimeout(total=8)

    async with aiohttp.ClientSession(timeout=timeout, trust_env=True) as session:
        for query in queries:
            try:
                encoded_query = urllib.parse.quote(query)

                # Try multiple Genius API endpoints
                endpoints = [
                    f"https://genius-lyrics-api.vercel.app/api/search/{encoded_query}",
                    f"https://genius-song-lyrics1.p.rapidapi.com/search/?q={encoded_query}",
                ]

                for url in endpoints:
                    try:
                        headers = {}
                        if "rapidapi" in url:
                            headers["X-RapidAPI-Key"] = "free"

                        async with session.get(url, headers=headers) as resp:
                            if resp.status == 200:
                                data = await resp.json()
                                lyrics = _extract_genius_lyrics(data)

                                if lyrics:
                                    # Clean up Genius formatting artifacts
                                    lyrics = re.sub(r"\[.*?\]\s*", "", lyrics)
                                    lyrics = re.sub(r"\n{3,}", "\n\n", lyrics)
                                    lyrics = lyrics.strip()

                                    if len(lyrics) > 30:
                                        return {
                                            "title": data.get("title", ""),
                                            "artist": data.get("artist", ""),
                                            "lyrics": lyrics,
                                            "image": None,
                                            "synced": None,
                                            "source": "Genius",
                                        }
                    except Exception:
                        continue

            except Exception as e:
                log.debug("Genius search for '%s' failed: %s", query, e)
                continue

    return None


def _extract_genius_lyrics(data: Any) -> Optional[str]:
    """Extract lyrics from various Genius API response formats."""
    if not data or not isinstance(data, dict):
        return None

    # Format 1: Direct lyrics field
    if data.get("lyrics"):
        return data["lyrics"]

    # Format 2: Nested in hits
    hits = data.get("hits", [])
    if hits and isinstance(hits, list):
        for hit in hits:
            result = hit.get("result", {})
            if result.get("lyrics"):
                return result["lyrics"]
            # Some endpoints have URL to fetch lyrics
            if result.get("url"):
                return None  # Would need separate fetch

    return None


# ─────────────────────────────────────────────────────────────────────────────
# Main Lyrics Fetch Function
# ─────────────────────────────────────────────────────────────────────────────

async def fetch_lyrics(
    track_name: Optional[str],
    artist_name: Optional[str],
    query: str,
    node: Optional[Any] = None,
    current_track: Optional[Any] = None,
) -> Optional[dict[str, Any]]:
    """
    Main lyrics fetch function with multiple fallback sources.

    Args:
        track_name: Clean track name (or extracted from current_track)
        artist_name: Clean artist name (or extracted from current_track)
        query: Original search query
        node: Lavalink node for plugin-based lyrics
        current_track: Lavalink AudioTrack object

    Returns:
        Dict with keys: title, artist, lyrics, synced (optional), image (optional), source
        or None if no lyrics found.
    """
    # Extract info from track object if not provided
    title = track_name or getattr(current_track, "title", "") or ""
    author = artist_name or getattr(current_track, "author", "") or ""

    # Build multiple query variations for better matching
    queries = build_search_queries(title, author)

    # Fallback to raw query if nothing extracted
    if not queries and query:
        queries = [query]

    if not queries:
        log.warning("No valid queries for lyrics search")
        return None

    log.debug("Lyrics search queries: %s", queries)

    # ── Source 1: Lavalink Plugin (fastest if available) ──
    if node:
        try:
            result = await fetch_lyrics_from_lavalink(node, current_track)
            if result and result.get("lyrics") and len(result["lyrics"]) > 30:
                log.debug("Got lyrics from Lavalink: %s", result.get("source"))
                return result
        except Exception as e:
            log.debug("Lavalink lyrics failed: %s", e)

    # ── Sources 2-4: External APIs (concurrent) ──
    parsed = parse_track(title, author)
    clean_song = parsed["songName"]
    clean_artist = parsed["artistName"]

    async def try_lrclib() -> Optional[dict]:
        return await fetch_lyrics_from_lrclib(queries, clean_song, clean_artist)

    async def try_lyrist() -> Optional[dict]:
        return await fetch_lyrics_from_lyrist(queries)

    async def try_genius() -> Optional[dict]:
        return await fetch_lyrics_from_genius(queries)

    # Run all sources concurrently for speed
    results = await asyncio.gather(
        try_lrclib(),
        try_lyrist(),
        try_genius(),
        return_exceptions=True,
    )

    # Return first successful result with valid content
    for res in results:
        if res and not isinstance(res, Exception):
            lyrics_text = res.get("lyrics", "")
            if lyrics_text and len(lyrics_text) > 30:
                log.debug("Got lyrics from %s", res.get("source"))
                return res

    # ── Final Fallback: Sequential retry with first query only ──
    # Sometimes concurrent requests fail but sequential works
    log.debug("Concurrent fetch failed, trying sequential fallback...")
    for q in queries[:2]:  # Only try first 2 queries
        result = await fetch_lyrics_from_lrclib([q], clean_song, clean_artist)
        if result and result.get("lyrics") and len(result["lyrics"]) > 30:
            return result

        result = await fetch_lyrics_from_lyrist([q])
        if result and result.get("lyrics") and len(result["lyrics"]) > 30:
            return result

    log.debug("No lyrics found from any source")
    return None


# ─────────────────────────────────────────────────────────────────────────────
# Synced Lyrics Parser
# ─────────────────────────────────────────────────────────────────────────────

def parse_synced_lyrics(synced_text: str) -> list[dict[str, Any]]:
    """
    Parse synced lyrics text into a list of {time, text} dicts.

    Supports formats:
        [01:23.45] Lyrics line
        [1:23.456] Lyrics line
        [01:23] Lyrics line
    """
    if not synced_text:
        return []

    lines: list[dict[str, Any]] = []

    for line in synced_text.split("\n"):
        line = line.strip()
        if not line:
            continue

        # Match [MM:SS.xx] or [M:SS.xxx] or [MM:SS]
        match = re.match(r"^\[(\d+):(\d+(?:\.\d+)?)\]\s*(.*)$", line)
        if not match:
            continue

        minutes = int(match.group(1))
        seconds = float(match.group(2))
        text = match.group(3).strip() or "\u200b"  # Zero-width space for empty lines

        lines.append(
            {
                "time": int((minutes * 60 + seconds) * 1000),
                "text": text,
            }
        )

    return lines