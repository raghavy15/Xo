def add_to_history(guild_id: str, requester_id: str, title: str, uri: str, author: str):
    pass
