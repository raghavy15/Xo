"""
helpers/lavalink_client.py
==========================
Lavalink.py 5.9.x connection manager & event wiring.

Call ``setup_lavalink(bot)`` from your bot's ``on_ready`` to initialise
the lavalink.Client instance and add the Lavalink node.

Provides:
  - LavalinkVoiceClient  — discord.VoiceProtocol adapter
  - GuildMusicState      — per-guild extras (NP message, autoplay, etc.)
  - Event hook           — track-end queue advance, autoplay, VC presence
  - Utility helpers      — format_ms, progress_bar
"""

from __future__ import annotations

import asyncio
import logging
import random
from typing import TYPE_CHECKING, Optional

import discord
import lavalink
from lavalink.events import (
    TrackStartEvent,
    TrackEndEvent,
    TrackExceptionEvent,
    QueueEndEvent,
    NodeConnectedEvent,
    NodeReadyEvent,
)
from lavalink.server import LoadType

if TYPE_CHECKING:
    from discord.ext.commands import Bot

import aiohttp

log = logging.getLogger("music.lavalink")


class WebhookLogHandler(logging.Handler):
    def __init__(self, webhook_url: str):
        super().__init__()
        self.webhook_url = webhook_url

    def emit(self, record):
        try:
            log_entry = self.format(record)
            loop = asyncio.get_event_loop()
            if loop.is_running():
                loop.create_task(self._send(log_entry))
        except Exception:
            pass

    async def _send(self, log_entry):
        try:
            if len(log_entry) > 1980:
                log_entry = log_entry[:1970] + "\n... [TRUNCATED]"
            content = f"```\n{log_entry}\n```"
            async with aiohttp.ClientSession() as session:
                async with session.post(self.webhook_url, json={"content": content}) as resp:
                    pass
        except Exception:
            pass


# ─────────────────────────────────────────────────────────────────────────────
# NodeLink / Lavalink compatibility monkey patches
# ─────────────────────────────────────────────────────────────────────────────
import lavalink.stats
import lavalink.transport
import lavalink.server
from lavalink.events import TrackStartEvent, TrackEndEvent, TrackExceptionEvent, TrackStuckEvent, WebSocketClosedEvent
from lavalink.server import Severity, EndReason

def patched_stats_init(self, node, data):
    self._node = node
    self.is_fake: bool = data.get('isFake', False)
    self.uptime: int = data.get('uptime', 0)
    self.players: int = data.get('players', 0)
    self.playing_players: int = data.get('playingPlayers', 0)
    
    memory = data.get('memory') or {}
    self.memory_free: int = memory.get('free', 0)
    self.memory_used: int = memory.get('used', 0)
    self.memory_allocated: int = memory.get('allocated', 0)
    self.memory_reservable: int = memory.get('reservable', 0)
    
    cpu = data.get('cpu') or {}
    self.cpu_cores: int = cpu.get('cores', 0)
    self.system_load: float = cpu.get('systemLoad', 0.0)
    self.lavalink_load: float = cpu.get('lavalinkLoad', 0.0)
    
    frame_stats = data.get('frameStats') or {}
    self.frames_sent: int = frame_stats.get('sent', 0)
    self.frames_nulled: int = frame_stats.get('nulled', 0)
    self.frames_deficit: int = frame_stats.get('deficit', 0)
    self.penalty: lavalink.stats.Penalty = lavalink.stats.Penalty(self)

lavalink.stats.Stats.__init__ = patched_stats_init


async def patched_handle_event(self, data: dict):
    guild_id = data.get('guildId')
    if not guild_id:
        event_type = data.get('type')
        log.debug('[Node:%s] Received event type %s with missing guildId: %s', self._node.name, event_type, data)
        return

    player = self.client.player_manager.get(int(guild_id))
    event_type = data.get('type')
    if not player:
        if event_type not in ('TrackEndEvent', 'WebSocketClosedEvent'):
            log.warning('[Node:%s] Received event type %s for non-existent player! GuildId: %s', self._node.name, event_type, guild_id)
        return

    event = None
    if event_type == 'TrackStartEvent':
        if player._next is not None:
            player.current = player._next
            player._next = None
        track = player.current
        if track is None:
            track_data = data.get('track') or {}
            track = lavalink.server.AudioTrack(track_data, 0)
            player.current = track
        event = TrackStartEvent(player, track)
        if hasattr(player, '_internal_pause'):
            player._internal_pause = False
            
    elif event_type == 'TrackEndEvent':
        end_reason = EndReason.from_str(data['reason'])
        event = TrackEndEvent(player, player.current or player._next, end_reason)
        
    elif event_type == 'TrackExceptionEvent':
        exception = data.get('exception') or {}
        message = exception.get('message', 'Unknown error')
        severity = Severity.from_str(exception.get('severity', 'COMMON'))
        cause = exception.get('cause', 'unknown')
        
        track = player.current or player._next
        if track is None:
            track_data = data.get('track') or {}
            track = lavalink.server.AudioTrack(track_data, 0)
        event = TrackExceptionEvent(player, track, message, severity, cause)
        
    elif event_type == 'TrackStuckEvent':
        track = player.current or player._next
        if track is None:
            track_data = data.get('track') or {}
            track = lavalink.server.AudioTrack(track_data, 0)
        event = TrackStuckEvent(player, track, data.get('thresholdMs', 0))
        
    elif event_type == 'WebSocketClosedEvent':
        event = WebSocketClosedEvent(player, data.get('code', 1000), data.get('reason', ''), data.get('byRemote', False))
        
    else:
        if not self.client.has_listeners(lavalink.events.IncomingWebSocketMessage):
            log.warning('[Node:%s] Unknown event received of type \'%s\'', self._node.name, event_type)
        return

    self.client._dispatch_event(event)
    if player:
        try:
            await player.handle_event(event)
        except:
            log.exception('Player %d encountered an error whilst handling event %s', player.guild_id, type(event).__name__)

lavalink.transport.Transport._handle_event = patched_handle_event


# ─────────────────────────────────────────────────────────────────────────────
# LavalinkVoiceClient  (discord.VoiceProtocol adapter)
# ─────────────────────────────────────────────────────────────────────────────

class LavalinkVoiceClient(discord.VoiceProtocol):
    """
    Bridges discord.py voice gateway events to lavalink.py.
    Use this as the ``cls`` argument in ``channel.connect(cls=...)``.
    """

    def __init__(self, client: discord.Client, channel: discord.abc.Connectable):
        self.client = client
        self.channel = channel
        self.guild_id = channel.guild.id
        self._destroyed = False
        self.voice_ready = asyncio.Event()  # set when VOICE_SERVER_UPDATE is fully forwarded

        self.lavalink: lavalink.Client = client.lavalink  # type: ignore[attr-defined]

    async def on_voice_server_update(self, data):
        log.info(f"[Voice] VOICE_SERVER_UPDATE received for guild {self.guild_id}")
        lavalink_data = {"t": "VOICE_SERVER_UPDATE", "d": data}
        await self.lavalink.voice_update_handler(lavalink_data)
        self.voice_ready.set()
        log.info(f"[Voice] VOICE_SERVER_UPDATE forwarded -- voice_ready SET")

    async def on_voice_state_update(self, data):
        channel_id = data["channel_id"]
        log.info(f"[Voice] VOICE_STATE_UPDATE received, channel_id={channel_id}")

        if not channel_id:
            await self._destroy()
            return

        self.channel = self.client.get_channel(int(channel_id))
        lavalink_data = {"t": "VOICE_STATE_UPDATE", "d": data}
        await self.lavalink.voice_update_handler(lavalink_data)

    async def connect(
        self, *, timeout: float, reconnect: bool,
        self_deaf: bool = False, self_mute: bool = False
    ) -> None:
        self.lavalink.player_manager.create(guild_id=self.channel.guild.id)
        await self.channel.guild.change_voice_state(
            channel=self.channel, self_mute=self_mute, self_deaf=self_deaf,
        )

    async def disconnect(self, *, force: bool = False) -> None:
        player = self.lavalink.player_manager.get(self.channel.guild.id)

        if not force and player and not player.is_connected:
            return

        await self.channel.guild.change_voice_state(channel=None)

        if player:
            player.channel_id = None

        await self._destroy()

    async def _destroy(self):
        self.cleanup()
        if self._destroyed:
            return
        self._destroyed = True

        try:
            await self.lavalink.player_manager.destroy(self.guild_id)
        except lavalink.errors.ClientError:
            pass


# ─────────────────────────────────────────────────────────────────────────────
# Node setup
# ─────────────────────────────────────────────────────────────────────────────

async def setup_lavalink(bot: Bot) -> None:
    """Initialise lavalink.Client and add the node from config.json."""
    if hasattr(bot, "lavalink"):
        return  # already set up (e.g. cog reload)

    if hasattr(bot, "config"):
        cfg = bot.config.get("lavalink", {})
    else:
        import json
        try:
            with open("config.json", "r", encoding="utf-8") as f:
                cfg = json.load(f).get("lavalink", {})
        except Exception:
            cfg = {}
        
    # Set up Webhook Logger if webhook URL is provided
    webhook_url = cfg.get("webhook")
    if webhook_url:
        handler = WebhookLogHandler(webhook_url)
        formatter = logging.Formatter(
            fmt="[%(asctime)s] [%(levelname)s] %(name)s: %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S"
        )
        handler.setFormatter(formatter)
        
        # Configure our wrapper logger
        log.handlers.clear()
        log.addHandler(handler)
        log.propagate = False
        
        # Configure main lavalink logger
        lavalink_logger = logging.getLogger("lavalink")
        lavalink_logger.handlers.clear()
        lavalink_logger.addHandler(handler)
        lavalink_logger.propagate = False
    else:
        log.propagate = True
        logging.getLogger("lavalink").propagate = True

    from utils import config as bot_config

    host = cfg.get("host", "localhost")
    port = cfg.get("port", 2333)
    password = cfg.get("password", "youshallnotpass")
    
    if hasattr(bot_config, "LAVALINK_URI") and bot_config.LAVALINK_URI:
        uri = bot_config.LAVALINK_URI
        if "://" in uri:
            from urllib.parse import urlparse
            parsed = urlparse(uri)
            host = parsed.hostname or "localhost"
            port = parsed.port or 2333
        elif ":" in uri:
            host, port_str = uri.rsplit(":", 1)
            port = int(port_str)
        else:
            host = uri
            port = 2333
            
    if hasattr(bot_config, "LAVALINK_PASSWORD") and bot_config.LAVALINK_PASSWORD:
        password = bot_config.LAVALINK_PASSWORD
        
    # Enable SSL if port is 443 or ssl/secure is explicitly set to True
    ssl_env = getattr(bot_config, "LAVALINK_SECURE", None)
    if cfg.get("secure") is False or cfg.get("ssl") is False:
        ssl = False
    elif ssl_env is not None:
        ssl = ssl_env
    else:
        ssl = bool(cfg.get("ssl", False) or cfg.get("secure", False) or port == 443)

    client = lavalink.Client(bot.user.id)
    client.add_node(
        host=host,
        port=port,
        password=password,
        region="us",
        name="default-node",
        ssl=ssl,
    )
    bot.lavalink = client
    set_bot_ref(bot)

    # Register global event hook
    client.add_event_hook(_event_hook)

    log.info("Lavalink client created — node %s:%s added (ssl=%s).", host, port, ssl)
    log.info(f"[OK] Lavalink node {host}:{port} added (ssl={ssl}).")


# ─────────────────────────────────────────────────────────────────────────────
# Guild player state  (per-guild extras)
# ─────────────────────────────────────────────────────────────────────────────

class GuildMusicState:
    """Lightweight bag of per-guild music state stored on the bot."""

    __slots__ = (
        "now_playing_msg",
        "autoplay",
        "radio_mode",
        "paused_by_empty",
        "previous_tracks",
        "text_channel_id",
        "twenty_four_seven", # 👈 ADD THIS
    )

    def __init__(self):
        self.now_playing_msg: discord.Message | None = None
        self.autoplay: bool = False
        self.radio_mode: bool = False
        self.paused_by_empty: bool = False
        self.previous_tracks: list[lavalink.AudioTrack] = []
        self.text_channel_id: int | None = None
        self.twenty_four_seven: bool = False # 👈 ADD THIS


# Module-level dict so it persists across cog reloads
_music_states: dict[int, GuildMusicState] = {}


def get_state(guild_id: int) -> GuildMusicState:
    if guild_id not in _music_states:
        _music_states[guild_id] = GuildMusicState()
    return _music_states[guild_id]


def clear_state(guild_id: int) -> None:
    _music_states.pop(guild_id, None)


# ─────────────────────────────────────────────────────────────────────────────
# Global event hook
# ─────────────────────────────────────────────────────────────────────────────

# We'll store a reference to the bot so the event hook can access it.
_bot_ref: Optional[Bot] = None


def set_bot_ref(bot: Bot) -> None:
    global _bot_ref
    _bot_ref = bot


async def _event_hook(event):
    """Dispatched for every lavalink event."""
    if _bot_ref:
        import re
        class_name = type(event).__name__.replace("Event", "")
        event_name = re.sub(r'(?<!^)(?=[A-Z])', '_', class_name).lower()
        _bot_ref.dispatch(f"lavalink_{event_name}", event)

    if isinstance(event, NodeConnectedEvent):
        log.info("Lavalink node connected: %s", event.node.name)

    elif isinstance(event, NodeReadyEvent):
        log.info("Lavalink node ready: %s (session=%s)", event.node.name, event.node.session_id)
        log.info(f"[OK] Lavalink node '{event.node.name}' is ready!")

    elif isinstance(event, TrackStartEvent):
        await _on_track_start(event)

    elif isinstance(event, TrackEndEvent):
        await _on_track_end(event)

    elif isinstance(event, TrackExceptionEvent):
        log.error("Track exception in guild %s: %s", event.player.guild_id, event.message)
        # Try to skip to the next track
        if event.player.queue:
            await event.player.play()

    elif isinstance(event, QueueEndEvent):
        await _on_queue_end(event)


async def _on_track_start(event: TrackStartEvent):
    """Record history when a track starts."""
    player = event.player
    state = get_state(player.guild_id)

    # Record to history
    track = player.current
    if track and _bot_ref:
        try:
            from helpers.playlist_db import add_to_history
            requester = getattr(track, "requester", 0)
            add_to_history(
                str(player.guild_id), str(requester),
                track.title, track.uri or "",
                track.author,
            )
        except Exception:
            pass

    log.info(f"[Lavalink] TrackStart: {track.title if track else 'None'} in guild {player.guild_id}")


async def _on_track_end(event: TrackEndEvent):
    """Push finished track to previous-tracks stack."""
    player = event.player
    state = get_state(player.guild_id)
    track = event.track

    if track:
        state.previous_tracks.append(track)
        if len(state.previous_tracks) > 20:
            state.previous_tracks.pop(0)


async def _on_queue_end(event: QueueEndEvent):
    """Handle autoplay when queue ends, or clean up NP."""
    player = event.player
    state = get_state(player.guild_id)

    log.info(f"[Autoplay Debug] Queue end event received in global client. Autoplay state: {state.autoplay}, Radio mode: {state.radio_mode}")

    # Clean up NP message
    if state.now_playing_msg:
        try:
            await state.now_playing_msg.delete()
        except Exception:
            pass
        state.now_playing_msg = None


# ─────────────────────────────────────────────────────────────────────────────
# Smart VC presence  (pause when alone, resume when someone joins)
# ─────────────────────────────────────────────────────────────────────────────

async def handle_vc_presence(
    bot: Bot,
    member: discord.Member,
    before: discord.VoiceState,
    after: discord.VoiceState,
) -> None:
    """Called from on_voice_state_update in main.py."""
    if member.bot:
        return

    if not hasattr(bot, "lavalink"):
        return

    guild = member.guild
    player = bot.lavalink.player_manager.get(guild.id)
    if player is None or not player.is_connected:
        return

    bot_channel = bot.get_channel(player.channel_id)
    if bot_channel is None:
        return

    state = get_state(guild.id)
    humans = [m for m in bot_channel.members if not m.bot]

    if len(humans) == 0 and player.is_playing and not player.paused:
        await player.set_pause(True)
        state.paused_by_empty = True
        log.info("Auto-paused in guild %s (VC empty).", guild.id)

    elif len(humans) > 0 and state.paused_by_empty and player.paused:
        await player.set_pause(False)
        state.paused_by_empty = False
        log.info("Auto-resumed in guild %s (user rejoined).", guild.id)


# ─────────────────────────────────────────────────────────────────────────────
# Utility helpers
# ─────────────────────────────────────────────────────────────────────────────

def format_ms(ms: int) -> str:
    """Convert milliseconds to m:ss or h:mm:ss."""
    s = ms // 1000
    m, s = divmod(s, 60)
    h, m = divmod(m, 60)
    if h:
        return f"{h}:{m:02d}:{s:02d}"
    return f"{m}:{s:02d}"


def progress_bar(position_ms: int, duration_ms: int, length: int = 14) -> str:
    """Build a text-based progress bar."""
    if duration_ms <= 0:
        return "🔴 LIVE"
    ratio = min(position_ms / duration_ms, 1.0)
    filled = round(ratio * length)
    bar = "━" * filled + "●" + "━" * (length - filled)
    return f"{format_ms(position_ms)} {bar} {format_ms(duration_ms)}"
