from __future__ import annotations

from utils.database import get_collection

BADGE_COLUMNS = frozenset({
    "owner",
    "staff",
    "partner",
    "sponsor",
    "friend",
    "early",
    "vip",
    "bug",
})

async def ensure_badges_table() -> None:
    pass


def _validate_badge(badge: str) -> str:
    key = badge.lower()
    if key not in BADGE_COLUMNS:
        raise ValueError(f"Invalid badge column: {badge}")
    return key


async def add_badge(user_id: int, badge: str) -> bool:
    column = _validate_badge(badge)
    collection = await get_collection("badges")
    
    doc = await collection.find_one({"user_id": user_id})
    if not doc:
        await collection.insert_one({"user_id": user_id, column: 1})
        return True
    
    if doc.get(column, 0) == 0:
        await collection.update_one({"user_id": user_id}, {"$set": {column: 1}})
        return True
        
    return False


async def remove_badge(user_id: int, badge: str) -> bool:
    column = _validate_badge(badge)
    collection = await get_collection("badges")
    
    doc = await collection.find_one({"user_id": user_id})
    if not doc or doc.get(column, 0) != 1:
        return False
        
    await collection.update_one({"user_id": user_id}, {"$set": {column: 0}})
    return True


async def get_user_badges(user_id: int) -> dict[str, int]:
    collection = await get_collection("badges")
    doc = await collection.find_one({"user_id": user_id})
    
    keys = ("owner", "staff", "partner", "sponsor", "friend", "early", "vip", "bug")
    if not doc:
        return {key: 0 for key in keys}
        
    return {key: doc.get(key, 0) for key in keys}