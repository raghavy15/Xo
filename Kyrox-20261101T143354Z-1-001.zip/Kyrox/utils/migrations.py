from __future__ import annotations

import logging

log = logging.getLogger(__name__)

async def run_startup_migrations() -> None:
    # MongoDB collections are created automatically, so no schema creation is needed.
    pass