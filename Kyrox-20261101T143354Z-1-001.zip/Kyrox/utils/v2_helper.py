import discord
from discord.ext import commands


class Test(commands.Cog):
    """
    A cog to demonstrate every Discord Components V2 component.
    Each command sends a LayoutView showcasing that specific component.
    """

    def __init__(self, bot: commands.Bot):
        self.bot = bot

    # ──────────────────────────────────────────────
    # 1. TextDisplay
    # ──────────────────────────────────────────────
    @commands.command(name="textdisplay", aliases=["text"])
    async def text_display(self, ctx: commands.Context):
        """Sends a message using ui.TextDisplay (supports markdown)."""

        class TextView(discord.ui.LayoutView):
            text1 = discord.ui.TextDisplay("# Hello, Components V2! 👋")
            text2 = discord.ui.TextDisplay(
                "This is a **TextDisplay** component.\n"
                "- Supports *markdown*\n"
                "- Supports `code`\n"
                "- Even > blockquotes!\n\n"
                "The 4000-char limit is **shared** across all TextDisplays in the same LayoutView."
            )

        await ctx.send(view=TextView())

    # ──────────────────────────────────────────────
    # 2. ActionRow with Button
    # ──────────────────────────────────────────────
    @commands.command(name="actionrow", aliases=["button"])
    async def action_row(self, ctx: commands.Context):
        """Sends a LayoutView with an ActionRow containing multiple buttons."""

        class ActionRowView(discord.ui.LayoutView):
            header = discord.ui.TextDisplay("## ActionRow Demo 🎛️\nClick any button below:")

            row = discord.ui.ActionRow()

            @row.button(label="Primary", style=discord.ButtonStyle.primary)
            async def primary_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
                await interaction.response.send_message("🔵 Primary clicked!", ephemeral=True)

            @row.button(label="Success", style=discord.ButtonStyle.success)
            async def success_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
                await interaction.response.send_message("🟢 Success clicked!", ephemeral=True)

            @row.button(label="Danger", style=discord.ButtonStyle.danger)
            async def danger_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
                await interaction.response.send_message("🔴 Danger clicked!", ephemeral=True)

            @row.button(label="Secondary", style=discord.ButtonStyle.secondary)
            async def secondary_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
                await interaction.response.send_message("⚫ Secondary clicked!", ephemeral=True)

        await ctx.send(view=ActionRowView())

    # ──────────────────────────────────────────────
    # 3. Section with Thumbnail accessory
    # ──────────────────────────────────────────────
    @commands.command(name="section")
    async def section(self, ctx: commands.Context):
        """Sends a Section with text and a Thumbnail accessory side-by-side."""

        class SectionView(discord.ui.LayoutView):
            header = discord.ui.TextDisplay("## Section Demo 📐")

            sec = discord.ui.Section(
                discord.ui.TextDisplay("**Sections** let you place text alongside an accessory."),
                discord.ui.TextDisplay("The accessory appears on the right side — it can be a Thumbnail or a Button."),
                accessory=discord.ui.Thumbnail(
                    "https://cdn.discordapp.com/embed/avatars/0.png",
                    description="A thumbnail accessory",
                ),
            )

        await ctx.send(view=SectionView())

    # ──────────────────────────────────────────────
    # 4. Thumbnail (inside Section)
    # ──────────────────────────────────────────────
    @commands.command(name="thumbnail")
    async def thumbnail(self, ctx: commands.Context):
        """Sends a Section with a Thumbnail accessory (image on the right)."""

        class ThumbnailView(discord.ui.LayoutView):
            header = discord.ui.TextDisplay("## Thumbnail Demo 🖼️")

            sec = discord.ui.Section(
                discord.ui.TextDisplay(
                    "**`ui.Thumbnail`** is a non-top-level component.\n"
                    "It can only live inside a **Section** as an accessory.\n\n"
                    "The image appears to the right of the text content."
                ),
                accessory=discord.ui.Thumbnail(
                    "https://cdn.discordapp.com/embed/avatars/1.png",
                    description="Example thumbnail image",
                ),
            )

        await ctx.send(view=ThumbnailView())

    # ──────────────────────────────────────────────
    # 5. Separator
    # ──────────────────────────────────────────────
    @commands.command(name="separator", aliases=["sep"])
    async def separator(self, ctx: commands.Context):
        """Sends a LayoutView demonstrating Separator (small, large, with/without divider)."""

        class SeparatorView(discord.ui.LayoutView):
            t1 = discord.ui.TextDisplay("## Separator Demo ➖")
            t2 = discord.ui.TextDisplay("⬆️ Text above a **small** separator (no line)")

            sep1 = discord.ui.Separator(
                spacing=discord.SeparatorSpacing.small,
                visible=False,
            )

            t3 = discord.ui.TextDisplay("⬆️ Text above a **small** separator **with** a visible line")

            sep2 = discord.ui.Separator(
                spacing=discord.SeparatorSpacing.small,
                visible=True,
            )

            t4 = discord.ui.TextDisplay("⬆️ Text above a **large** separator (no line)")

            sep3 = discord.ui.Separator(
                spacing=discord.SeparatorSpacing.large,
                visible=False,
            )

            t5 = discord.ui.TextDisplay("⬆️ Text above a **large** separator **with** a visible line")

            sep4 = discord.ui.Separator(
                spacing=discord.SeparatorSpacing.large,
                visible=True,
            )

            t6 = discord.ui.TextDisplay("⬇️ End of separator demo!")

        await ctx.send(view=SeparatorView())

    # ──────────────────────────────────────────────
    # 6. MediaGallery
    # ──────────────────────────────────────────────
    @commands.command(name="mediagallery", aliases=["gallery"])
    async def media_gallery(self, ctx: commands.Context):
        """Sends a MediaGallery with multiple images (1–10 items supported)."""

        class GalleryView(discord.ui.LayoutView):
            header = discord.ui.TextDisplay(
                "## MediaGallery Demo 🖼️\nDisplaying 3 images below (supports 1–10 items):"
            )

            gallery = discord.ui.MediaGallery(
                discord.MediaGalleryItem(
                    "https://picsum.photos/seed/alpha/400/300",
                    description="Random image 1",
                ),
                discord.MediaGalleryItem(
                    "https://picsum.photos/seed/beta/400/300",
                    description="Random image 2",
                ),
                discord.MediaGalleryItem(
                    "https://picsum.photos/seed/gamma/400/300",
                    description="A spoilered image",
                    spoiler=True,
                ),
            )

        await ctx.send(view=GalleryView())

    # ──────────────────────────────────────────────
    # 7. File display (ui.File)
    # ──────────────────────────────────────────────
    @commands.command(name="filedisplay", aliases=["file"])
    async def file_display(self, ctx: commands.Context):
        """Sends a ui.File component (non-preview file attachment display)."""

        # Create a simple in-memory text file to attach
        import io
        file_content = b"Hello from a discord.ui.File component!\nThis is Components V2."
        discord_file = discord.File(io.BytesIO(file_content), filename="hello_cv2.txt")

        class FileView(discord.ui.LayoutView):
            header = discord.ui.TextDisplay(
                "## File Display Demo 📄\n"
                "`discord.ui.File` shows an attachment in the component layout.\n"
                "Note: No preview is shown — just a download link."
            )
            file_component = discord.ui.File("attachment://hello_cv2.txt")

        await ctx.send(view=FileView(), files=[discord_file])

    # ──────────────────────────────────────────────
    # 8. Container
    # ──────────────────────────────────────────────
    @commands.command(name="containerr")
    async def containerr(self, ctx: commands.Context):
        """Sends a Container component (bordered box with accent color)."""

        class InnerContainer(discord.ui.Container):
            title_text = discord.ui.TextDisplay("### 📦 Inside a Container!")
            body_text = discord.ui.TextDisplay(
                "A `Container` wraps other top-level components in a **bordered box**.\n"
                "You can set an `accent_color` — just like an embed's left-side stripe."
            )
            sep = discord.ui.Separator(spacing=discord.SeparatorSpacing.small, visible=True)
            footer_text = discord.ui.TextDisplay("*This text is also inside the container.*")

        class ContainerView(discord.ui.LayoutView):
            header = discord.ui.TextDisplay("## Container Demo 📦")
            box = InnerContainer(accent_color=0x5865F2)  # Discord Blurple

        await ctx.send(view=ContainerView())

    # ──────────────────────────────────────────────
    # 9. Select Menus inside ActionRow inside Container
    # ──────────────────────────────────────────────
    @commands.command(name="selectmenu", aliases=["select"])
    async def select_menu(self, ctx: commands.Context):
        """Sends a LayoutView with a select menu inside an ActionRow inside a Container."""

        class MySelect(discord.ui.Select):
            def __init__(self):
                super().__init__(
                    placeholder="Choose an option...",
                    options=[
                        discord.SelectOption(label="Option A", value="a"),
                        discord.SelectOption(label="Option B", value="b"),
                        discord.SelectOption(label="Option C", value="c"),
                    ],
                )

            async def callback(self, interaction: discord.Interaction):
                chosen = ", ".join(self.values)
                await interaction.response.send_message(
                    f"You selected: **{chosen}**", ephemeral=True
                )

        class SelectContainer(discord.ui.Container):
            label = discord.ui.TextDisplay(
                "## Select Menu Demo 📋\n"
                "Select menus live inside an **ActionRow**, inside a **Container**:"
            )
            row = discord.ui.ActionRow(MySelect())

        class SelectView(discord.ui.LayoutView):
            box = SelectContainer(accent_color=0x5865F2)

        await ctx.send(view=SelectView())

    # ──────────────────────────────────────────────
    # 10. Section with Button accessory
    # ──────────────────────────────────────────────
    @commands.command(name="sectionbutton", aliases=["secbtn"])
    async def section_button(self, ctx: commands.Context):
        """Sends a Section where the accessory is a Button (not a Thumbnail)."""

        class SectionBtnView(discord.ui.LayoutView):
            header = discord.ui.TextDisplay("## Section + Button Accessory Demo 🔘")

            class MyButton(discord.ui.Button):
                def __init__(self):
                    super().__init__(label="Click me!", style=discord.ButtonStyle.success)

                async def callback(self, interaction: discord.Interaction):
                    await interaction.response.send_message(
                        "✅ Button inside a Section was clicked!", ephemeral=True
                    )

            sec = discord.ui.Section(
                discord.ui.TextDisplay("A **Section** can also use a **Button** as its accessory."),
                discord.ui.TextDisplay("The button appears to the right of this text block."),
                accessory=MyButton(),
            )

        await ctx.send(view=SectionBtnView())

    # ──────────────────────────────────────────────
    # 11. find_item via component id
    # ──────────────────────────────────────────────
    @commands.command(name="componentid", aliases=["finditem"])
    async def component_id(self, ctx: commands.Context):
        """Demonstrates numeric component IDs and LayoutView.find_item()."""

        COUNT_DISPLAY_ID = 99001

        class CounterView(discord.ui.LayoutView):
            count: int = 0

            container = discord.ui.Container(
                discord.ui.Section(
                    discord.ui.TextDisplay(
                        "The current count is **0**.",
                        id=COUNT_DISPLAY_ID,
                    ),
                    accessory=discord.ui.Button(
                        label="+1",
                        style=discord.ButtonStyle.primary,
                    ),
                )
            )

            # wire up the button callback after the class body
            async def _btn_callback(self, interaction: discord.Interaction):
                self.count += 1
                display: discord.ui.TextDisplay = self.find_item(COUNT_DISPLAY_ID)
                display.content = f"The current count is **{self.count}**."
                await interaction.response.edit_message(view=self)

            def __init__(self):
                super().__init__()
                # Grab the button from the nested Section accessory and attach callback
                section = self.container.children[0]  # type: discord.ui.Section
                section.accessory.callback = self._btn_callback.__get__(self, CounterView)

        await ctx.send(
            view=CounterView(),
        )

    # ──────────────────────────────────────────────
    # 12. ALL components combined showcase
    # ──────────────────────────────────────────────
    @commands.command(name="showcase", aliases=["all", "cv2"])
    async def showcase(self, ctx: commands.Context):
        """Sends one big LayoutView showcasing ALL Components V2 components together."""

        class ShowcaseView(discord.ui.LayoutView):

            # ── TextDisplay ──
            title = discord.ui.TextDisplay(
                "# 🧩 Components V2 — Full Showcase\nEvery new component in one message!"
            )

            sep0 = discord.ui.Separator(spacing=discord.SeparatorSpacing.small, visible=True)

            # ── Section + Thumbnail ──
            sec = discord.ui.Section(
                discord.ui.TextDisplay("**Section + Thumbnail**\nText on the left, image on the right."),
                accessory=discord.ui.Thumbnail(
                    "https://cdn.discordapp.com/embed/avatars/2.png",
                    description="Thumbnail accessory",
                ),
            )

            sep1 = discord.ui.Separator(spacing=discord.SeparatorSpacing.large, visible=True)

            # ── MediaGallery ──
            gallery_label = discord.ui.TextDisplay("**MediaGallery** — up to 10 images/videos:")
            gallery = discord.ui.MediaGallery(
                discord.MediaGalleryItem(
                    "https://picsum.photos/seed/showcase1/400/300",
                    description="Gallery image 1",
                ),
                discord.MediaGalleryItem(
                    "https://picsum.photos/seed/showcase2/400/300",
                    description="Gallery image 2",
                ),
            )

            sep2 = discord.ui.Separator(spacing=discord.SeparatorSpacing.large, visible=True)

            # ── Container ──
            class InnerBox(discord.ui.Container):
                box_text = discord.ui.TextDisplay(
                    "**Container** — a bordered box with accent color.\n"
                    "Can hold other top-level components inside it."
                )

            container_label = discord.ui.TextDisplay("**Container** with accent color:")
            box = InnerBox(accent_color=0x57F287)  # Discord Green

            sep3 = discord.ui.Separator(spacing=discord.SeparatorSpacing.large, visible=True)

            # ── ActionRow with Buttons ──
            buttons_label = discord.ui.TextDisplay("**ActionRow** with buttons:")
            row = discord.ui.ActionRow()

            @row.button(label="Button A", style=discord.ButtonStyle.primary)
            async def btn_a(self, interaction: discord.Interaction, button: discord.ui.Button):
                await interaction.response.send_message("Button A clicked!", ephemeral=True)

            @row.button(label="Button B", style=discord.ButtonStyle.secondary)
            async def btn_b(self, interaction: discord.Interaction, button: discord.ui.Button):
                await interaction.response.send_message("Button B clicked!", ephemeral=True)

            # ── ActionRow with Select ──
            class ShowcaseSelect(discord.ui.Select):
                def __init__(self):
                    super().__init__(
                        placeholder="Select menu inside ActionRow...",
                        options=[
                            discord.SelectOption(label="Choice 1", value="1"),
                            discord.SelectOption(label="Choice 2", value="2"),
                            discord.SelectOption(label="Choice 3", value="3"),
                        ],
                    )

                async def callback(self, interaction: discord.Interaction):
                    await interaction.response.send_message(
                        f"Selected: {', '.join(self.values)}", ephemeral=True
                    )

            row2 = discord.ui.ActionRow(ShowcaseSelect())

            sep4 = discord.ui.Separator(spacing=discord.SeparatorSpacing.small, visible=False)

            footer = discord.ui.TextDisplay(
                "*That's all the Components V2 components! Use individual commands like "
                "`?textdisplay`, `?section`, `?thumbnail`, `?separator`, `?mediagallery`, "
                "`?container`, `?actionrow`, `?selectmenu`, `?sectionbutton`, `?filedisplay`, "
                "`?componentid` to explore each one.*"
            )

        await ctx.send(view=ShowcaseView())


async def setup(bot: commands.Bot):
    await bot.add_cog(Test(bot))