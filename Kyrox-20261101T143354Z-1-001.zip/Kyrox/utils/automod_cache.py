from __future__ import annotations

from dataclasses import dataclass

from utils.cache import TTLCache
from utils.database import get_collection

_automod_cache = TTLCache["AutomodGuildState"](ttl=45.0)


@dataclass(frozen=True, slots=True)
class AutomodGuildState:
    enabled: bool
    events: dict[str, str]
    ignored_channels: frozenset[int]
    ignored_roles: frozenset[int]
    log_channel_id: int | None


_EMPTY = AutomodGuildState(False, {}, frozenset(), frozenset(), None)


async def get_automod_state(guild_id: int) -> AutomodGuildState:
    key = f"automod:{guild_id}"
    cached = await _automod_cache.get(key)
    if cached is not None:
        return cached

    collection = await get_collection("automod")
    doc = await collection.find_one({"guild_id": guild_id})
    enabled = doc is not None and doc.get("enabled", 0) == 1

    events: dict[str, str] = {}
    punish_coll = await get_collection("automod_punishments")
    async for pdoc in punish_coll.find({"guild_id": guild_id}):
        events[pdoc["event"]] = pdoc["punishment"]

    ignored_channels: set[int] = set()
    ignored_roles: set[int] = set()
    ignored_coll = await get_collection("automod_ignored")
    async for idoc in ignored_coll.find({"guild_id": guild_id}):
        if idoc["type"] == "channel":
            ignored_channels.add(int(idoc["id"]))
        elif idoc["type"] == "role":
            ignored_roles.add(int(idoc["id"]))

    log_channel_id = None
    log_coll = await get_collection("automod_logging")
    ldoc = await log_coll.find_one({"guild_id": guild_id})
    if ldoc and ldoc.get("log_channel"):
        log_channel_id = int(ldoc["log_channel"])

    state = AutomodGuildState(
        enabled=enabled,
        events=events,
        ignored_channels=frozenset(ignored_channels),
        ignored_roles=frozenset(ignored_roles),
        log_channel_id=log_channel_id,
    )
    await _automod_cache.set(key, state)
    return state


async def invalidate_automod_state(guild_id: int) -> None:
    await _automod_cache.invalidate(f"automod:{guild_id}")


@dataclass(frozen=True, slots=True)
class AutomodGate:
    punishment: str
    log_channel_id: int | None


async def automod_gate(message, event_name: str) -> AutomodGate | None:
    """Fast cached gate used by automod listeners."""
    if message.author.bot or message.guild is None:
        return None

    guild = message.guild
    user = message.author
    channel = message.channel

    me = guild.me
    if user.id == guild.owner_id or (me and user.id == me.id):
        return None

    state = await get_automod_state(guild.id)
    if not state.enabled:
        return None

    punishment = state.events.get(event_name)
    if not punishment:
        return None

    if channel.id in state.ignored_channels:
        return None

    if any(role.id in state.ignored_roles for role in user.roles):
        return None

    return AutomodGate(punishment=punishment, log_channel_id=state.log_channel_id)