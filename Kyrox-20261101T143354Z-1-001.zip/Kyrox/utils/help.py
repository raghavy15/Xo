from __future__ import annotations

import asyncio
from difflib import get_close_matches
from typing import Optional

import discord
from discord.ext import commands

from utils import emojis
from utils.components_v2 import action_row, separator, text
from utils.config import PREFIX

try:
    from utils.config import serverLink
except ImportError:  # pragma: no cover - fallback if not configured yet
    serverLink = "https://discord.gg/your-support-server"

try:
    from utils.config import WEBSITE_URL
except ImportError:  # pragma: no cover - fallback if not configured yet
    WEBSITE_URL = "https://vaishnav.fun/"

MAX_PAGE_CHARS = 3600
HELP_VIEW_TIMEOUT = 120.0
MENU_TIMEOUT = 120.0
MENU_COMMANDS_PER_PAGE = 6


class ExpiringHelpMixin:
    """Delete the help message when the view times out."""

    message: Optional[discord.Message] = None

    def bind_message(self, message: discord.Message) -> None:
        self.message = message

    async def _delete_bound_message(self) -> None:
        if self.message is None:
            return
        try:
            await self.message.delete()
        except (discord.NotFound, discord.Forbidden, discord.HTTPException):
            pass
        finally:
            self.message = None

    async def on_timeout(self) -> None:
        await self._delete_bound_message()


def schedule_help_expire(
    message: discord.Message,
    delay: float = HELP_VIEW_TIMEOUT,
) -> None:
    """Delete a static help panel after a fixed delay."""

    async def _expire() -> None:
        await asyncio.sleep(delay)
        try:
            await message.delete()
        except (discord.NotFound, discord.Forbidden, discord.HTTPException):
            pass

    asyncio.create_task(_expire())


async def reply_help(
    ctx: commands.Context,
    view: discord.ui.View,
    **kwargs,
) -> discord.Message:
    """Send a help panel and auto-remove it when the view expires."""
    message = await ctx.reply(view=view, **kwargs)
    if isinstance(view, ExpiringHelpMixin):
        view.bind_message(message)
    elif isinstance(view, discord.ui.LayoutView) and view.timeout:
        schedule_help_expire(message, view.timeout)
    else:
        schedule_help_expire(message)
    return message


class HelpDropdown(discord.ui.Select):
    def __init__(self, ctx: commands.Context, options: list[discord.SelectOption]):
        super().__init__(
            placeholder="↳ Select a module to see",
            min_values=1,
            max_values=1,
            options=options,
            custom_id=f"help:v2:select:{ctx.author.id}",
        )
        self.invoker = ctx.author

    async def callback(self, interaction: discord.Interaction):
        if interaction.user != self.invoker:
            await interaction.response.send_message(
                "You must run this command to interact with it.",
                ephemeral=True,
            )
            return

        view: HelpView = self.view  # type: ignore[assignment]
        index = view.find_index_from_select(self.values[0])
        await view.set_page(index, interaction)


class HelpButton(discord.ui.Button):
    def __init__(
        self,
        *,
        invoker: discord.abc.User,
        action: str,
        emoji: str,
        disabled: bool = False,
        style: discord.ButtonStyle = discord.ButtonStyle.secondary,
    ):
        super().__init__(
            emoji=emoji,
            style=style,
            custom_id=f"help:v2:{action}:{invoker.id}",
            disabled=disabled,
        )
        self.invoker = invoker
        self.action = action

    async def callback(self, interaction: discord.Interaction):
        if interaction.user != self.invoker:
            await interaction.response.send_message(
                "You must run this command to interact with it.",
                ephemeral=True,
            )
            return

        view: HelpView = self.view  # type: ignore[assignment]

        if self.action == "prev":
            await view.set_page(view.index - 1, interaction)

        elif self.action == "delete":
            await interaction.response.defer()
            if interaction.message:
                await interaction.message.delete()

        elif self.action == "next":
            await view.set_page(view.index + 1, interaction)

        elif self.action == "last":
            await view.set_page(view.total_pages - 1, interaction)


class HelpView(ExpiringHelpMixin, discord.ui.LayoutView):
    def __init__(
        self,
        mapping: dict,
        ctx: commands.Context,
        homeembed: Optional[discord.Embed] = None,
        ui: int = 2,
        *,
        prefix: Optional[str] = None,
        total_commands: Optional[int] = None,
        timeout: float = HELP_VIEW_TIMEOUT,
    ):
        super().__init__(timeout=timeout)

        self.mapping = mapping
        self.ctx = ctx
        self.prefix = prefix or getattr(ctx, "prefix", PREFIX) or PREFIX
        self.total_commands = total_commands or len(set(ctx.bot.walk_commands()))
        self.index = 0

        self.pages, self.options = self._build_pages()
        self.total_pages = len(self.pages)

        self._render()

    def get_cogs(self):
        return list(self.mapping.keys())

    def find_index_from_select(self, value: str) -> int:
        for index, option in enumerate(self.options):
            if option.value == value:
                return index
        return 0

    def _bot_logo_url(self) -> Optional[str]:
        bot_user = self.ctx.bot.user

        if not bot_user:
            return None

        if bot_user.display_avatar:
            return bot_user.display_avatar.url

        if bot_user.avatar:
            return bot_user.avatar.url

        return None

    def _home_header(self) -> str:
        bot_name = self.ctx.bot.user.name if self.ctx.bot.user else "KyroX"
        return (
            f"**Hey, I'm {bot_name}**\n\n"
            f"{emojis.BLUEDOT} **My prefix for this server is** `{self.prefix}`\n"
            f"{emojis.BLUEDOT} **Type** `{self.prefix}help [command]` **for more info**\n"
            f"{emojis.BLUEDOT} **Total commands:** `{self.total_commands}`\n"
        )

    def _home_modules(self) -> str:
        return (
            "<:dot_flowerblue_nc:1526949160857894922> `»` **Security**\n"
            "<:dot_flowerblue_nc:1526949160857894922> `»` **Automod**\n"
            "<:dot_flowerblue_nc:1526949160857894922> `»` **Moderation**\n"
            "<:dot_flowerblue_nc:1526949160857894922> `»` **Utility**\n"
            "<:dot_flowerblue_nc:1526949160857894922> `»` **Welcomer**\n"
            "<:dot_flowerblue_nc:1526949160857894922> `»` **Ticket**\n"
            "<:dot_flowerblue_nc:1526949160857894922> `»` **Music**\n"
            "<:dot_flowerblue_nc:1526949160857894922> `»` **Giveaway**\n"
            "<:dot_flowerblue_nc:1526949160857894922> `»` **Extra**"
        )

    def _home_features(self) -> str:
        return (
            "**__Pro Tip__**\n"
            f"Enable **Auto-Mod** with `{self.prefix}automod enable` to instantly secure your server against raids! {emojis.SECURITY}\n\n"
            f"<:502352link:1520019364584231074> **__Links__**\n"
            "[Invite me](https://kyroxbot.xyz/invite) • [Support](https://discord.gg/himalaya) • [Website](https://kyrox.xyz)"
        )

    def _build_home_page(self) -> str:
        return "\n\n".join(
            [
                self._home_header(),
                self._home_modules(),
                self._home_features(),
            ]
        )

    def _home_header_component(self):
        logo_url = self._bot_logo_url()

        Section = getattr(discord.ui, "Section", None)
        Thumbnail = getattr(discord.ui, "Thumbnail", None)

        if not logo_url or Section is None or Thumbnail is None:
            return text(self._home_header())

        try:
            return Section(
                text(self._home_header()),
                accessory=Thumbnail(logo_url),
            )
        except Exception:
            return text(self._home_header())

    def _build_command_page(self, cog) -> str:
        emoji, label, description = cog.help_custom()

        all_cmds = []

        for cmd in cog.get_commands():
            if cmd.hidden:
                continue

            if (
                isinstance(cmd, commands.Group)
                and cmd.name.startswith("__")
                and not list(cmd.walk_commands())
                and cmd.help
            ):
                doc_list = cmd.help.strip()

                lines = [
                    f"{emoji} {label}",
                    "",
                    f"**{label}**",
                    doc_list,
                ]

                page = "\n".join(lines).strip()

                if len(page) > MAX_PAGE_CHARS:
                    page = page[: MAX_PAGE_CHARS - 20].rstrip() + "\n`...`"

                return page

            all_cmds.append(cmd)

            if isinstance(cmd, commands.Group):
                all_cmds.extend(sub for sub in cmd.walk_commands() if not sub.hidden)

        lines = [
            f"{emoji} {label}",
            "",
            f"**{label}**",
        ]

        if not all_cmds:
            lines.append("*No commands available.*")
        else:
            cmd_tags = " , ".join(f"`{cmd.name}`" for cmd in all_cmds)
            lines.append(cmd_tags)

        page = "\n".join(lines).strip()

        if len(page) > MAX_PAGE_CHARS:
            page = page[: MAX_PAGE_CHARS - 20].rstrip() + "\n`...`"

        return page

    def _build_pages(self) -> tuple[list[str], list[discord.SelectOption]]:
        pages = [self._build_home_page()]

        options = [
            discord.SelectOption(
                label="Home",
                value="__home__",
                emoji=str(emojis.HOME),
                description="Main help panel",
            )
        ]

        for cog in self.get_cogs():
            if "help_custom" not in dir(cog):
                continue

            emoji, label, description = cog.help_custom()

            pages.append(self._build_command_page(cog))

            options.append(
                discord.SelectOption(
                    label=label[:100],
                    value=label[:100],
                    emoji=str(emoji),
                    description=(description or "")[:100],
                )
            )

        return pages, options[:25]

    def _footer(self) -> str:
        return (
            f"- Help page {self.index + 1}/{self.total_pages} "
            f"| Closes after {int(HELP_VIEW_TIMEOUT)}s idle "
            f"| Requested by: {self.ctx.author.display_name}"
        )

    def _nav_buttons(self) -> list[HelpButton]:
        prev_emoji = getattr(emojis, "PREVIOUS", emojis.NEXT)

        return [
            HelpButton(
                invoker=self.ctx.author,
                action="home",
                emoji=str(emojis.REWIND1),
                disabled=self.index == 0,
            ),
            HelpButton(
                invoker=self.ctx.author,
                action="prev",
                emoji=str(prev_emoji),
                disabled=self.index == 0,
            ),
            HelpButton(
                invoker=self.ctx.author,
                action="delete",
                emoji=str(emojis.DELETE),
                style=discord.ButtonStyle.danger,
            ),
            HelpButton(
                invoker=self.ctx.author,
                action="next",
                emoji=str(emojis.ICONS_NEXT),
                disabled=self.index >= self.total_pages - 1,
            ),
            HelpButton(
                invoker=self.ctx.author,
                action="last",
                emoji=str(emojis.FORWARD),
                disabled=self.index >= self.total_pages - 1,
            ),
        ]

    def _render_home(self) -> None:
        parts = [
            self._home_header_component(),
            separator(),
            text(self._home_modules()),
            separator(),
            text(self._home_features()),
            separator(),
        ]
        
        # Add the MediaGallery for the banner image
        gallery = discord.ui.MediaGallery()
        gallery.add_item(media="attachment://banner.png")
        parts.append(gallery)
        parts.append(separator())
        
        parts.extend([
            text(self._footer()),
            separator(),
            action_row(*self._nav_buttons()),
            action_row(HelpDropdown(self.ctx, self.options)),
        ])
        
        self.add_item(discord.ui.Container(*parts))

    def _render_command_page(self) -> None:
        self.add_item(
            discord.ui.Container(
                text(self.pages[self.index]),
                separator(),
                text(self._footer()),
                separator(),
                action_row(*self._nav_buttons()),
                action_row(HelpDropdown(self.ctx, self.options)),
            )
        )

    def _render(self) -> None:
        self.clear_items()

        if self.index == 0:
            self._render_home()
        else:
            self._render_command_page()

    async def set_page(self, page: int, interaction: discord.Interaction):
        self.index = max(0, min(page, self.total_pages - 1))
        self._render()

        if interaction.response.is_done():
            await interaction.edit_original_response(view=self)
        else:
            await interaction.response.edit_message(view=self)


class ListNavButton(discord.ui.Button):
    def __init__(
        self,
        *,
        invoker: discord.abc.User,
        action: str,
        emoji: str,
        disabled: bool = False,
        style: discord.ButtonStyle = discord.ButtonStyle.secondary,
    ):
        super().__init__(
            emoji=emoji,
            style=style,
            custom_id=f"help:list:{action}:{invoker.id}",
            disabled=disabled,
        )
        self.invoker = invoker
        self.action = action

    async def callback(self, interaction: discord.Interaction):
        if interaction.user != self.invoker:
            await interaction.response.send_message(
                "You must run this command to interact with it.",
                ephemeral=True,
            )
            return

        view: HelpListView = self.view  # type: ignore[assignment]

        if self.action == "first":
            await view.set_page(0, interaction)
        elif self.action == "prev":
            await view.set_page(view.index - 1, interaction)
        elif self.action == "delete":
            await interaction.response.defer()
            if interaction.message:
                await interaction.message.delete()
        elif self.action == "next":
            await view.set_page(view.index + 1, interaction)
        elif self.action == "last":
            await view.set_page(view.total_pages - 1, interaction)


class HelpListView(ExpiringHelpMixin, discord.ui.LayoutView):
    """CV2 paginated list for per-command and per-category help."""

    def __init__(
        self,
        ctx: commands.Context,
        *,
        title: str,
        description: str = "",
        entries: list[tuple[str, str]],
        per_page: int = 4,
        timeout: float = HELP_VIEW_TIMEOUT,
    ):
        super().__init__(timeout=timeout)
        self.ctx = ctx
        self.title = title
        self.description = description
        self.entries = entries
        self.per_page = per_page
        self.index = 0
        self.total_pages = max(1, (len(entries) + per_page - 1) // per_page)
        self._render()

    def _page_body(self) -> str:
        start = self.index * self.per_page
        chunk = self.entries[start : start + self.per_page]
        lines = [f"## {self.title}"]
        if self.description:
            lines.extend(["", self.description.strip()])
        if not chunk:
            lines.extend(["", "*No entries to display.*"])
        else:
            lines.append("")
            for name, value in chunk:
                lines.append(f"**{name.strip()}**")
                if value.strip():
                    lines.append(value.strip())
                lines.append("")
        return "\n".join(lines).strip()

    def _footer(self) -> str:
        return (
            f"- Page {self.index + 1}/{self.total_pages} "
            f"| Closes after {int(HELP_VIEW_TIMEOUT)}s idle "
            f"| Requested by {self.ctx.author.display_name}"
        )

    def _nav_buttons(self) -> list[ListNavButton]:
        prev_emoji = getattr(emojis, "PREVIOUS", emojis.NEXT)
        return [
            ListNavButton(
                invoker=self.ctx.author,
                action="first",
                emoji=str(emojis.REWIND1),
                disabled=self.index == 0,
            ),
            ListNavButton(
                invoker=self.ctx.author,
                action="prev",
                emoji=str(prev_emoji),
                disabled=self.index == 0,
            ),
            ListNavButton(
                invoker=self.ctx.author,
                action="delete",
                emoji=str(emojis.DELETE),
                style=discord.ButtonStyle.danger,
            ),
            ListNavButton(
                invoker=self.ctx.author,
                action="next",
                emoji=str(emojis.ICONS_NEXT),
                disabled=self.index >= self.total_pages - 1,
            ),
            ListNavButton(
                invoker=self.ctx.author,
                action="last",
                emoji=str(emojis.FORWARD),
                disabled=self.index >= self.total_pages - 1,
            ),
        ]

    def _render(self) -> None:
        self.clear_items()
        self.add_item(
            discord.ui.Container(
                text(self._page_body()),
                separator(),
                text(self._footer()),
                separator(),
                action_row(*self._nav_buttons()),
            )
        )

    async def set_page(self, page: int, interaction: discord.Interaction) -> None:
        self.index = max(0, min(page, self.total_pages - 1))
        self._render()
        if interaction.response.is_done():
            await interaction.edit_original_response(view=self)
        else:
            await interaction.response.edit_message(view=self)


View = HelpView


# ---------------------------------------------------------------------- #
# Brand new two-container help menu (Components V2)
#
# Container 1 (nav):     search button (top-left) + category dropdown
# Container 2 (content): home / category listing / single-command view,
#                         always edited in place.
# On timeout the whole message collapses into a single "timed out"
# container with the three link buttons.
# ---------------------------------------------------------------------- #


def _invite_url(bot_id: int) -> str:
    """Build a bot invite link with the Administrator permission pre-selected."""
    perms = discord.Permissions(administrator=True)
    return discord.utils.oauth_url(bot_id, permissions=perms, scopes=("bot", "applications.commands"))


def _bot_avatar_url(bot: discord.Client) -> Optional[str]:
    if not bot.user:
        return None
    return bot.user.display_avatar.url if bot.user.display_avatar else None


class CommandSearchModal(discord.ui.Modal, title="Search a Command"):
    query: discord.ui.TextInput = discord.ui.TextInput(
        label="Command name",
        placeholder="e.g. ban, play, help...",
        min_length=1,
        max_length=100,
    )

    def __init__(self, menu: "HelpMenuView"):
        super().__init__(timeout=90)
        self.menu = menu

    async def on_submit(self, interaction: discord.Interaction) -> None:
        await self.menu.handle_search(interaction, self.query.value)

    async def on_error(self, interaction: discord.Interaction, error: Exception) -> None:
        message = "Something went wrong while searching for that command."
        if interaction.response.is_done():
            await interaction.followup.send(message, ephemeral=True)
        else:
            await interaction.response.send_message(message, ephemeral=True)


class MenuSearchButton(discord.ui.Button):
    def __init__(self, invoker: discord.abc.User):
        super().__init__(
            label="Search",
            emoji="🔍",
            style=discord.ButtonStyle.secondary,
            custom_id=f"help:menu:search:{invoker.id}",
        )
        self.invoker = invoker

    async def callback(self, interaction: discord.Interaction) -> None:
        if interaction.user != self.invoker:
            await interaction.response.send_message(
                "You must run this command to interact with it.", ephemeral=True
            )
            return
        menu: HelpMenuView = self.view  # type: ignore[assignment]
        await interaction.response.send_modal(CommandSearchModal(menu))


class MenuFeatureButton(discord.ui.Button):
    def __init__(self, invoker: discord.abc.User):
        super().__init__(
            label="Get Started",
            emoji="<:798008booster:1520019388395294860>",
            style=discord.ButtonStyle.success,
            custom_id=f"help:menu:features:{invoker.id}",
        )
        self.invoker = invoker

    async def callback(self, interaction: discord.Interaction) -> None:
        if interaction.user != self.invoker:
            await interaction.response.send_message(
                "You must run this command to interact with it.", ephemeral=True
            )
            return
        menu: HelpMenuView = self.view  # type: ignore[assignment]
        await menu.show_overview(interaction)


class MenuCategorySelect(discord.ui.Select):
    def __init__(self, invoker: discord.abc.User, options: list[discord.SelectOption]):
        super().__init__(
            placeholder="↳ Select a category",
            min_values=1,
            max_values=1,
            options=options,
            custom_id=f"help:menu:select:{invoker.id}",
        )
        self.invoker = invoker

    async def callback(self, interaction: discord.Interaction) -> None:
        if interaction.user != self.invoker:
            await interaction.response.send_message(
                "You must run this command to interact with it.", ephemeral=True
            )
            return
        menu: HelpMenuView = self.view  # type: ignore[assignment]
        await menu.select_category(interaction, self.values[0])


class MenuNavButton(discord.ui.Button):
    def __init__(
        self,
        *,
        invoker: discord.abc.User,
        action: str,
        emoji: str,
        disabled: bool = False,
        style: discord.ButtonStyle = discord.ButtonStyle.secondary,
    ):
        super().__init__(
            emoji=emoji,
            style=style,
            custom_id=f"help:menu:nav:{action}:{invoker.id}",
            disabled=disabled,
        )
        self.invoker = invoker
        self.action = action

    async def callback(self, interaction: discord.Interaction) -> None:
        if interaction.user != self.invoker:
            await interaction.response.send_message(
                "You must run this command to interact with it.", ephemeral=True
            )
            return
        menu: HelpMenuView = self.view  # type: ignore[assignment]

        if self.action == "home":
            menu.content_state = None
            menu._render()
            await menu._push(interaction)
        elif self.action == "prev":
            await menu.turn_page(interaction, -1)
        elif self.action == "next":
            await menu.turn_page(interaction, 1)
        elif self.action == "delete":
            await interaction.response.defer()
            if interaction.message:
                await interaction.message.delete()


class HelpMenuView(discord.ui.LayoutView):
    """
    Single top container (title + features teaser + dropdown) that stays put,
    with a second content container that only appears once the person picks
    something — the feature button, the dropdown, or the search button.
    """

    def __init__(
        self,
        mapping: dict,
        ctx: commands.Context,
        *,
        prefix: Optional[str] = None,
        total_commands: Optional[int] = None,
        timeout: float = MENU_TIMEOUT,
    ):
        super().__init__(timeout=timeout)

        self.mapping = mapping
        self.ctx = ctx
        self.prefix = prefix or getattr(ctx, "prefix", PREFIX) or PREFIX
        self.total_commands = total_commands or len(set(ctx.bot.walk_commands()))
        self.message: Optional[discord.Message] = None

        # content_state: None (no second container yet) | "overview" | "category" | "command" | "message"
        self.content_state: Optional[str] = None
        self.page_index = 0
        self.current_category: Optional[dict] = None
        self.current_command: Optional[commands.Command] = None
        self._pending_title = ""
        self._pending_body = ""

        self.categories = self._build_categories()
        self._render()

    # ------------------------------------------------------------------ #
    # setup helpers
    # ------------------------------------------------------------------ #

    def bind_message(self, message: discord.Message) -> None:
        self.message = message

    def _build_categories(self) -> list[dict]:
        categories = []
        for cog in self.mapping.keys():
            if cog is None or "help_custom" not in dir(cog):
                continue

            cog_commands = [c for c in cog.get_commands() if not c.hidden]
            if not cog_commands:
                continue

            emoji, label, description = cog.help_custom()
            categories.append(
                {
                    "cog": cog,
                    "emoji": emoji,
                    "label": label,
                    "description": description,
                    "commands": cog_commands,
                }
            )
        return categories

    def _select_options(self) -> list[discord.SelectOption]:
        options = []
        for cat in self.categories:
            options.append(
                discord.SelectOption(
                    label=cat["label"][:100],
                    value=cat["label"][:100],
                    emoji=str(cat["emoji"]),
                    description=(cat["description"] or "")[:100],
                    default=self.content_state == "category" and self.current_category is cat,
                )
            )
        return options[:25]

    def _links_row(self):
        bot = self.ctx.bot
        invite = _invite_url(bot.user.id) if bot.user else "https://discord.com"
        return action_row(
            discord.ui.Button(label="Support Server", emoji="<:623618bot:1520019378446401579>", url=serverLink, style=discord.ButtonStyle.link),
            discord.ui.Button(label="Invite Me", emoji="<:479407mention:1520019360633192521>", url=invite, style=discord.ButtonStyle.link),
            discord.ui.Button(label="Website", emoji="<:502352link:1520019364584231074>", url=WEBSITE_URL, style=discord.ButtonStyle.link),
        )

    # ------------------------------------------------------------------ #
    # container 1 (always present): title+search / features+button / dropdown
    # ------------------------------------------------------------------ #

    def _overview_text(self) -> str:
        lines = [
            f"<a:BlueDot:1525086022533386383> **Prefix:** `{self.prefix}`",
            f"<a:BlueDot:1525086022533386383> **Total commands:** `{self.total_commands}`",
            f"<a:BlueDot:1525086022533386383> Use `{self.prefix}help [command]` for command details",
            "",
            "**Modules available:**"
        ]
        for cat in self.categories:
            lines.append(f"<a:BlueDot:1525086022533386383> `»` **{cat['label']}**")
        return "\n".join(lines)

    def _nav_container(self):
        bot = self.ctx.bot
        bot_name = bot.user.name if bot.user else "KyroX"
        bot_avatar = _bot_avatar_url(bot)
        
        # 1. Intro
        intro_text = text(
            f"# {bot_name} Help Panel\n"
            f"Elevate your Discord experience with **{bot_name}** — the all-in-one bot designed for modern communities, featuring powerful tools, instant performance, uncompromising security, and seamless reliability."
        )
        
        Section = getattr(discord.ui, "Section", None)
        Thumbnail = getattr(discord.ui, "Thumbnail", None)
        if Section is not None and Thumbnail is not None and bot_avatar:
            try:
                intro_part = Section(intro_text, accessory=Thumbnail(bot_avatar))
            except Exception:
                intro_part = intro_text
        else:
            intro_part = intro_text

        # 2. Stats
        latency = f"{round(bot.latency * 1000)}ms" if bot.latency else "N/A"
        stats_part = text(
            f"**<a:BlueDot:1525086022533386383> Prefix:** `{self.prefix}`\n"
            f"**<a:BlueDot:1525086022533386383> Commands:** `{self.total_commands}`\n"
            f"**<a:BlueDot:1525086022533386383> Latency:** `{latency}`\n"
            f"**<a:BlueDot:1525086022533386383> Status:** `Online`"
        )

        # 3. Features
        features_part = text(
            f"**Why {bot_name}?**\n"
            "• Advanced moderation and anti-nuke protection.\n"
            "• Powerful utilities, tickets, giveaways, and more.\n"
            "• Fast, stable, and always up-to-date."
        )

        # 4. Buttons
        get_started = MenuFeatureButton(self.ctx.author)
        
        bot_id = bot.user.id if bot.user else 0
        invite_url = _invite_url(bot_id)
        invite_btn = discord.ui.Button(label="Invite", emoji="<:623618bot:1520019378446401579>", url=invite_url, style=discord.ButtonStyle.link)
        support_btn = discord.ui.Button(label="Support", emoji="<:479407mention:1520019360633192521>", url=serverLink, style=discord.ButtonStyle.link)
        website_btn = discord.ui.Button(label="Website", emoji="<:502352link:1520019364584231074>", url=WEBSITE_URL, style=discord.ButtonStyle.link)
        
        buttons_part = action_row(get_started, invite_btn, support_btn, website_btn)


        return discord.ui.Container(
            intro_part,
            separator(),
            stats_part,
            separator(),
            features_part,
            separator(),
            buttons_part,
        )

    # ------------------------------------------------------------------ #
    # container 2 (conditional): overview / category / command / message
    # ------------------------------------------------------------------ #

    def _overview_text(self) -> str:
        lines = [
            f"<a:BlueDot:1525086022533386383> **Prefix:** `{self.prefix}`",
            f"<a:BlueDot:1525086022533386383> **Total commands:** `{self.total_commands}`",
            f"<a:BlueDot:1525086022533386383> Use `{self.prefix}help [command]` for command details",
            "",
            "**Modules available:**"
        ]
        for cat in self.categories:
            lines.append(f"<a:BlueDot:1525086022533386383> `»` **{cat['label']}**")
        return "\n".join(lines)

    def _content_overview(self):
        bot = self.ctx.bot
        bot_name = bot.user.name if bot.user else "Kyrox"
        
        intro_part = text(f"## Hey, I'm {bot_name}! <a:star:1525086734797377546>")
            
        dropdown = action_row(MenuCategorySelect(self.ctx.author, self._select_options()))
        
        nav_buttons = action_row(
            MenuNavButton(
                invoker=self.ctx.author,
                action="home",
                emoji=str(emojis.HOME),
                style=discord.ButtonStyle.secondary,
            ),
            MenuNavButton(
                invoker=self.ctx.author,
                action="delete",
                emoji=str(emojis.DELETE),
                style=discord.ButtonStyle.danger,
            ),
        )

        tip_part = text(
            f"ℹ️ **Pro Tip** — Enable **Auto-Mod** with `{self.prefix}automod enable` "
            "to instantly secure your server against raids! <:tick:1525086743035117629> "
        )

        return discord.ui.Container(
            intro_part,
            text(self._overview_text()),
            separator(),
            tip_part,
            separator(),
            dropdown,
            nav_buttons,

        )

    def _category_content_text(self, cat: dict, total_pages: int) -> str:
        per_page = MENU_COMMANDS_PER_PAGE
        start = self.page_index * per_page
        chunk = cat["commands"][start : start + per_page]

        lines = [f"**__{cat['label']}__**"]
        if cat["description"]:
            lines.append(f"-# {cat['description']}")

        if not chunk:
            lines.append("*No commands available.*")
        else:
            for cmd in chunk:
                short = cmd.short_doc or "No description."
                lines.append(f"> `{self.prefix}{cmd.qualified_name}` - {short}")

        lines.append("")
        lines.append(f"-# Page {self.page_index + 1}/{total_pages} • {len(cat['commands'])} commands")
        return "\n".join(lines)

    def _content_category(self):
        cat = self.current_category
        total_pages = max(1, (len(cat["commands"]) + MENU_COMMANDS_PER_PAGE - 1) // MENU_COMMANDS_PER_PAGE)

        nav = action_row(
            MenuNavButton(
                invoker=self.ctx.author,
                action="home",
                emoji=str(emojis.HOME),
                style=discord.ButtonStyle.secondary,
            ),
            MenuNavButton(
                invoker=self.ctx.author,
                action="prev",
                emoji=str(getattr(emojis, "PREVIOUS", emojis.NEXT)),
                disabled=self.page_index == 0,
            ),
            MenuNavButton(
                invoker=self.ctx.author,
                action="next",
                emoji=str(emojis.ICONS_NEXT),
                disabled=self.page_index >= total_pages - 1,
            ),
            MenuNavButton(
                invoker=self.ctx.author,
                action="delete",
                emoji=str(emojis.DELETE),
                style=discord.ButtonStyle.danger,
            ),
        )
        dropdown = action_row(MenuCategorySelect(self.ctx.author, self._select_options()))

        return discord.ui.Container(
            text(self._category_content_text(cat, total_pages)),
            separator(),
            dropdown,
            separator(),
            nav,
            accent_colour=discord.Colour(0x185FE5),
        )

    def _content_command(self):
        cmd = self.current_command
        alias = " | ".join(cmd.aliases) if cmd.aliases else "No aliases"
        usage = f"{self.prefix}{cmd.qualified_name}"
        if cmd.signature:
            usage += f" {cmd.signature}"

        lines = [
            f"**__{cmd.qualified_name.title()}__**",
            cmd.help or "No help provided.",
            "",
            f"> **Aliases:** `{alias}`",
            f"> **Usage:** `{usage}`",
        ]
        nav = action_row(
            MenuNavButton(
                invoker=self.ctx.author,
                action="home",
                emoji=str(emojis.HOME),
                style=discord.ButtonStyle.secondary,
            ),
            MenuNavButton(
                invoker=self.ctx.author,
                action="delete",
                emoji=str(emojis.DELETE),
                style=discord.ButtonStyle.danger,
            ),
        )
        return discord.ui.Container(
            text("\n".join(lines)),
            separator(),
            nav,
            accent_colour=discord.Colour(0x2ECC71),
        )

    def _content_message(self):
        nav = action_row(
            MenuNavButton(
                invoker=self.ctx.author,
                action="home",
                emoji=str(emojis.HOME),
                style=discord.ButtonStyle.secondary,
            ),
            MenuNavButton(
                invoker=self.ctx.author,
                action="delete",
                emoji=str(emojis.DELETE),
                style=discord.ButtonStyle.danger,
            ),
        )
        lines = [f"**__{self._pending_title}__**", self._pending_body]
        return discord.ui.Container(
            text("\n".join(lines)),
            separator(),
            nav,
            accent_colour=discord.Colour(0xED4245),
        )

    def _timeout_container(self):
        header = text("### <:trap_tf:1517093724704739348> Session Expired")
        body = text(
            "-# oops~ looks like it has been timed out, use "
            f"`{self.prefix}help` again to get help."
        )
        return discord.ui.Container(
            header,
            separator(),
            body,
            separator(),
            self._links_row(),
            accent_colour=discord.Colour(0x99AAB5),
        )

    # ------------------------------------------------------------------ #
    # render / state transitions
    # ------------------------------------------------------------------ #

    def _render(self) -> None:
        self.clear_items()

        if self.content_state is None:
            self.add_item(self._nav_container())
        elif self.content_state == "overview":
            self.add_item(self._content_overview())
        elif self.content_state == "category":
            self.add_item(self._content_category())
        elif self.content_state == "command":
            self.add_item(self._content_command())
        elif self.content_state == "message":
            self.add_item(self._content_message())

    async def _push(self, interaction: discord.Interaction) -> None:
        if interaction.response.is_done():
            await interaction.edit_original_response(view=self)
        else:
            await interaction.response.edit_message(view=self)

    async def show_overview(self, interaction: discord.Interaction) -> None:
        self.content_state = "overview"
        self.current_category = None
        self.current_command = None
        self.page_index = 0
        self._render()
        await self._push(interaction)

    async def select_category(self, interaction: discord.Interaction, value: str) -> None:
        for cat in self.categories:
            if cat["label"][:100] == value:
                self.current_category = cat
                self.current_command = None
                self.content_state = "category"
                self.page_index = 0
                self._render()
                await self._push(interaction)
                return

        await self._push(interaction)

    async def turn_page(self, interaction: discord.Interaction, delta: int) -> None:
        if self.content_state != "category" or not self.current_category:
            await self._push(interaction)
            return

        total_pages = max(
            1,
            (len(self.current_category["commands"]) + MENU_COMMANDS_PER_PAGE - 1) // MENU_COMMANDS_PER_PAGE,
        )
        self.page_index = max(0, min(self.page_index + delta, total_pages - 1))
        self._render()
        await self._push(interaction)

    async def handle_search(self, interaction: discord.Interaction, query: str) -> None:
        query = query.strip()
        bot = self.ctx.bot
        command = bot.get_command(query)

        if command is None or command.hidden:
            names = {str(c) for c in bot.walk_commands() if not c.hidden}
            matches = get_close_matches(query, names, n=3)

            self._pending_title = "Command Not Found"
            self._pending_body = f"No command found matching `{query}`."
            if matches:
                self._pending_body += "\n\n**Did you mean:**\n" + "\n".join(f"`{m}`" for m in matches)

            self.content_state = "message"
            self._render()
            await self._push(interaction)
            return

        self.current_command = command
        self.content_state = "command"
        self._render()
        await self._push(interaction)

    async def on_timeout(self) -> None:
        if self.message is None:
            return
        self.clear_items()
        self.add_item(self._timeout_container())
        try:
            await self.message.edit(view=self)
        except (discord.NotFound, discord.Forbidden, discord.HTTPException):
            pass


async def reply_help_menu(ctx: commands.Context, view: HelpMenuView, **kwargs) -> discord.Message:
    """Send the help menu and bind it for timeout handling."""
    message = await ctx.reply(view=view, **kwargs)
    view.bind_message(message)
    return message