from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable


@dataclass(frozen=True, slots=True)
class CustomEmoji:
    name: str
    id: int
    animated: bool = False

    @property
    def mention(self) -> str:
        prefix = "a" if self.animated else ""
        return f"<{prefix}:{self.name}:{self.id}>"

    @property
    def cdn_url(self) -> str:
        extension = "gif" if self.animated else "png"
        return f"https://cdn.discordapp.com/emojis/{self.id}.{extension}"

    def __str__(self) -> str:
        return self.mention


EMOJI_37496ALERT = CustomEmoji('37496alert', 1560281930564370442, True)
EMOJI_7CLUB_BAN = CustomEmoji('7club_ban', 1560281939104235571, False)
ROSE = CustomEmoji('_rose', 1291476899557671054, True)
AUTOREACT = CustomEmoji('Autoreact', 1560281959438098437, False)
AUTOROLE = CustomEmoji('autorole', 1560281968208515183, False)
AXON_OWNER = CustomEmoji('axon_owner', 1560281978874363904, False)
BLUEDOT = CustomEmoji('BlueDot', 1560281987367833681, True)
BOTS = CustomEmoji('Bots', 1560281995559440386, False)
BROWSER = CustomEmoji('browser', 1560282004224876717, False)
COMMANDS = CustomEmoji('Commands', 1560282012831580170, False)
CROSSICON = CustomEmoji('CrossIcon', 1560282021283233815, False)
CUSTOMROLE = CustomEmoji('customrole', 1560282029751533710, False)
DC_REDCROWNESPORTS = CustomEmoji('Dc_RedCrownEsports', 1560282038995779686, False)
DELETE = CustomEmoji('delete', 1560282047585460397, False)
DENIED = CustomEmoji('Denied', 1560282055961485422, False)
DISABLED1 = CustomEmoji('disabled1', 1560282064589430905, True)
DND = CustomEmoji('dnd', 1560282073191809114, False)
ENABLED = CustomEmoji('enabled', 1560282081496539307, False)
ENABLED_160063 = CustomEmoji('enabled_', 1329022799708160063, True)
EXTRA = CustomEmoji('Extra', 1560282090199711834, False)
FILDER = CustomEmoji('filder', 1560282099163074611, False)
FILE = CustomEmoji('file', 1560282108243738704, False)
FORWARD = CustomEmoji('forward', 1560282116216979468, False)
GAMES = CustomEmoji('games', 1560282125419286528, False)
GEAR = CustomEmoji('Gear', 1560282134051164250, True)
GIFD = CustomEmoji('GIFD', 1560282145056882711, True)
GIFN = CustomEmoji('GIFN', 1560282155676868619, True)
GIVEAWAY = CustomEmoji('giveaway', 1560282164065599569, False)
GIVEAWAY_644980 = CustomEmoji('giveaway', 1560282164065599569, False)
GIVEAWAYS = CustomEmoji('Giveaways', 1560282174274674830, True)
GREET = CustomEmoji('greet', 1560282182868533268, False)
HEADMOD = CustomEmoji('headmod', 1560282191328583731, False)
HEART_EM = CustomEmoji('heart_em', 1560282200317100052, False)
HEERIYE = CustomEmoji('Heeriye', 1560282208739000382, False)
HOME = CustomEmoji('home', 1560282217530392588, False)
ICON_BOOSTER = CustomEmoji('icon_booster', 1560282226409603173, False)
ICON_PING = CustomEmoji('icon_ping', 1560282235477696573, False)
ICONARROWRIGHT = CustomEmoji('iconArrowRight', 1560282243933544598, False)
ICONLOAD = CustomEmoji('iconLoad', 1560282254050201640, False)
ICONS_BOT = CustomEmoji('icons_bot', 1560282262657040638, False)
ICONS_CHANNEL = CustomEmoji('icons_channel', 1560282271204774053, False)
ICONS_DISCORDBOTDEV = CustomEmoji('icons_discordbotdev', 1560282280029720666, False)
ICONS_MUSIC = CustomEmoji('icons_music', 1560282288732766298, False)
ICONS_NEXT = CustomEmoji('icons_next', 1560282297075503196, False)
ICONS_PAUSE = CustomEmoji('icons_pause', 1560282305224769579, False)
ICONS_PLUS = CustomEmoji('icons_plus', 1560282314045399163, False)
ICONS_WARNING = CustomEmoji('icons_warning', 1560282322773876827, False)
ICONSETTING = CustomEmoji('iconSetting', 1560282331091181759, False)
IDLE = CustomEmoji('idle', 1560282339488174130, False)
IGNORE = CustomEmoji('ignore', 1560282347918721257, False)
INFO = CustomEmoji('info', 1560282357343330304, False)
INVITETRACKER = CustomEmoji('InviteTracker', 1560282365861957662, False)
JIOSAAVN = CustomEmoji('jiosaavn', 1560282374443503647, False)
KING = CustomEmoji('king', 1560282382932910224, True)
LAND_YILDIZ = CustomEmoji('land_yildiz', 1560282391786950736, False)
LAND_YILDIZ_722475 = CustomEmoji('land_yildiz', 1560282391786950736, False)
LOADING = CustomEmoji('loading', 1560282400863559720, True)
LOADING_461233 = CustomEmoji('loading', 1560282400863559720, True)
LOGGING = CustomEmoji('logging', 1560282409428066364, False)
MAX__A = CustomEmoji('max__A', 1560282420119343204, True)
MENTION = CustomEmoji('mention', 1560282429669773423, True)
ML_CROSS = CustomEmoji('ml_cross', 1560282438184468591, False)
MOBILE = CustomEmoji('mobile', 1560282447000641649, False)
MOD = CustomEmoji('mod', 1560282455485718578, False)
MODERATION = CustomEmoji('moderation', 1560282463480057950, False)
MODULE = CustomEmoji('Module', 1560282472292286566, False)
MUSIC = CustomEmoji('music', 1560282481243070614, False)
MUSIC_116319 = CustomEmoji('music', 1560282481243070614, False)
MUSICSTOP_ICONS = CustomEmoji('musicstop_icons', 1560282489698910309, False)
NEXT = CustomEmoji('next', 1560282498360025142, False)
OFFLINE = CustomEmoji('offline', 1560282508367626381, True)
OLYMPUS_CROSS = CustomEmoji('olympus_cross', 1560282517729312869, False)
OLYMPUS_NOTIFY = CustomEmoji('olympus_notify', 1560282526004813828, False)
OLYMPUS_STAFF = CustomEmoji('olympus_staff', 1560282535324549270, False)
OLYMPUS_TICK = CustomEmoji('olympus_tick', 1560282543750774784, False)
OLYMPUSARROW = CustomEmoji('olympusArrow', 1560282552231661598, False)
ONLINE = CustomEmoji('online', 1560282563095036058, True)
OWNER = CustomEmoji('owner', 1560282572552929464, True)
OWNER_433185 = CustomEmoji('owner', 1560282572552929464, True)
PC = CustomEmoji('pc', 1560282581012840458, False)
PREMIUM = CustomEmoji('premium', 1560282589523222528, True)
QUESTIONS = CustomEmoji('questions', 1560282598201368666, False)
RED_DOT = CustomEmoji('red_dot', 1560282607139291276, False)
REDHEART = CustomEmoji('RedHeart', 1560282618224971890, True)
REWIND1 = CustomEmoji('rewind1', 1560282627204841554, False)
RIVERSE_FUN = CustomEmoji('riverse_fun', 1560282636268605510, False)
ROSE = CustomEmoji('rose', 1560281951150149724, True)
SECURITY = CustomEmoji('security', 1560282644711870564, False)
SG_RD = CustomEmoji('sg_rd', 1560282653671030977, True)
SHUFFLE = CustomEmoji('shuffle', 1560282662382604359, False)
SKIP = CustomEmoji('skip', 1560282670771212481, False)
SOUNDCLOUD = CustomEmoji('SoundCloud', 1560282679323267073, False)
SQ_HEADMOD = CustomEmoji('sq_HeadMod', 1560282687984636035, False)
STAR = CustomEmoji('star', 1560282696737886228, True)
STAR_147803 = CustomEmoji('star', 1560282696737886228, True)
TICK = CustomEmoji('tick', 1560282705202253837, False)
TICK_RED = CustomEmoji('tick_red', 1560282713926275096, False)
TICKET = CustomEmoji('ticket', 1560282722608480330, False)
TIMER = CustomEmoji('timer', 1560282732800507914, True)
U_ADMIN = CustomEmoji('U_admin', 1560282741331857481, False)
UPTIME = CustomEmoji('Uptime', 1560282751339471001, True)
USER = CustomEmoji('user', 1560282760474665201, False)
UTILITY = CustomEmoji('utility', 1560282768888307998, False)
VANITYROLES = CustomEmoji('vanityroles', 1560282777822437447, False)
VOICE = CustomEmoji('voice', 1560282786416304148, False)
VOICE_003466 = CustomEmoji('voice', 1560282786416304148, False)
WARNING = CustomEmoji('Warning', 1560282795081994331, False)
WARNINGICON = CustomEmoji('WarningIcon', 1560282803437043852, False)
YOUTUBE = CustomEmoji('youtube', 1560282811867336715, False)
YOUTUBE_570841 = CustomEmoji('youtube', 1560282811867336715, False)
ZTICK = CustomEmoji('Ztick', 1560282820751003718, False)


EMOJIS: dict[str, CustomEmoji] = {
    '37496alert': EMOJI_37496ALERT,
    '7club_ban': EMOJI_7CLUB_BAN,
    '_rose': ROSE,
    'Autoreact': AUTOREACT,
    'autorole': AUTOROLE,
    'axon_owner': AXON_OWNER,
    'BlueDot': BLUEDOT,
    'Bots': BOTS,
    'browser': BROWSER,
    'Commands': COMMANDS,
    'CrossIcon': CROSSICON,
    'customrole': CUSTOMROLE,
    'Dc_RedCrownEsports': DC_REDCROWNESPORTS,
    'delete': DELETE,
    'Denied': DENIED,
    'disabled1': DISABLED1,
    'dnd': DND,
    'enabled': ENABLED,
    'enabled_': ENABLED_160063,
    'Extra': EXTRA,
    'filder': FILDER,
    'file': FILE,
    'forward': FORWARD,
    'games': GAMES,
    'Gear': GEAR,
    'GIFD': GIFD,
    'GIFN': GIFN,
    'Giveaway': GIVEAWAY,
    'giveaway': GIVEAWAY_644980,
    'Giveaways': GIVEAWAYS,
    'greet': GREET,
    'headmod': HEADMOD,
    'heart_em': HEART_EM,
    'Heeriye': HEERIYE,
    'home': HOME,
    'icon_booster': ICON_BOOSTER,
    'icon_ping': ICON_PING,
    'iconArrowRight': ICONARROWRIGHT,
    'iconLoad': ICONLOAD,
    'icons_bot': ICONS_BOT,
    'icons_channel': ICONS_CHANNEL,
    'icons_discordbotdev': ICONS_DISCORDBOTDEV,
    'icons_music': ICONS_MUSIC,
    'icons_next': ICONS_NEXT,
    'icons_pause': ICONS_PAUSE,
    'icons_plus': ICONS_PLUS,
    'icons_warning': ICONS_WARNING,
    'iconSetting': ICONSETTING,
    'idle': IDLE,
    'ignore': IGNORE,
    'info': INFO,
    'InviteTracker': INVITETRACKER,
    'jiosaavn': JIOSAAVN,
    'king': KING,
    'land_yildiz': LAND_YILDIZ,
    'land_yildiz': LAND_YILDIZ_722475,
    'loading': LOADING,
    'Loading': LOADING_461233,
    'logging': LOGGING,
    'max__A': MAX__A,
    'mention': MENTION,
    'ml_cross': ML_CROSS,
    'mobile': MOBILE,
    'mod': MOD,
    'Moderation': MODERATION,
    'Module': MODULE,
    'music': MUSIC,
    'music': MUSIC_116319,
    'musicstop_icons': MUSICSTOP_ICONS,
    'next': NEXT,
    'offline': OFFLINE,
    'olympus_cross': OLYMPUS_CROSS,
    'olympus_notify': OLYMPUS_NOTIFY,
    'olympus_staff': OLYMPUS_STAFF,
    'olympus_tick': OLYMPUS_TICK,
    'olympusArrow': OLYMPUSARROW,
    'online': ONLINE,
    'owner': OWNER,
    'owner': OWNER_433185,
    'pc': PC,
    'premium': PREMIUM,
    'questions': QUESTIONS,
    'red_dot': RED_DOT,
    'RedHeart': REDHEART,
    'rewind1': REWIND1,
    'riverse_fun': RIVERSE_FUN,
    'security': SECURITY,
    'sg_rd': SG_RD,
    'shuffle': SHUFFLE,
    'skip': SKIP,
    'SoundCloud': SOUNDCLOUD,
    'sq_HeadMod': SQ_HEADMOD,
    'star': STAR,
    'Star': STAR_147803,
    'tick': TICK,
    'tick_red': TICK_RED,
    'ticket': TICKET,
    'timer': TIMER,
    'U_admin': U_ADMIN,
    'Uptime': UPTIME,
    'user': USER,
    'Utility': UTILITY,
    'VanityRoles': VANITYROLES,
    'voice': VOICE,
    'voice': VOICE_003466,
    'Warning': WARNING,
    'WarningIcon': WARNINGICON,
    'youtube': YOUTUBE,
    'YouTube': YOUTUBE_570841,
    'Ztick': ZTICK,
}

EMOJIS_BY_ID: dict[int, CustomEmoji] = {
    1273959128490049556: EMOJI_37496ALERT,
    1274766732786925750: EMOJI_7CLUB_BAN,
    1291476899557671054: ROSE,
    1330393356198477824: AUTOREACT,
    1330393358904066148: AUTOROLE,
    1228227536207740989: AXON_OWNER,
    1364125472539021352: BLUEDOT,
    1330393366373863526: BOTS,
    1329382931449516058: BROWSER,
    1329004882992300083: COMMANDS,
    1327829124894429235: CROSSICON,
    1330393383830683710: CUSTOMROLE,
    1287302832244129823: DC_REDCROWNESPORTS,
    1327842168693461022: DELETE,
    1294218790082711553: DENIED,
    1329022921427128321: DISABLED1,
    1329382206921248808: DND,
    1204107832232775730: ENABLED,
    1329022799708160063: ENABLED_160063,
    1330393380810657843: EXTRA,
    1330393371650297887: FILDER,
    1327842123906547713: FILE,
    1329361532999569439: FORWARD,
    1330393345796603924: GAMES,
    1329025929971896340: GEAR,
    1275850452323401789: GIFD,
    1275850451212042391: GIFN,
    1197061264271212605: GIVEAWAY,
    1330395924299644980: GIVEAWAY_644980,
    1351861871690645505: GIVEAWAYS,
    1330393349441585253: GREET,
    1274781954482376857: HEADMOD,
    1274781856406962250: HEART_EM,
    1274769360560328846: HEERIYE,
    1332569722801225749: HOME,
    1327842151962513515: ICON_BOOSTER,
    1327829337461882913: ICON_PING,
    1327829310962401331: ICONARROWRIGHT,
    1327829324518391824: ICONLOAD,
    1327829370881966092: ICONS_BOT,
    1327829380935843941: ICONS_CHANNEL,
    1327829391178338304: ICONS_DISCORDBOTDEV,
    1327829459729911900: ICONS_MUSIC,
    1327829470027055184: ICONS_NEXT,
    1327829480835780609: ICONS_PAUSE,
    1328966531140288524: ICONS_PLUS,
    1327829522573430864: ICONS_WARNING,
    1327842140570779658: ICONSETTING,
    1329382255046430740: IDLE,
    1330398849101205524: IGNORE,
    1374723970376405113: INFO,
    1392125185817051239: INVITETRACKER,
    1306976886047375430: JIOSAAVN,
    1234399917792034846: KING,
    1274766735702233089: LAND_YILDIZ,
    1274781969640722475: LAND_YILDIZ_722475,
    1246691973633671268: LOADING,
    1328740531907461233: LOADING_461233,
    1392124867872165969: LOGGING,
    1295014945641201685: MAX__A,
    1329408091011285113: MENTION,
    1204106928675102770: ML_CROSS,
    1329382816441569372: MOBILE,
    1327845044182585407: MOD,
    1330393377203556412: MODERATION,
    1330406766151860297: MODULE,
    1330393374271737896: MUSIC,
    1332620358255116319: MUSIC_116319,
    1327829536053923934: MUSICSTOP_ICONS,
    1327829548426854522: NEXT,
    1329382356804440107: OFFLINE,
    1227866668152393789: OLYMPUS_CROSS,
    1227866804630720565: OLYMPUS_NOTIFY,
    1228227884481515613: OLYMPUS_STAFF,
    1227866641027698792: OLYMPUS_TICK,
    1297341001341599797: OLYMPUSARROW,
    1329382084837507092: ONLINE,
    1272731689948287068: OWNER,
    1329041011984433185: OWNER_433185,
    1329382763161321524: PC,
    1204110058124873889: PREMIUM,
    1329005603669938236: QUESTIONS,
    1222796144996777995: RED_DOT,
    1272229548280512547: REDHEART,
    1329360839874056225: REWIND1,
    1327829569264160870: RIVERSE_FUN,
    1330393362305515560: SECURITY,
    1273974278433280122: SG_RD,
    1329360518367936564: SHUFFLE,
    1329359900563996754: SKIP,
    1307002774738829413: SOUNDCLOUD,
    1292538970500235366: SQ_HEADMOD,
    1251876754516349059: STAR,
    1273588820373147803: STAR_147803,
    1327829594954530896: TICK,
    1374052118020882563: TICK_RED,
    1355527347335467191: TICKET,
    1329404677820911697: TIMER,
    1327829252120510567: U_ADMIN,
    1368920252871737444: UPTIME,
    1329379728603353108: USER,
    1330393368894902272: UTILITY,
    1392125176644108359: VANITYROLES,
    1327841731651174450: VOICE,
    1330393386490003466: VOICE_003466,
    1299512982006665216: WARNING,
    1327829272697634937: WARNINGICON,
    1329365996959567893: YOUTUBE,
    1344680847315570841: YOUTUBE_570841,
    1222750301233090600: ZTICK,
}


def get(name: str) -> CustomEmoji:
    return EMOJIS[name]


def get_by_id(emoji_id: int) -> CustomEmoji:
    return EMOJIS_BY_ID[emoji_id]


def mention(name: str) -> str:
    return str(get(name))


def all_custom_emojis() -> tuple[CustomEmoji, ...]:
    return tuple(EMOJIS_BY_ID.values())


def _constant_emojis() -> dict[str, CustomEmoji]:
    return {
        name: value
        for name, value in globals().items()
        if name.isupper() and isinstance(value, CustomEmoji)
    }


def _rebuild_indexes() -> None:
    EMOJIS.clear()
    EMOJIS_BY_ID.clear()
    for emoji in _constant_emojis().values():
        EMOJIS[emoji.name] = emoji
        EMOJIS_BY_ID[emoji.id] = emoji


def apply_application_emojis(application_emojis: Iterable[object]) -> int:
    by_name = {
        str(getattr(emoji, "name")).lower(): emoji
        for emoji in application_emojis
        if getattr(emoji, "name", None) and getattr(emoji, "id", None)
    }
    updates = 0

    for constant_name, current in _constant_emojis().items():
        application_emoji = by_name.get(current.name.lower())
        if application_emoji is None:
            continue

        next_emoji = CustomEmoji(
            str(getattr(application_emoji, "name")),
            int(getattr(application_emoji, "id")),
            bool(getattr(application_emoji, "animated", False)),
        )
        if next_emoji != current:
            globals()[constant_name] = next_emoji
            updates += 1

    if updates:
        _rebuild_indexes()
    return updates


_rebuild_indexes()
