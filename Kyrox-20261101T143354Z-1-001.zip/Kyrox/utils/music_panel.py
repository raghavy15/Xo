"""
Kyrox music panel builders — Fynex-style Components V2 layout.

Now Playing card:
  [Section]  left: title + metadata   right: album art (Thumbnail accessory)
  [ActionRow] row 0: |< pause >| stop(red)
  [ActionRow] row 1: shuffle loop autoplay fav
"""
from __future__ import annotations

from typing import Any, Optional, Sequence

import discord

from utils.components_v2 import container, layout_view, separator, text

FOOTER_BRAND = "Kyrox"

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def format_duration(seconds: float) -> str:
    total = max(0, int(seconds))
    minutes, secs = divmod(total, 60)
    if minutes >= 60:
        hours, minutes = divmod(minutes, 60)
        return f"{hours}:{minutes:02d}:{secs:02d}"
    return f"{minutes}:{secs:02d}"


def format_duration_ms(ms: int | float) -> str:
    return format_duration((ms or 0) / 1000)


def kawaii_progress_bar(completed: float, total: float, *, length: int = 12) -> str:
    if total <= 0:
        return "\u2661 " + "\u2500" * length + " \u2661"
    ratio = max(0.0, min(1.0, completed / total))
    filled = int(length * ratio)
    if filled >= length:
        bar = "\u2501" * length
    else:
        bar = "\u2501" * filled + "\u25cb" + "\u2500" * max(0, length - filled - 1)
    return f"\u2661 {bar} \u2661"


def source_badge(source_name: str) -> str:
    badges = {
        "Spotify": "Spotify",
        "YouTube": "YouTube",
        "SoundCloud": "SoundCloud",
        "JioSaavn": "JioSaavn",
    }
    return badges.get(source_name, "Music")


def kawaii_footer(*, requested_by: str = "", autoplay: bool = False, extra: str = "") -> str:
    parts: list[str] = []
    if requested_by:
        suffix = " (autoplay mode~)" if autoplay else ""
        parts.append(f"\u2661 requested by **{requested_by}**{suffix}")
    if extra:
        parts.append(extra)
    parts.append(FOOTER_BRAND)
    return " \u00b7 ".join(parts)


def _track_title_line(track: Any) -> str:
    title = getattr(track, "title", "Unknown track") or "Unknown track"
    uri = getattr(track, "uri", None)
    safe = str(title).replace("[", "\\[").replace("]", "\\]")
    return f"**[{safe}]({uri})**" if uri else f"**{safe}**"


def _track_title_short(track: Any, max_len: int = 45) -> str:
    title = getattr(track, "title", "Unknown track") or "Unknown track"
    uri = getattr(track, "uri", None)
    display = title if len(title) <= max_len else title[:max_len - 3] + "..."
    safe = display.replace("[", "\\[").replace("]", "\\]")
    return f"[{safe}]({uri})" if uri else safe


def _artwork_url(track: Any) -> Optional[str]:
    url = getattr(track, "artwork_url", None) or getattr(track, "artwork", None)
    return str(url) if url else None


def _source_icon(source_name: str) -> str:
    from utils import emojis
    name = source_name.lower()
    if 'youtube' in name: return str(emojis.YOUTUBE)
    if 'soundcloud' in name: return str(emojis.SOUNDCLOUD)
    if 'jiosaavn' in name: return str(emojis.JIOSAAVN)
    return "<:zemojis_music:1527683319213592767>"


# ---------------------------------------------------------------------------
# "Track Added to Queue" view  — small card (no buttons)
# ---------------------------------------------------------------------------

def track_added_embed(
    track: Any,
    *,
    requested_by: str = "",
) -> discord.Embed:
    """Returns a plain Embed for the track-added notification."""
    source_name = getattr(track, "source_name", "YouTube")
    icon = _source_icon(source_name)
    title = getattr(track, "title", "Unknown track")
    uri = getattr(track, "uri", None)
    author = getattr(track, "author", "Unknown")
    duration = format_duration_ms(getattr(track, "length", 0) or 0)
    safe = str(title).replace("[", "\\[").replace("]", "\\]")
    track_link = f"**[{safe}]({uri})**" if uri else f"**{safe}**"

    desc = f"{icon} {track_link} - {author}\nDuration: `{duration}`"
    if requested_by:
        desc += f"\nRequested by {requested_by}"

    embed = discord.Embed(
        description=desc,
        color=0x2B2D31,
    )
    embed.set_author(name="Added to Queue")
    
    artwork = _artwork_url(track)
    if artwork:
        embed.set_thumbnail(url=artwork)
        
    return embed







# ---------------------------------------------------------------------------
# Now Playing full panel — Section with right-side thumbnail + button rows
# ---------------------------------------------------------------------------




class NowPlayingView(discord.ui.LayoutView):
    """
    Full Now Playing panel standard LayoutView for music playback controls.
    """

    def __init__(
        self,
        track: Any,
        player: Any,
        ctx: Any,
        *,
        source_name: str = "Unknown Source",
        requested_by: str = "",
        autoplay: bool = False,
        queue_length: int = 0,
    ) -> None:
        super().__init__(timeout=None)
        self.track = track
        self.player = player
        self.ctx = ctx
        
        
        from utils import emojis

        source_name = getattr(track, "source_name", source_name)
        icon = _source_icon(source_name)
        title = getattr(track, "title", "Unknown track")
        uri = getattr(track, "uri", None)
        author = getattr(track, "author", "Unknown")
        duration = format_duration_ms(getattr(track, "length", 0) or 0)
        safe = str(title).replace("[", "\\[").replace("]", "\\]")
        track_link = f"[{safe}]({uri})" if uri else safe
        
        played_by = f"{requested_by}" if requested_by else "Unknown"
        if autoplay:
            played_by += " *(autoplay)*"

        author_safe = str(author).replace("[", "\\[").replace("]", "\\]")
        desc = (
            f" > \u2022 **Author:** [{author_safe}]({uri})\n"
            f" > \u2022 **Duration:** `{duration}`\n"
            f" > \u2022 **Requester:** {played_by}"
        )
        
        artwork = _artwork_url(track)
        if not artwork:
            artwork = "https://images.unsplash.com/photo-1614613535308-eb5fbd3d2c17?q=80&w=200&auto=format&fit=crop"
            
        section = discord.ui.Section(
            f"## Now Playing: {track_link}",
            desc,
            accessory=discord.ui.Thumbnail(media=artwork)
        )

        # Row 0: transport controls
        btn_prev = discord.ui.Button(
            emoji="<:m_previous:1528037913017979050>",
            style=discord.ButtonStyle.secondary,
            custom_id="np_prev",
        )
        btn_prev.callback = self._prev_cb

        self._pause_btn = discord.ui.Button(
            emoji="<:pause:1528037906713804932>" if not getattr(self.player, "paused", False) else "<:play:1528037921276297449>",
            style=discord.ButtonStyle.secondary,
            custom_id="np_pause",
        )
        self._pause_btn.callback = self._pause_cb

        btn_skip = discord.ui.Button(
            emoji="<:next:1528037902645465158>",
            style=discord.ButtonStyle.secondary,
            custom_id="np_skip",
        )
        btn_skip.callback = self._skip_cb

        btn_stop = discord.ui.Button(
            emoji="<:whitesquare:1528037915320385698>",
            style=discord.ButtonStyle.danger,
            custom_id="np_stop",
        )
        btn_stop.callback = self._stop_cb

        # Row 1: extra controls
        self._loop_btn = discord.ui.Button(
            label="Loop",
            emoji="<:autoplay:1528037910832746506>",
            style=discord.ButtonStyle.success if getattr(self.player, "loop", 0) == getattr(self.player, "LOOP_QUEUE", 2) else (discord.ButtonStyle.primary if getattr(self.player, "loop", 0) == getattr(self.player, "LOOP_SINGLE", 1) else discord.ButtonStyle.secondary),
            custom_id="np_loop",
        )
        self._loop_btn.callback = self._loop_cb

        self._auto_btn = discord.ui.Button(
            label="Autoplay",
            emoji="<:queue:1528037927186075668>",
            style=discord.ButtonStyle.primary if getattr(self.player, "autoplay", False) else discord.ButtonStyle.secondary,
            custom_id="np_auto",
        )
        self._auto_btn.callback = self._auto_cb

        row0 = discord.ui.ActionRow(btn_prev, self._pause_btn, btn_skip, btn_stop)
        row1 = discord.ui.ActionRow(self._loop_btn, self._auto_btn)

        container = discord.ui.Container(section, separator(), row0, row1)
        self.add_item(container)

    # ------------------------------------------------------------------
    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if not self.ctx.voice_client or not self.player.is_playing:
            await interaction.response.send_message(
                "I'm not playing anything anymore.", ephemeral=True
            )
            return False
        if interaction.user in self.ctx.voice_client.channel.members:
            return True
        await interaction.response.send_message(
            "\u2661 Join my voice channel to use player controls.", ephemeral=True
        )
        return False

    # ------------------------------------------------------------------
    async def _prev_cb(self, interaction: discord.Interaction):
        await self.player.seek(0)
        await interaction.response.send_message("Replaying from the start.", ephemeral=True)

    async def _pause_cb(self, interaction: discord.Interaction):
        from utils import emojis
        if self.player.paused:
            await self.player.set_pause(False)
            self._pause_btn.emoji = "<:pause:1528037906713804932>"
        else:
            await self.player.set_pause(True)
            self._pause_btn.emoji = "<:play:1528037921276297449>"
        await interaction.response.edit_message(view=self)

    async def _skip_cb(self, interaction: discord.Interaction):
        await self.player.skip()
        await interaction.response.send_message("Skipped.", ephemeral=True)

    async def _stop_cb(self, interaction: discord.Interaction):
        self.player.queue.clear()
        await self.player.stop()
        await self.ctx.voice_client.disconnect(force=True)
        await interaction.response.send_message("Stopped and disconnected.", ephemeral=True)

    async def _loop_cb(self, interaction: discord.Interaction):
        if self.player.loop == self.player.LOOP_NONE:
            self.player.loop = self.player.LOOP_SINGLE
            self._loop_btn.style = discord.ButtonStyle.primary
        elif self.player.loop == self.player.LOOP_SINGLE:
            self.player.loop = self.player.LOOP_QUEUE
            self._loop_btn.style = discord.ButtonStyle.success
        else:
            self.player.loop = self.player.LOOP_NONE
            self._loop_btn.style = discord.ButtonStyle.secondary
        await interaction.response.edit_message(view=self)

    async def _auto_cb(self, interaction: discord.Interaction):
        cur = getattr(self.player, "autoplay", False)
        self.player.autoplay = not cur
        self._auto_btn.style = (
            discord.ButtonStyle.primary if self.player.autoplay
            else discord.ButtonStyle.secondary
        )
        await interaction.response.edit_message(view=self)


# ---------------------------------------------------------------------------
# Thin wrappers used by old call sites in music.py
# ---------------------------------------------------------------------------

def player_layout_view(
    embed: discord.Embed,
    controls: discord.ui.View,
    *,
    timeout: Optional[float] = None,
) -> discord.ui.LayoutView:
    """Legacy shim — wraps an embed+view via cv2_compat."""
    from utils.cv2_compat import panel_with_actions
    return panel_with_actions(embed, controls, timeout=timeout)


def player_embed(
    track: Any,
    *,
    source_name: str = "Unknown Source",
    source_link: str = "",
    requested_by: str = "",
    autoplay: bool = False,
    queue_length: int = 0,
    volume: int = 100,
) -> discord.Embed:
    """Legacy embed kept for callers that still use embed_to_view path."""
    duration = format_duration_ms(getattr(track, "length", 0) or 0)
    author = getattr(track, "author", "Unknown") or "Unknown"
    icon = _source_icon(source_name)
    embed = discord.Embed(
        title=f"{icon} Now Playing",
        description=(
            f"{_track_title_line(track)}\n"
            f"Duration: {duration}\n"
            f"Author: {author}\n"
            f"Played by: @{requested_by}"
            + (" *(autoplay)*" if autoplay else "")
        ),
        color=0x2B2D31,
    )
    artwork = _artwork_url(track)
    if artwork:
        embed.set_thumbnail(url=artwork)
    return embed


def now_playing_embed(
    track: Any,
    *,
    source_name: str = "Unknown Source",
    requested_by: str = "",
    autoplay: bool = False,
    **kwargs
) -> discord.Embed:
    source_name = getattr(track, "source_name", source_name)
    icon = _source_icon(source_name)
    title = getattr(track, "title", "Unknown track")
    uri = getattr(track, "uri", None)
    author = getattr(track, "author", "Unknown")
    duration = format_duration_ms(getattr(track, "length", 0) or 0)
    
    safe = str(title).replace("[", "\\[").replace("]", "\\]")
    track_link = f"**[{safe}]({uri})**" if uri else f"**{safe}**"

    played_by = f"({requested_by})" if requested_by else "(Unknown)"
    if autoplay:
        played_by += " *(autoplay)*"

    desc = f"{icon} {track_link} - {author}\nDuration: `{duration}`\nRequested by {played_by}"

    embed = discord.Embed(
        description=desc,
        color=0x2B2D31,
    )
    embed.set_author(name="Now Playing")
    
    artwork = _artwork_url(track)
    if artwork:
        embed.set_thumbnail(url=artwork)
        
    return embed


# ---------------------------------------------------------------------------
# Toast / guard messages
# ---------------------------------------------------------------------------

def music_toast(
    message: str,
    *,
    title: str = "",
    tone: str = "info",
) -> discord.ui.LayoutView:
    _TOAST_TITLES = {
        "success": "Done",
        "error": "Error",
        "warning": "Notice",
        "info": "Music",
        "added": "Queued",
    }
    icons = {
        "success": "\u2705",
        "error": "\u274c",
        "warning": "\u26a0\ufe0f",
        "info": "\u2661",
        "added": "\u2661",
    }
    icon = icons.get(tone, "\u2661")
    header = title or _TOAST_TITLES.get(tone, "Music")
    from utils.components_v2 import container as _container, layout_view as _lv, separator as _sep, text as _text
    return _lv(
        _container(
            _text(f"## {icon} {header}"),
            _sep(visible=False),
            _text(message),
            _sep(),
            _text(f"-# {FOOTER_BRAND}"),
        ),
        timeout=90,
    )


def guard_no_voice() -> discord.ui.LayoutView:
    return music_toast("Join a voice channel first.", tone="warning")


def guard_same_channel() -> discord.ui.LayoutView:
    return music_toast("You need to be in my voice channel.", tone="warning")


def guard_not_playing() -> discord.ui.LayoutView:
    return music_toast("Nothing is playing right now.", tone="warning")


def guard_not_connected() -> discord.ui.LayoutView:
    return music_toast("I'm not connected to a voice channel.", tone="warning")


def guard_no_results() -> discord.ui.LayoutView:
    return music_toast("No results found \u2014 try a different search.", tone="error")


def guard_empty_queue() -> discord.ui.LayoutView:
    return music_toast("The queue is empty. Use `>play` to add songs.", tone="warning")


# ---------------------------------------------------------------------------
# Queue / misc embeds
# ---------------------------------------------------------------------------

def search_results_embed(query: str, source: str, tracks: Sequence[Any]) -> discord.Embed:
    platform = source.replace("search", "").upper() or "MUSIC"
    lines = []
    for index, track in enumerate(tracks, start=1):
        duration = format_duration_ms(getattr(track, "length", 0) or 0)
        lines.append(
            f"`{index}.` {_track_title_line(track)}\n"
            f"> `{getattr(track, 'author', 'Unknown')}` \u00b7 `{duration}`"
        )
    embed = discord.Embed(
        title="Search Results",
        description=(
            f"*Results for* **{query}** *on* **{platform}**\n"
            f"\u2661 tap a number below to play\n\n" + "\n\n".join(lines)
        ),
        color=0xFFD1DC,
    )
    embed.set_footer(text="\u2661 pick a track below \u00b7 " + FOOTER_BRAND)
    return embed


def platform_select_embed(query: str) -> discord.Embed:
    return discord.Embed(
        title="Choose a Platform",
        description=(
            f"*Searching for* **{query}**\n\n"
            "YouTube \u2014 videos & covers\n"
            "JioSaavn \u2014 regional hits\n"
            "SoundCloud \u2014 indie & remixes\n\n"
            "\u2661 pick where to search"
        ),
        color=0xFFB6C1,
    )


def queue_embed(
    entries: Sequence[str],
    *,
    page: int = 0,
    total_pages: int = 1,
    now_playing: Optional[Any] = None,
) -> discord.Embed:
    body = "\n".join(entries) if entries else "*nothing queued yet~*"
    description = f"\u2661 **Page {page + 1}/{total_pages}**\n\n{body}"
    if now_playing is not None:
        description = (
            f"**Now spinning~**\n{_track_title_line(now_playing)}\n\n"
            f"**Coming up next**\n{body}"
        )
    embed = discord.Embed(title="Song Queue", description=description, color=0xF8C8DC)
    embed.set_footer(text="\u2661 upcoming tracks \u00b7 " + FOOTER_BRAND)
    return embed


def queue_entry_line(index: int, track: Any) -> str:
    duration = format_duration_ms(getattr(track, "length", 0) or 0)
    return (
        f"`{index:02d}.` {_track_title_line(track)}\n"
        f"> `{getattr(track, 'author', 'Unknown')}` \u00b7 `{duration}`"
    )


def queue_ended_embed() -> discord.Embed:
    return discord.Embed(
        title="Queue Finished",
        description=(
            "All songs finished~ I'm heading out of voice now.\n\n"
            "\u2661 thanks for vibing with Kyrox!"
        ),
        color=0xFFB7C5,
    )


def inactivity_embed() -> discord.Embed:
    return discord.Embed(
        title="Idle Timeout",
        description=(
            "I was alone in voice for 2 minutes~\n"
            "Disconnected to save resources. Join me again anytime!"
        ),
        color=0xFFC0CB,
    )


def lavalink_offline_embed(warning_emoji: str) -> discord.Embed:
    return discord.Embed(
        title="Music Offline",
        description=(
            f"{warning_emoji} Music can't connect to Lavalink right now.\n"
            "Set `LAVALINK_URI` and `LAVALINK_PASSWORD` in `.env`, then restart the bot."
        ),
        color=0xFF8FAB,
    )


def kawaii_queue_page_source(
    entries: Sequence[str],
    *,
    per_page: int = 5,
    now_playing: Any = None,
    requested_by: str = "",
):
    from discord.ext import menus

    class _Source(menus.ListPageSource):
        def __init__(self) -> None:
            super().__init__(list(entries), per_page=per_page)
            self._np = now_playing
            self._by = requested_by

        async def format_page(self, menu, page_entries) -> discord.Embed:
            maximum = self.get_max_pages() or 1
            embed = queue_embed(
                list(page_entries),
                page=menu.current_page,
                total_pages=maximum,
                now_playing=self._np if menu.current_page == 0 else None,
            )
            if self._by:
                pg = f"page {menu.current_page + 1}/{maximum} \u00b7 " if maximum > 1 else ""
                embed.set_footer(text=f"\u2661 {pg}requested by **{self._by}** \u00b7 {FOOTER_BRAND}")
            return embed

    return _Source()
