from __future__ import annotations

import logging
from typing import Any
from contextlib import asynccontextmanager

from db._db import Database

log = logging.getLogger(__name__)

async def get_db():
    """Return the motor database instance."""
    return await Database().ensure_connection()

async def get_collection(name: str):
    """Return a motor collection instance."""
    db = await get_db()
    return db[name]

class MockCursor:
    def __init__(self, data=None):
        self._data = data or []
        self.rowcount = 1
    async def fetchone(self):
        return self._data[0] if self._data else None
    async def fetchall(self):
        return self._data
    async def __aenter__(self):
        return self
    async def __aexit__(self, exc_type, exc, tb):
        pass
    def __await__(self):
        async def _awaitable():
            return self
        return _awaitable().__await__()
    def execute(self, query: str, parameters: tuple = ()):
        return self
    def __aiter__(self):
        self._iter_index = 0
        return self
    async def __anext__(self):
        if self._iter_index < len(self._data):
            val = self._data[self._iter_index]
            self._iter_index += 1
            return val
        raise StopAsyncIteration
    async def close(self):
        pass

class MockSQLiteDB:
    def __init__(self, name):
        self.name = name
    def execute(self, query: str, parameters: tuple = ()) -> MockCursor:
        return MockCursor()
    async def executescript(self, query: str) -> None:
        pass
    async def cursor(self) -> MockCursor:
        return MockCursor()
    async def commit(self):
        pass
    async def close(self):
        pass
    async def __aenter__(self):
        return self
    async def __aexit__(self, exc_type, exc, tb):
        pass

@asynccontextmanager
async def connect(
    name: str,
    *,
    timeout: float = 30.0,
    wal: bool = True,
):
    """Mock connect to prevent ImportError and runtime crashes in unmigrated cogs."""
    yield MockSQLiteDB(name)

async def execute_many(name: str, statements: list[str]) -> None:
    pass

async def open_connection(
    name: str,
    *,
    timeout: float = 30.0,
    wal: bool = True,
):
    return MockSQLiteDB(name)

async def get_anti_db():
    """Return the shared singleton collection for anti."""
    return MockSQLiteDB("anti")

async def close_shared_databases() -> None:
    """Close long-lived shared database handles."""
    await Database().close()