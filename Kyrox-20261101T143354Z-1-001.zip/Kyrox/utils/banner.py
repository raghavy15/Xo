import io
from PIL import Image, ImageDraw, ImageFont, ImageFilter

def generate_help_banner(avatar_bytes=None, name="KyroX", subtitle="", dev="Krishna.xyz"):
    width = 900
    height = 250
    bg_color = (15, 0, 15)
    
    # Create base image
    img = Image.new('RGB', (width, height), bg_color)
    draw = ImageDraw.Draw(img)
    
    # Draw faint grid
    grid_color = (35, 0, 30)
    for x in range(0, width, 30):
        draw.line([(x, 0), (x, height)], fill=grid_color, width=1)
    for y in range(0, height, 30):
        draw.line([(0, y), (width, y)], fill=grid_color, width=1)
        
    # Process avatar if provided
    if avatar_bytes:
        try:
            avatar = Image.open(io.BytesIO(avatar_bytes)).convert("RGBA")
            avatar = avatar.resize((180, 180))
            
            # Create a circular mask
            mask = Image.new('L', (180, 180), 0)
            mask_draw = ImageDraw.Draw(mask)
            mask_draw.ellipse((0, 0, 180, 180), fill=255)
            
            avatar.putalpha(mask)
            
            # Paste avatar onto background
            img.paste(avatar, (40, 35), avatar)
            
            # Draw neon ring around avatar
            ring_color = (255, 20, 147)  # Deep Pink
            draw.ellipse((35, 30, 225, 220), outline=ring_color, width=4)
            # Add dashed outer ring
            draw.arc((25, 20, 235, 230), start=0, end=360, fill=(255, 105, 180), width=1)
        except Exception as e:
            print(f"Failed to process banner avatar: {e}")
            
    # Define fonts (fallback to default if arial is missing)
    try:
        font_title = ImageFont.truetype("arialbd.ttf", 70)
        font_sub = ImageFont.truetype("arialbd.ttf", 26)
        font_mini = ImageFont.truetype("arialbd.ttf", 16)
    except IOError:
        try:
            font_title = ImageFont.truetype("arial.ttf", 70)
            font_sub = ImageFont.truetype("arial.ttf", 26)
            font_mini = ImageFont.truetype("arial.ttf", 16)
        except IOError:
            font_title = ImageFont.load_default()
            font_sub = ImageFont.load_default()
            font_mini = ImageFont.load_default()
        
    text_x = 280
    
    # Draw texts
    draw.text((text_x, 30), name.upper(), font=font_mini, fill=(180, 180, 180))
    
    # Drop shadow for title
    draw.text((text_x+3, 60+3), "HELP  MENU", font=font_title, fill=(255, 20, 147))
    draw.text((text_x, 60), "HELP  MENU", font=font_title, fill=(255, 255, 255))
    
    draw.text((text_x, 150), subtitle, font=font_sub, fill=(255, 20, 147))
    draw.text((text_x, 200), f"DEVELOPED BY  {dev}", font=font_mini, fill=(180, 180, 180))
    
    # Save to buffer
    buf = io.BytesIO()
    img.save(buf, format='PNG')
    buf.seek(0)
    return buf

def generate_stats_banner(avatar_bytes=None, name="KyroX", subtitle="BOT PERFORMANCE METRICS", m1_title="", m1_val="", m1_pct=0.5, m2_title="", m2_val="", m2_pct=0.5):
    import math
    from PIL import ImageOps
    width = 900
    height = 250
    
    try:
        bg = Image.open(r"\assets\images\cool-aesthetic-cloud-05bsl7m2e5bh01ki.jpg").convert('RGBA')
        img = ImageOps.fit(bg, (width, height), Image.Resampling.LANCZOS)
    except Exception as e:
        bg_color = (15, 0, 15)
        img = Image.new('RGBA', (width, height), bg_color)
        
    draw = ImageDraw.Draw(img, 'RGBA')
    
    # Optional dark overlay to make text pop against bright clouds
    overlay = Image.new('RGBA', (width, height), (0, 0, 0, 90))
    img = Image.alpha_composite(img, overlay)
    draw = ImageDraw.Draw(img, 'RGBA')

    # Process avatar
    if avatar_bytes:
        try:
            avatar = Image.open(io.BytesIO(avatar_bytes)).convert("RGBA")
            avatar = avatar.resize((180, 180))
            mask = Image.new('L', (180, 180), 0)
            mask_draw = ImageDraw.Draw(mask)
            mask_draw.ellipse((0, 0, 180, 180), fill=255)
            avatar.putalpha(mask)
            img.paste(avatar, (40, 35), avatar)
            
            # Rings
            ring_pink = (255, 20, 147)
            ring_cyan = (0, 255, 255)
            draw.arc((35, 30, 225, 220), start=180, end=360, fill=ring_pink, width=4)
            draw.arc((35, 30, 225, 220), start=0, end=180, fill=ring_cyan, width=4)
        except Exception as e:
            pass
            
    # Fonts
    try:
        font_title = ImageFont.truetype("arialbd.ttf", 45)
        font_sub = ImageFont.truetype("arial.ttf", 20)
        font_micro = ImageFont.truetype("arialbd.ttf", 14)
    except IOError:
        font_title = font_sub = font_micro = ImageFont.load_default()
        
    text_x = 280
    
    # Text
    draw.text((text_x, 30), f"{name} Dashboard", font=font_title, fill=(255, 255, 255))
    draw.text((text_x, 80), subtitle, font=font_sub, fill=(180, 180, 180))
    
    # Graphs Area
    g_y = 130
    g_w = 260
    g_h = 80
    
    # Graph 1 (Pink)
    x1 = text_x
    draw.text((x1, g_y), m1_title.upper(), font=font_micro, fill=(255, 20, 147))
    draw.text((x1 + g_w - 60, g_y), m1_val, font=font_micro, fill=(255, 255, 255))
    
    # Draw Pink Curve
    pts1 = []
    for i in range(g_w):
        # A simple sine wave to look like a graph curve
        t = i / g_w
        val = (math.sin(t * math.pi * 1.5) * 0.3 + t * 0.7) * m1_pct
        px = x1 + i
        py = g_y + g_h - (val * g_h)
        pts1.append((px, py))
    draw.line(pts1, fill=(255, 20, 147), width=3)
    draw.ellipse((pts1[-1][0]-4, pts1[-1][1]-4, pts1[-1][0]+4, pts1[-1][1]+4), fill=(255, 20, 147))
    
    # Graph 2 (Cyan)
    x2 = text_x + g_w + 40
    draw.text((x2, g_y), m2_title.upper(), font=font_micro, fill=(0, 255, 255))
    draw.text((x2 + g_w - 60, g_y), m2_val, font=font_micro, fill=(255, 255, 255))
    
    # Draw Cyan Curve
    pts2 = []
    for i in range(g_w):
        t = i / g_w
        val = (1 - math.exp(-t * 3)) * m2_pct # another math curve
        px = x2 + i
        py = g_y + g_h - (val * g_h)
        pts2.append((px, py))
    draw.line(pts2, fill=(0, 255, 255), width=3)
    draw.ellipse((pts2[-1][0]-4, pts2[-1][1]-4, pts2[-1][0]+4, pts2[-1][1]+4), fill=(0, 255, 255))
    
    buf = io.BytesIO()
    img.save(buf, format='PNG')
    buf.seek(0)
    return buf
