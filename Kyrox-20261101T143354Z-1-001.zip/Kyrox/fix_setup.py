import re

file_path = r'c:\Users\vaish\OneDrive\Desktop\Codes\Kyrox\cogs\commands\music.py'
with open(file_path, 'r', encoding='utf-8') as f:
    content = f.read()

setup_replacement = """
async def setup(client):
    from helpers.lavalink_client import setup_lavalink
    if not hasattr(client, 'lavalink'):
        await setup_lavalink(client)
    await client.add_cog(Music(client))
"""

content = re.sub(
    r'async def setup\(client\):\n\s*await client\.add_cog\(Music\(client\)\)',
    setup_replacement.strip(),
    content
)

with open(file_path, 'w', encoding='utf-8') as f:
    f.write(content)
print('Fixed setup function')
