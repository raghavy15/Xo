from __future__ import annotations

import asyncio
import logging
from typing import Callable, Optional, TypeVar

from motor.motor_asyncio import AsyncIOMotorClient
import certifi

from utils.config import MONGO_URI

log = logging.getLogger(__name__)
T = TypeVar("T")

class Database:
    _instance: Optional["Database"] = None
    _lock: asyncio.Lock
    client: Optional[AsyncIOMotorClient] = None
    db_name: str = "kyrox"

    def __new__(cls, db_name: str = "kyrox"):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance.db_name = db_name
            cls._instance.client = None
            cls._instance._lock = asyncio.Lock()
        return cls._instance

    async def connect(self) -> AsyncIOMotorClient:
        async with self._lock:
            if self.client is None:
                if not MONGO_URI:
                    log.error("MONGO_URI is not set in environment variables.")
                    raise ValueError("MONGO_URI is not set.")
                self.client = AsyncIOMotorClient(MONGO_URI, tlsCAFile=certifi.where())
                log.info("Connected to MongoDB Atlas.")
        return self.client

    async def ensure_connection(self):
        if self.client is None:
            await self.connect()
        return self.client[self.db_name]

    async def get_collection(self, collection_name: str):
        db = await self.ensure_connection()
        return db[collection_name]

    async def execute_with_retries(
        self,
        func: Callable[[], T],
        retries: int = 5,
        delay: float = 1,
    ) -> T:
        # MongoDB handles retries natively for most operations, 
        # but kept this for backward compatibility.
        for attempt in range(retries):
            try:
                return await func()
            except Exception as exc:
                sleep_time = delay * (2 ** attempt)
                log.warning(f"Database operation failed: {exc} — retrying in {sleep_time:.2f}s")
                await asyncio.sleep(sleep_time)
        raise RuntimeError("Database operation failed after max retries.")

    async def close(self) -> None:
        async with self._lock:
            if self.client is not None:
                self.client.close()
                self.client = None
                log.info("Closed MongoDB connection.")