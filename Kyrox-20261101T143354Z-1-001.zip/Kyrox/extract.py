﻿import zipfile
import os

zip_path = r'C:\Users\vaish\OneDrive\Desktop\Codes\Kyrox.zip'
target_file = 'Kyrox/cogs/commands/music.py' # It could be inside a 'Kyrox' folder or not
dest_path = r'C:\Users\vaish\OneDrive\Desktop\Codes\Kyrox\cogs\commands\music.py'

with zipfile.ZipFile(zip_path, 'r') as zip_ref:
    # Find music.py in the zip
    music_file_info = None
    for info in zip_ref.infolist():
        if info.filename.endswith('cogs/commands/music.py'):
            music_file_info = info
            break
    
    if music_file_info:
        with zip_ref.open(music_file_info) as src, open(dest_path, 'wb') as dst:
            dst.write(src.read())
        print(f"Restored {music_file_info.filename} to {dest_path}")
    else:
        print("music.py not found in zip!")
