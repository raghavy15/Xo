import re

file_path = r'c:\Users\vaish\OneDrive\Desktop\Codes\Kyrox\cogs\commands\music.py'
with open(file_path, 'r', encoding='utf-8') as f:
    content = f.read()

content = re.sub(r'\{emojis\.get\("(.*?)"\)\}', r"{emojis.get('\1')}", content)

with open(file_path, 'w', encoding='utf-8') as f:
    f.write(content)
print('Fixed quotes')
