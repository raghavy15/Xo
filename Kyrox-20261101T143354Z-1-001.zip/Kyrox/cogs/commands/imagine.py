import discord
from discord.ext import commands
from discord import app_commands
import aiohttp
import asyncio
import random
import time
from utils.ai_utils import poly_image_gen, generate_image_prodia
from enum import Enum

class Model(Enum):
    ANALOG = ("analog-diffusion-1.0.ckpt [9ca13f02]", "Analog V1", "01")
    ANYTHING_V3 = ("anythingv3_0-pruned.ckpt [2700c435]", "Anything V3", "02")
    ANYTHING_V4 = ("anything-v4.5-pruned.ckpt [65745d25]", "Anything V4.5", "03")
    ABYSSORANGEMIX = ("AOM3A3_orangemixs.safetensors [9600da17]", "AbyssOrangeMix V3", "04")
    DELIBERATE = ("deliberate_v2.safetensors [10ec4b29]", "Deliberate V2", "05")
    DREAMLIKE_V1 = ("dreamlike-diffusion-1.0.safetensors [5c9fd6e0]", "Dreamlike Diffusion V1", "06")
    DREAMLIKE_V2 = ("dreamlike-diffusion-2.0.safetensors [fdcf65e7]", "Dreamlike Diffusion V2", "07")
    DREAMSHAPER_5 = ("dreamshaper_5BakedVae.safetensors [a3fbf318]", "Dreamshaper 5 baked vae", "08")
    DREAMSHAPER_6 = ("dreamshaper_6BakedVae.safetensors [114c8abb]", "Dreamshaper 6 baked vae", "09")
    ELLDRETHVIVIDMIX = ("elldreths-vivid-mix.safetensors [342d9d26]", "Elldreth's Vivid", "10")
    LYRIEL_V15 = ("lyriel_v15.safetensors [65d547c5]", "Lyriel V1.5", "11")
    LYRIEL_V16 = ("lyriel_v16.safetensors [68fceea2]", "Lyriel V1.6", "12")
    MECHAMIX = ("mechamix_v10.safetensors [ee685731]", "MechaMix V1.0", "13")
    MEINAMIX = ("meinamix_meinaV9.safetensors [2ec66ab0]", "MeinaMix V9", "14")
    OPENJOURNEY = ("openjourney_V4.ckpt [ca2f377f]", "Openjourney V4", "15")
    PORTRAIT = ("portrait+1.0.safetensors [1400e684]", "Portrait V1", "16")
    REALISTICVS_V14 = ("Realistic_Vision_V1.4-pruned-fp16.safetensors [8d21810b]", "Realistic Vision V1.4", "17")
    REALISTICVS_V20 = ("Realistic_Vision_V2.0.safetensors [79587710]", "Realistic Vision V2.0", "18")
    REV_ANIMATED = ("revAnimated_v122.safetensors [3f4fefd9]", "ReV Animated V1.2.2", "19")
    RIFFUSION = ("riffusion-model-v1.ckpt [3aafa6fe]", "Riffusion V1", "20")
    SD_V14 = ("sdv1_4.ckpt [7460a6fa]", "Stable Diffusion V1.4", "21")
    SD_V15 = ("v1-5-pruned-emaonly.ckpt [81761151]", "Stable Diffusion V1.5", "22")
    SBP = ("shoninsBeautiful_v10.safetensors [25d8c546]", "Shonin's Beautiful People V1.0", "23")
    THEALLYSMIX = ("theallys-mix-ii-churned.safetensors [5d9225a4]", "TheAlly's Mix II", "24")
    TIMELESS = ("timeless-1.0.ckpt [7c4971d4]", "Timeless V1", "25")

from utils.Tools import *
from utils.cv2_compat import embed_to_view, embeds_to_view

blacklisted_words = [
    "naked", "nude", "nudes", "teen", "gay", "lesbian", "porn", "xnxx",
    "bitch", "loli", "hentai", "explicit", "pornography", "adult", "XXX",
    "sex", "erotic", "dick", "vagina", "pussy", "gay", "lick", "creampie", "nsfw",
    "hardcore", "ass", "anal", "anus", "boobs", "tits", "cum", "cunnilingus", "squirt", "penis", "lick", "masturbate", "masturbation ", "orgasm", "orgy", "fap", "fapping", "fuck", "fucking", "handjob", "cowgirl", "doggystyle", "blowjob", "boobjob", "boobies", "horny", "nudity"
]

blocked=["minor", "minors", "kid", "kids", "child", "children", "baby", "babies", "toddler", "childporn", "todd", "underage"]

class CooldownManager:
    def __init__(self, rate: int, per: float):
        self.rate = rate
        self.per = per
        self.cooldowns = {}

    def check_cooldown(self, user_id: int):
        now = time.time()
        if user_id not in self.cooldowns:
            self.cooldowns[user_id] = [now]
            return None

        self.cooldowns[user_id] = [timestamp for timestamp in self.cooldowns[user_id] if now - timestamp < self.per]
        if len(self.cooldowns[user_id]) >= self.rate:
            retry_after = self.per - (now - self.cooldowns[user_id][0])
            return retry_after
        self.cooldowns[user_id].append(now)
        return None

cooldown_manager = CooldownManager(rate=1, per=60.0)

async def cooldown_check(interaction: discord.Interaction):
    retry_after = cooldown_manager.check_cooldown(interaction.user.id)
    if retry_after:
        await interaction.response.send_message(f"You are on cooldown. Try again in {retry_after:.2f} seconds.", ephemeral=True)
        return False
    return True





class AiStuffCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.guild_only()
    @app_commands.command(name="imagine", description="Generate an image using AI")

    #@app_commands.check(blacklist_check())
    #@app_commands.check(ignore_check())
    #@app_commands.check(cooldown_check)
    @discord.app_commands.choices(
        model=[
            discord.app_commands.Choice(name='âœ¨ Elldreth vivid mix (Landscapes, Stylized characters, nsfw)', value='ELLDRETHVIVIDMIX'),
            discord.app_commands.Choice(name='ðŸ’ª Deliberate v2 (Anything you want, nsfw)', value='DELIBERATE'),
            discord.app_commands.Choice(name='ðŸ”® Dreamshaper (HOLYSHIT this so good)', value='DREAMSHAPER_6'),
            discord.app_commands.Choice(name='ðŸŽ¼ Lyriel', value='LYRIEL_V16'),
            discord.app_commands.Choice(name='ðŸ’¥ Anything diffusion (Good for anime)', value='ANYTHING_V4'),
            discord.app_commands.Choice(name='ðŸŒ… Openjourney (Midjourney alternative)', value='OPENJOURNEY'),
            discord.app_commands.Choice(name='ðŸžï¸ Realistic (Lifelike pictures)', value='REALISTICVS_V20'),
            discord.app_commands.Choice(name='ðŸ‘¨â€ðŸŽ¨ Portrait (For headshots I guess)', value='PORTRAIT'),
            discord.app_commands.Choice(name='ðŸŒŸ Rev animated (Illustration, Anime)', value='REV_ANIMATED'),
            discord.app_commands.Choice(name='ðŸ¤– Analog', value='ANALOG'),
            discord.app_commands.Choice(name='ðŸŒŒ AbyssOrangeMix', value='ABYSSORANGEMIX'),
            discord.app_commands.Choice(name='ðŸŒŒ Dreamlike v1', value='DREAMLIKE_V1'),
            discord.app_commands.Choice(name='ðŸŒŒ Dreamlike v2', value='DREAMLIKE_V2'),
            discord.app_commands.Choice(name='ðŸŒŒ Dreamshaper 5', value='DREAMSHAPER_5'),
            discord.app_commands.Choice(name='ðŸŒŒ MechaMix', value='MECHAMIX'),
            discord.app_commands.Choice(name='ðŸŒŒ MeinaMix', value='MEINAMIX'),
            discord.app_commands.Choice(name='ðŸŒŒ Stable Diffusion v14', value='SD_V14'),
            discord.app_commands.Choice(name='ðŸŒŒ Stable Diffusion v15', value='SD_V15'),
            discord.app_commands.Choice(name="ðŸŒŒ Shonin's Beautiful People", value='SBP'),
            discord.app_commands.Choice(name="ðŸŒŒ TheAlly's Mix II", value='THEALLYSMIX'),
            discord.app_commands.Choice(name='ðŸŒŒ Timeless', value='TIMELESS')
        ],
        sampler=[
            discord.app_commands.Choice(name='ðŸ“ Euler (Recommended)', value='Euler'),
            discord.app_commands.Choice(name='ðŸ“ Euler a', value='Euler a'),
            discord.app_commands.Choice(name='ðŸ“ Heun', value='Heun'),
            discord.app_commands.Choice(name='ðŸ’¥ DPM++ 2M Karras', value='DPM++ 2M Karras'),
            discord.app_commands.Choice(name='ðŸ’¥ DPM++ SDE Karras', value='DPM++ SDE Karras'),
            discord.app_commands.Choice(name='ðŸ” DDIM', value='DDIM')
        ]
    )
    @discord.app_commands.describe(
        prompt="Write an amazing prompt for an image",
        model="Model to generate image",
        sampler="Sampler for denoising",
        negative="Prompt that specifies what you do not want the model to generate",
    )
    async def imagine(self, interaction: discord.Interaction, prompt: str, model: discord.app_commands.Choice[str], sampler: discord.app_commands.Choice[str], negative: str = None, seed: int = None):
        retry_after = cooldown_manager.check_cooldown(interaction.user.id)
        if retry_after:
            await interaction.response.send_message(f"You are on cooldown. Try again in {retry_after:.2f} seconds.", ephemeral=True)
            return

        await interaction.response.defer()

        is_nsfw = any(word in prompt.lower() for word in blacklisted_words)

        is_child = any(word in prompt.lower() for word in blocked)

        if is_child:
            await interaction.followup.send("Child porn is not allowed as it violates Discord ToS. Please try again with a different peompt.")
            return

        if is_nsfw and not interaction.channel.nsfw:
            await interaction.followup.send("You can create NSFW images in NSFW channels only. Please try in an appropriate channel.", ephemeral=True)
            return

        model_uid = Model[model.value].value[0]

        try:
            imagefileobj = await generate_image_prodia(prompt, model_uid, sampler.value, seed, negative)
        except aiohttp.ClientPayloadError:
            await interaction.followup.send("An error occurred while generating the image. Please try again later.", ephemeral=True)
            return
        except Exception as e:
            await interaction.followup.send(f"An unexpected error occurred: {e}", ephemeral=True)
            return

        if is_nsfw:
            img_file = discord.File(imagefileobj, filename="image.png", spoiler=True, description=prompt)
            prompt = f"||{prompt}||"
        else:
            img_file = discord.File(imagefileobj, filename="image.png", description=prompt)

        embed = discord.Embed(color=0xFF0000) if is_nsfw else discord.Embed(color=discord.Color.random())
        embed.title = f"Generated Image by {interaction.user.display_name}"
        embed.add_field(name='Prompt', value=f'- {prompt}', inline=False)
        embed.add_field(name='Image Details', value=f"- **Model:** {model.value}\n- **Sampler:** {sampler.value}\n- **Seed:**{seed}", inline=True)
        embed.set_footer(text="Â© Kyrox", icon_url=self.bot.user.display_avatar.url)
        #embed.set_thumbnail(url=img_file)
        if negative:
            embed.add_field(name='Negative Prompt', value=f'- {negative}', inline=False)
        if is_nsfw:
            embed.add_field(name='NSFW', value=f'- {str(is_nsfw)}', inline=True)
            


        await interaction.followup.send(view = embed_to_view(embed), file=img_file, ephemeral=True)



