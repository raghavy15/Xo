from utils import emojis

import json
import os
import random
import discord
from discord.ext import commands, tasks
import datetime
from discord.ui import Button, View
import lavalink
from utils import Paginator
from core import Cog, Kyrox, Context

import aiohttp
import asyncio
from utils.Tools import *
from utils.config import SPOTIFY_CLIENT_ID, SPOTIFY_CLIENT_SECRET, serverLink
from utils.cv2_compat import embed_to_view
from utils.music_panel import (
    guard_empty_queue,
    guard_no_results,
    guard_no_voice,
    guard_not_connected,
    guard_not_playing,
    guard_same_channel,
    inactivity_embed,
    kawaii_queue_page_source,
    lavalink_offline_embed,
    music_toast,
    now_playing_embed,
    platform_select_embed,
    player_embed,
    player_layout_view,
    queue_ended_embed,
    queue_entry_line,
    search_results_embed,
    track_added_embed,
    NowPlayingView,
)
import base64
import re
import logging
from urllib.parse import urljoin

import yaml

log = logging.getLogger(__name__)
BOT_DISPLAY_NAME = "Kyrox"

SPOTIFY_TRACK_REGEX = r"https?://open\.spotify\.com/track/([a-zA-Z0-9]+)"
SPOTIFY_PLAYLIST_REGEX = r"https?://open\.spotify\.com/playlist/([a-zA-Z0-9]+)"
SPOTIFY_ALBUM_REGEX = r"https?://open\.spotify\.com/album/([a-zA-Z0-9]+)"

class SpotifyAPI:
    BASE_URL = "https://api.spotify.com/v1"

    def __init__(self, client_id, client_secret):
        self.client_id = client_id
        self.client_secret = client_secret
        self.token = None

    async def get_token(self):
        auth_url = "https://accounts.spotify.com/api/token"
        auth_value = base64.b64encode(f"{self.client_id}:{self.client_secret}".encode('utf-8')).decode('utf-8')
        headers = {"Authorization": f"Basic {auth_value}"}
        data = {"grant_type": "client_credentials"}
        async with aiohttp.ClientSession() as session:
            async with session.post(auth_url, headers=headers, data=data) as response:
                text = await response.text()
                if response.status != 200:
                    raise Exception(f"Failed to fetch token: {response.status}, response: {text}")
                self.token = (await response.json()).get("access_token")

    async def get(self, endpoint, params=None):
        retries = 2
        for attempt in range(retries):
            if not self.token or attempt > 0:
                await self.get_token()

            url = f"{self.BASE_URL}/{endpoint}"
            headers = {"Authorization": f"Bearer {self.token}"}
            async with aiohttp.ClientSession() as session:
                async with session.get(url, headers=headers, params=params) as response:
                    if response.status == 401 and attempt < retries - 1:
                        continue
                    elif response.status != 200:
                        text = await response.text()
                        raise Exception(f"Failed to fetch data from Spotify: {response.status}, message: {text}")
                    return await response.json()
        raise Exception("Exceeded max retries to fetch Spotify data")

    async def get_track(self, track_id):
        return await self.get(f"tracks/{track_id}")

    async def get_playlist(self, playlist_id):
        return await self.get(f"playlists/{playlist_id}")

_spotify_api: SpotifyAPI | None = None

def get_spotify_api() -> SpotifyAPI | None:
    global _spotify_api
    if not SPOTIFY_CLIENT_ID or not SPOTIFY_CLIENT_SECRET:
        return None
    if _spotify_api is None:
        _spotify_api = SpotifyAPI(client_id=SPOTIFY_CLIENT_ID, client_secret=SPOTIFY_CLIENT_SECRET)
    return _spotify_api


_track_artworks = {}

def get_track_artwork(self):
    if id(self) in _track_artworks:
        return _track_artworks[id(self)]
    thumb = "https://images.unsplash.com/photo-1614613535308-eb5fbd3d2c17?q=80&w=200&auto=format&fit=crop"
    source = getattr(self, "source_name", "").lower()
    if source == "youtube" or "youtube.com" in getattr(self, "uri", "") or "youtu.be" in getattr(self, "uri", ""):
        if getattr(self, "identifier", None):
            thumb = f"https://img.youtube.com/vi/{self.identifier}/hqdefault.jpg"
    elif getattr(self, "info", None) and self.info.get("artworkUrl"):
        thumb = self.info.get("artworkUrl")
    return thumb

def set_track_artwork(self, value):
    _track_artworks[id(self)] = value

# Configure properties directly on class definition to support slotted models
lavalink.AudioTrack.length = property(lambda self: self.duration)
lavalink.AudioTrack.artwork = property(get_track_artwork, set_track_artwork)


def patch_track(track):
    """Lavalink track properties are patched dynamically via class properties."""
    return track


class LavalinkVoiceClient(discord.VoiceProtocol):
    """Bridge voice client for discord.py and lavalink."""
    def __init__(self, client: discord.Client, channel: discord.abc.Connectable):
        self.client = client
        self.channel = channel
        self.guild_id = channel.guild.id
        self._destroyed = False
        self.lavalink = self.client.lavalink

    async def on_voice_server_update(self, data):
        lavalink_data = {
            't': 'VOICE_SERVER_UPDATE',
            'd': data
        }
        log.info("Voice Server Update raw data: %s", data)
        try:
            await self.lavalink.voice_update_handler(lavalink_data)
        except lavalink.errors.RequestError as e:
            log.error("RequestError in on_voice_server_update: message=%s, trace=%s", e.message, e.trace)
            raise
        player = self.lavalink.player_manager.get(self.guild_id)
        if player:
            log.info("Player voice state after server update: %s", getattr(player, "_voice_state", None))

    async def on_voice_state_update(self, data):
        channel_id = data['channel_id']
        if not channel_id:
            await self._destroy()
            return

        self.channel = self.client.get_channel(int(channel_id))
        lavalink_data = {
            't': 'VOICE_STATE_UPDATE',
            'd': data
        }
        log.info("Voice State Update raw data: %s", data)
        try:
            await self.lavalink.voice_update_handler(lavalink_data)
        except lavalink.errors.RequestError as e:
            log.error("RequestError in on_voice_state_update: message=%s, trace=%s", e.message, e.trace)
            raise
        player = self.lavalink.player_manager.get(self.guild_id)
        if player:
            log.info("Player voice state after state update: %s", getattr(player, "_voice_state", None))

    async def connect(self, *, timeout: float, reconnect: bool, self_deaf: bool = False, self_mute: bool = False) -> None:
        self.lavalink.player_manager.create(guild_id=self.guild_id)
        await self.channel.guild.change_voice_state(channel=self.channel, self_mute=self_mute, self_deaf=self_deaf)

    async def disconnect(self, *, force: bool = False) -> None:
        player = self.lavalink.player_manager.get(self.guild_id)
        if not force and (not player or not player.is_connected):
            return

        await self.channel.guild.change_voice_state(channel=None)
        if player:
            player.channel_id = None
        await self._destroy()

    async def _destroy(self):
        self.cleanup()
        if self._destroyed:
            return
        self._destroyed = True
        try:
            await self.lavalink.player_manager.destroy(self.guild_id)
        except Exception:
            pass


class PlatformSelectView(View):
    def __init__(self, ctx, query):
        super().__init__(timeout=60)
        self.ctx = ctx
        self.query = query

        platforms = [
            ("♡ YouTube", "ytsearch", discord.ButtonStyle.danger),
            ("♡ JioSaavn", "jssearch", discord.ButtonStyle.success),
            ("♡ SoundCloud", "scsearch", discord.ButtonStyle.secondary),
        ]

        for name, source, style in platforms:
            button = Button(label=name, style=style)
            button.callback = self.create_callback(source)
            self.add_item(button)

    def create_callback(self, source):
        async def callback(interaction: discord.Interaction):
            if interaction.user != self.ctx.author:
                await interaction.response.send_message("Only the command author can select a platform.", ephemeral=True)
                return

            await interaction.response.send_message("✧ searching… one moment!", ephemeral=True)
            await self.perform_search(source)
            await interaction.message.delete()
        return callback

    async def perform_search(self, source):
        if self.ctx.cog and not await self.ctx.cog.ensure_lavalink(self.ctx):
            return

        if not self.ctx.bot.lavalink.node_manager.nodes:
            return await self.ctx.send(view=guard_no_results())

        node = self.ctx.bot.lavalink.node_manager.nodes[0]
        results = await node.get_tracks(f"{source}:{self.query}")
        if not results or not results.tracks:
            return await self.ctx.send(view=guard_no_results())

        top_results = [patch_track(t) for t in results.tracks[:5]]
        embed = search_results_embed(self.query, source, top_results)
        await self.ctx.send(view=embed_to_view(embed, view=SearchResultView(self.ctx, top_results)))


class SearchResultView(View):
    def __init__(self, ctx, results):
        super().__init__(timeout=60)
        self.ctx = ctx
        self.results = results

        for i in range(min(5, len(results))):
            button = Button(label=f"♡ {i + 1}", style=discord.ButtonStyle.primary)
            button.callback = self.create_callback(i)
            self.add_item(button)

    def create_callback(self, index):
        async def callback(interaction: discord.Interaction):
            if interaction.user != self.ctx.author:
                await interaction.response.send_message("Only the command author can select a track.", ephemeral=True)
                return

            track = self.results[index]
            vc = self.ctx.voice_client or await self.ctx.author.voice.channel.connect(cls=LavalinkVoiceClient)
            player = self.ctx.bot.lavalink.player_manager.get(self.ctx.guild.id)
            player.ctx = self.ctx

            if not player.is_playing:
                player.add(requester=self.ctx.author.id, track=track)
                await player.play()
                await interaction.response.send_message(f"♡ Now playing **{track.title}**", ephemeral=True)
            else:
                player.add(requester=self.ctx.author.id, track=track)
                await interaction.response.send_message(f"♡ Added **{track.title}** to the queue", ephemeral=True)

        return callback


class MusicControlView(View):
    def __init__(self, player, ctx):
        super().__init__(timeout=None)
        self.player = player
        self.ctx = ctx

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if not self.ctx.voice_client or not self.player.is_playing:
            await interaction.response.send_message("I'm not currently playing this anymore.", ephemeral=True)
            return False
        if interaction.user in self.ctx.voice_client.channel.members:
            return True
        await interaction.response.send_message(
            "♡ Join my voice channel to use the player controls.",
            ephemeral=True,
        )
        return False

    # ── Row 1: transport controls ────────────────────────────────────────
    @discord.ui.button(emoji=str(emojis.REWIND1), style=discord.ButtonStyle.secondary, custom_id="music_prev", row=0)
    async def prev_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self.player.seek(0)
        await interaction.response.send_message("Replaying from the start.", ephemeral=True)

    @discord.ui.button(emoji=str(emojis.ICONS_PAUSE), style=discord.ButtonStyle.secondary, custom_id="music_pause", row=0)
    async def pause_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        if self.player.paused:
            await self.player.set_pause(False)
            button.emoji = str(emojis.ICONS_PAUSE)
            await interaction.response.edit_message(view=self)
            await self.ctx.send(view=music_toast("Resumed playback~", tone="info"))
        else:
            await self.player.set_pause(True)
            button.emoji = str(emojis.ICONS_MUSIC)
            await interaction.response.edit_message(view=self)
            await self.ctx.send(view=music_toast("Paused playback~", tone="info"))

    @discord.ui.button(emoji=str(emojis.ICONS_NEXT), style=discord.ButtonStyle.secondary, custom_id="music_skip", row=0)
    async def skip_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self.player.skip()
        await interaction.response.send_message("Skipped track.", ephemeral=True)

    @discord.ui.button(emoji=str(emojis.MUSICSTOP_ICONS), style=discord.ButtonStyle.danger, custom_id="music_stop", row=0)
    async def stop_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        self.player.queue.clear()
        await self.player.stop()
        await self.ctx.voice_client.disconnect(force=True)
        await interaction.response.send_message("Stopped playback and disconnected.", ephemeral=True)

    # ── Row 2: extra controls ────────────────────────────────────────────
    @discord.ui.button(emoji="\U0000267e\U0000fe0f", style=discord.ButtonStyle.secondary, custom_id="music_loop", row=1)
    async def loop_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        if self.player.loop == self.player.LOOP_NONE:
            self.player.loop = self.player.LOOP_SINGLE
            button.style = discord.ButtonStyle.primary
            await interaction.response.edit_message(view=self)
            await self.ctx.send(view=music_toast("Loop set to track~", tone="info"))
        elif self.player.loop == self.player.LOOP_SINGLE:
            self.player.loop = self.player.LOOP_QUEUE
            button.style = discord.ButtonStyle.success
            await interaction.response.edit_message(view=self)
            await self.ctx.send(view=music_toast("Loop set to queue~", tone="info"))
        else:
            self.player.loop = self.player.LOOP_NONE
            button.style = discord.ButtonStyle.secondary
            await interaction.response.edit_message(view=self)
            await self.ctx.send(view=music_toast("Loop disabled~", tone="info"))

    @discord.ui.button(emoji="\U0001f504", style=discord.ButtonStyle.secondary, custom_id="music_autoplay", row=1)
    async def autoplay_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        current = getattr(self.player, "autoplay", False)
        self.player.autoplay = not current
        state = "on" if self.player.autoplay else "off"
        button.style = discord.ButtonStyle.primary if self.player.autoplay else discord.ButtonStyle.secondary
        await interaction.response.edit_message(view=self)
        await self.ctx.send(view=music_toast(f"Autoplay {state}~", tone="info"))


class Music(commands.Cog):
    def __init__(self, client: Kyrox):
        self.client = client
        self.lavalink_nodes = self._load_lavalink_nodes()
        self.inactivity_timeout = 120
        self.player_inactivity = {}

    async def cog_load(self) -> None:
        asyncio.create_task(self.initialize_lavalink())
        asyncio.create_task(self.monitor_inactivity())

    async def initialize_lavalink(self):
        try:
            await self.client.wait_until_ready()
        except RuntimeError:
            return

        if not hasattr(self.client, 'lavalink'):
            self.client.lavalink = lavalink.Client(self.client.user.id)
            
            for node_config in self.lavalink_nodes:
                uri = str(node_config.get("uri") or node_config.get("URI") or "").strip()
                host = str(node_config.get("host") or node_config.get("HOST") or "").strip()
                port = node_config.get("port") or node_config.get("PORT")
                password = str(node_config.get("password") or node_config.get("PASSWORD") or "").strip()
                identifier = str(node_config.get("identifier") or node_config.get("IDENTIFIER") or "main")
                secure = node_config.get("secure")
                if secure is None:
                    secure = node_config.get("ssl")
                
                if (uri or host) and password:
                    if not host and uri:
                        if secure is None:
                            secure = uri.startswith("https://")
                        uri_clean = uri.replace("http://", "").replace("https://", "").rstrip("/")
                        if ":" in uri_clean:
                            host, port_str = uri_clean.rsplit(":", 1)
                            port = int(port_str)
                        else:
                            host = uri_clean
                            port = 443 if secure else 80
                    else:
                        port = int(port or (443 if secure else 80))
                    
                    is_ssl = bool(secure or port == 443)
                    if secure is False:
                        is_ssl = False
                    
                    self.client.lavalink.add_node(
                        host=host,
                        port=port,
                        password=password,
                        region="us",
                        name=identifier,
                        ssl=is_ssl,
                    )
            
            for node in self.client.lavalink.node_manager.nodes:
                node._transport.trace_requests = True
            
        self.client.lavalink.add_event_hook(self.on_lavalink_event)

    def cog_unload(self):
        if hasattr(self.client, 'lavalink'):
            self.client.lavalink.remove_event_hooks(hooks=[self.on_lavalink_event])

    def _env_bool(self, name: str, default: bool) -> bool:
        value = os.getenv(name)
        if value is None:
            return default
        return value.strip().lower() in {"1", "true", "yes", "on"}

    def _load_lavalink_nodes(self) -> list[dict]:
        config: dict = {}
        if os.path.exists("config.yml"):
            try:
                with open("config.yml", "r", encoding="utf-8") as fp:
                    config = yaml.safe_load(fp) or {}
            except OSError:
                log.warning("Could not read config.yml for Lavalink settings.")

        lavalink_config = config.get("LAVALINK", {}) or {}
        if not self._env_bool("LAVALINK_ENABLED", bool(lavalink_config.get("ENABLED", True))):
            return []

        raw_nodes = os.getenv("LAVALINK_NODES_JSON") or os.getenv("LAVALINK_NODES")
        if raw_nodes:
            try:
                parsed = json.loads(raw_nodes)
                if isinstance(parsed, dict):
                    parsed = [parsed]
                if isinstance(parsed, list):
                    return [node for node in parsed if isinstance(node, dict)]
            except json.JSONDecodeError:
                log.warning("LAVALINK_NODES_JSON is not valid JSON; falling back to simple Lavalink env vars.")

        uri = os.getenv("LAVALINK_URI") or lavalink_config.get("URI")
        password = os.getenv("LAVALINK_PASSWORD") or lavalink_config.get("PASSWORD")
        host = os.getenv("LAVALINK_HOST") or lavalink_config.get("HOST")
        port = os.getenv("LAVALINK_PORT") or lavalink_config.get("PORT")
        if (uri or host) and password:
            node_data = {
                "identifier": os.getenv("LAVALINK_IDENTIFIER") or lavalink_config.get("IDENTIFIER") or "main",
                "password": password,
                "secure": self._env_bool("LAVALINK_SECURE", bool(lavalink_config.get("SECURE", False))),
                "heartbeat": float(os.getenv("LAVALINK_HEARTBEAT") or lavalink_config.get("HEARTBEAT", 15.0)),
                "retries": int(os.getenv("LAVALINK_RETRIES") or lavalink_config.get("RETRIES", 3)),
            }
            if uri:
                node_data["uri"] = uri
            if host:
                node_data["host"] = host
            if port:
                node_data["port"] = int(port)
            return [node_data]

        config_nodes = lavalink_config.get("NODES", []) or []
        return [node for node in config_nodes if isinstance(node, dict)]

    def is_lavalink_available(self) -> bool:
        if not hasattr(self.client, 'lavalink'):
            return False
        for node in self.client.lavalink.node_manager.nodes:
            if node.available:
                return True
        return False

    def source_link_value(self, track) -> str:
        uri = getattr(track, "uri", None) or ""
        source = f"{getattr(track, 'source_name', '')} {uri}".lower()
        if "spotify" in source:
            emoji, label = getattr(emojis, "SPOTIFY", emojis.YOUTUBE), "Listen on Spotify"
        elif "jiosaavn" in source:
            emoji, label = emojis.JIOSAAVN, "Listen on JioSaavn"
        elif "soundcloud" in source:
            emoji, label = emojis.SOUNDCLOUD, "Listen on SoundCloud"
        else:
            emoji, label = emojis.YOUTUBE, "Listen on YouTube"

        return f"{emoji} [{label}]({uri})" if uri else f"{emoji} {label}"

    def source_name(self, track) -> str:
        source = f"{getattr(track, 'source_name', '')} {getattr(track, 'uri', '')}".lower()
        if "spotify" in source:
            return "Spotify"
        if "youtube" in source or "youtu.be" in source:
            return "YouTube"
        if "soundcloud" in source:
            return "SoundCloud"
        if "jiosaavn" in source:
            return "JioSaavn"
        return "Unknown Source"

    def track_link(self, track) -> str:
        title = getattr(track, "title", "Unknown track")
        uri = getattr(track, "uri", None)
        title = str(title).replace("[", "\\[").replace("]", "\\]")
        return f"[{title}]({uri})" if uri else f"**{title}**"

    async def music_reply(self, ctx: commands.Context, message: str, *, tone: str = "info") -> None:
        await ctx.send(view=music_toast(message, tone=tone))

    async def require_voice(self, ctx: commands.Context) -> bool:
        if ctx.author.voice:
            return True
        await ctx.send(view=guard_no_voice())
        return False

    async def require_same_channel(self, ctx: commands.Context, vc) -> bool:
        if ctx.author.voice and vc and ctx.author.voice.channel.id == vc.channel.id:
            return True
        await ctx.send(view=guard_same_channel())
        return False

    async def require_playing(self, ctx: commands.Context):
        player = self.client.lavalink.player_manager.get(ctx.guild.id)
        if not player or not player.is_playing:
            await ctx.send(view=guard_not_playing())
            return None
        vc = ctx.voice_client
        if not vc:
            await ctx.send(view=guard_not_playing())
            return None
        if not await self.require_same_channel(ctx, vc):
            return None
        return player

    async def ensure_lavalink(self, ctx: commands.Context) -> bool:
        if self.is_lavalink_available():
            return True

        await ctx.send(view=embed_to_view(lavalink_offline_embed(emojis.ICONS_WARNING)))
        return False

    async def monitor_inactivity(self):
        try:
            await self.client.wait_until_ready()
        except RuntimeError:
            return
        while True:
            for guild in self.client.guilds:
                await self.check_inactivity(guild.id) 
            await asyncio.sleep(60) 

    async def check_inactivity(self, guild_id):
        guild = self.client.get_guild(guild_id)
        if not guild:
            return

        player = self.client.lavalink.player_manager.get(guild.id)
        vc = guild.voice_client
        if player and player.is_playing and vc and len(vc.channel.members) == 1:
            await self.inactivity_timer(guild)

    async def inactivity_timer(self, guild):
        await asyncio.sleep(self.inactivity_timeout)
        vc = guild.voice_client
        if vc and len(vc.channel.members) == 1:
            player = self.client.lavalink.player_manager.get(guild.id)
            if player:
                player.queue.clear()
                await player.stop()
            await vc.disconnect(force=True)
            try:
                ended = inactivity_embed()
                if self.client.user and self.client.user.avatar:
                    ended.set_author(name="Kyrox Music", icon_url=self.client.user.display_avatar.url)
                support = Button(label="Support", style=discord.ButtonStyle.link, url=serverLink)
                view = View()
                view.add_item(support)
                # Find channel to notify
                ctx_channel = getattr(player, "ctx", None)
                if ctx_channel:
                    await ctx_channel.channel.send(view=embed_to_view(ended, view=view))
            except:
                pass

    async def display_player_embed(self, player, track, ctx, autoplay=False):
        from utils.music_panel import NowPlayingView
        view = NowPlayingView(
            track,
            player,
            ctx,
            source_name=self.source_name(track),
            requested_by=ctx.author.mention,
            autoplay=autoplay,
            queue_length=len(player.queue),
        )
        await ctx.send(view=view)

    async def update_channel_status(self, channel_id: int, status: str):
        if not channel_id:
            return
        try:
            await self.client.http.edit_voice_channel_status(status, channel_id=channel_id)
        except Exception as e:
            log.warning("Failed to edit voice channel status: %s", e)

    async def on_lavalink_event(self, event):
        if isinstance(event, lavalink.events.TrackStartEvent):
            self.client.dispatch("lavalink_track_start", event)
            player = event.player
            ctx = getattr(player, "ctx", None)
            
            status_text = f"<:zemojis_music:1527683319213592767> ● **{event.track.title}**"
            if len(status_text) > 500:
                status_text = status_text[:497] + "..."
            await self.update_channel_status(int(player.channel_id), status_text)
            
            if ctx:
                await self.display_player_embed(player, event.track, ctx)

        elif isinstance(event, lavalink.events.TrackEndEvent):
            player = event.player
            ctx = getattr(player, "ctx", None)
            
            if not player.queue and player.loop == player.LOOP_NONE:
                autoplay = getattr(player, "autoplay", False)
                if autoplay:
                    last_track = event.track
                    if not last_track:
                        try:
                            from helpers.lavalink_client import get_state
                            state = get_state(player.guild_id)
                            if state.previous_tracks:
                                last_track = state.previous_tracks[-1]
                        except Exception:
                            pass
                    if not last_track:
                        return
                    query = f"ytsearch:{last_track.author} mix"
                    results = await self.get_search_results(query)
                    if results and results.tracks:
                        for t in results.tracks:
                            if t.identifier != last_track.identifier:
                                player.add(requester=self.client.user.id, track=t)
                                await player.play()
                                if ctx:
                                    await self.display_player_embed(player, t, ctx, autoplay=True)
                                return
                    if ctx:
                        await ctx.send("No suitable track found for autoplay.")
                        
                await self.update_channel_status(int(player.channel_id), "Oi, Motu Play any song")

                if ctx:
                    ended = queue_ended_embed()
                    if self.client.user and self.client.user.avatar:
                        ended.set_author(name="Kyrox Music", icon_url=self.client.user.display_avatar.url)
                    support = Button(label="Support", style=discord.ButtonStyle.link, url=serverLink)
                    view = View()
                    view.add_item(support)
                    await ctx.send(view=embed_to_view(ended, view=view))

    async def get_search_results(self, query: str):
        if not self.is_lavalink_available():
            return None
        node = self.client.lavalink.node_manager.nodes[0]
        results = await node.get_tracks(query)
        if results and results.tracks:
            for t in results.tracks:
                patch_track(t)
        return results

    async def handle_spotify_link(self, ctx, player, link, type_):
        spotify_api = get_spotify_api()
        if not spotify_api:
            await ctx.send("Spotify is not configured. Set `SPOTIFY_CLIENT_ID` and `SPOTIFY_CLIENT_SECRET` in `.env`.")
            return
        try:
            if type_ == "track":
                track_id = re.search(SPOTIFY_TRACK_REGEX, link).group(1)
                track_info = await spotify_api.get_track(track_id)
                title = track_info['name']
                author = ', '.join(artist['name'] for artist in track_info['artists'])
                search_query = f"ytsearch:{title} by {author}"
                results = await player.node.get_tracks(search_query)
                if not results or not results.tracks:
                    await ctx.send("Can't play this track from Spotify, please try another query.")
                    return
                track = patch_track(results.tracks[0])
                player.add(requester=ctx.author.id, track=track)
                await ctx.send(embed=track_added_embed(track, requested_by=ctx.author.mention))
                if not player.is_playing:
                    await player.play()
            elif type_ == "playlist":
                playlist_id = re.search(SPOTIFY_PLAYLIST_REGEX, link).group(1)
                playlist_info = await spotify_api.get_playlist(playlist_id)
                tracks_data = playlist_info['tracks']['items']
                await ctx.send(view=music_toast(f"Adding Spotify playlist **{playlist_info['name']}** to the queue...", tone="added"))
                added_count = 0
                for item in tracks_data:
                    track_data = item['track']
                    if not track_data:
                        continue
                    title = track_data['name']
                    author = ', '.join(artist['name'] for artist in track_data['artists'])
                    search_query = f"ytsearch:{title} by {author}"
                    results = await player.node.get_tracks(search_query)
                    if results and results.tracks:
                        track = patch_track(results.tracks[0])
                        player.add(requester=ctx.author.id, track=track)
                        added_count += 1
                        if not player.is_playing:
                            await player.play()
                await ctx.send(view=music_toast(f"Queued **{added_count}** tracks from Spotify playlist!", tone="added"))
            elif type_ == "album":
                album_id = re.search(SPOTIFY_ALBUM_REGEX, link).group(1)
                album_info = await spotify_api.get(f"albums/{album_id}")
                tracks_data = album_info['tracks']['items']
                await ctx.send(view=music_toast(f"Adding Spotify album **{album_info['name']}** to the queue...", tone="added"))
                added_count = 0
                for track_data in tracks_data:
                    title = track_data['name']
                    author = ', '.join(artist['name'] for artist in track_data['artists'])
                    search_query = f"ytsearch:{title} by {author}"
                    results = await player.node.get_tracks(search_query)
                    if results and results.tracks:
                        track = patch_track(results.tracks[0])
                        player.add(requester=ctx.author.id, track=track)
                        added_count += 1
                        if not player.is_playing:
                            await player.play()
                await ctx.send(view=music_toast(f"Queued **{added_count}** tracks from Spotify album!", tone="added"))
        except Exception as e:
            log.warning("Spotify resolution failed: %s", e)
            await ctx.send(f"Error reading Spotify link: {e}")

    @commands.hybrid_command(name="play", aliases=['p'], usage="play <query>", help="Plays a song or playlist.")
    async def play(self, ctx: Context, *, query: str):
        if not await self.ensure_lavalink(ctx):
            return
        if not await self.require_voice(ctx):
            return

        vc = ctx.voice_client or await ctx.author.voice.channel.connect(cls=LavalinkVoiceClient)
        if not await self.require_same_channel(ctx, vc):
            return

        player = self.client.lavalink.player_manager.get(ctx.guild.id)
        player.ctx = ctx

        if player.is_playing:
            if ctx.voice_client and ctx.voice_client.channel != ctx.author.voice.channel:
                await self.music_reply(
                    ctx,
                    f"I'm already in {ctx.voice_client.channel.mention}. Join that channel to add songs.",
                    tone="warning",
                )
                return

        player.loop = player.LOOP_NONE

        query = query.strip("<>")
        if not query.startswith("http://") and not query.startswith("https://"):
            query = f"ytsearch:{query}"

        results = await player.node.get_tracks(query)
        if not results or not results.tracks:
            await ctx.send(view=guard_no_results())
            return

        if results.load_type in ("PLAYLIST_LOADED", "playlist"):
            tracks = results.tracks
            for t in tracks:
                patch_track(t)
                player.add(requester=ctx.author.id, track=t)
            await ctx.send(
                view=music_toast(
                    f"Added playlist **{results.playlist_info.name}** with **{len(tracks)}** songs to the queue~",
                    tone="added",
                )
            )
            if not player.is_playing:
                await player.play()
        else:
            track = patch_track(results.tracks[0])
            player.add(requester=ctx.author.id, track=track)
            from utils.music_panel import track_added_embed
            await ctx.send(
                embed=track_added_embed(track, requested_by=ctx.author.mention)
            )
            if not player.is_playing:
                await player.play()

    @commands.hybrid_command(name="search", usage="search <query>", help="Searches music from multiple platforms.")
    async def search(self, ctx: Context, *, query: str):
        if not await self.ensure_lavalink(ctx):
            return
        if not await self.require_voice(ctx):
            return

        await ctx.send(
            view=embed_to_view(
                platform_select_embed(query),
                view=PlatformSelectView(ctx, query)
            )
        )

    @commands.hybrid_command(name="nowplaying", aliases=["nop"], usage="nowplaying", help="Shows the info about current playing song.")
    async def nowplaying(self, ctx: Context):
        player = await self.require_playing(ctx)
        if not player:
            return

        track = player.current
        embed = now_playing_embed(
            track,
            position=player.position / 1000,
            queue_length=len(player.queue),
            source_name=self.source_name(track),
            source_link=self.source_link_value(track),
            requested_by=ctx.author.display_name,
        )
        await ctx.reply(embed=embed, mention_author=False)

    @commands.hybrid_command(name="autoplay", usage="autoplay", help="Toggles autoplay mode.")
    async def autoplay(self, ctx: Context):
        player = await self.require_playing(ctx)
        if not player:
            return
        current = getattr(player, "autoplay", False)
        player.autoplay = not current
        await ctx.send(f"Autoplay {'enabled' if player.autoplay else 'disabled'}.")

    @commands.hybrid_command(name="loop", usage="loop", help="Toggles loop mode.")
    async def loop(self, ctx: Context, mode: str = None):
        player = await self.require_playing(ctx)
        if not player:
            return

        if mode is None:
            if player.loop == player.LOOP_NONE:
                player.loop = player.LOOP_SINGLE
                state = "single track"
            elif player.loop == player.LOOP_SINGLE:
                player.loop = player.LOOP_QUEUE
                state = "queue"
            else:
                player.loop = player.LOOP_NONE
                state = "disabled"
        else:
            m = mode.lower()
            if m in ("single", "track", "one"):
                player.loop = player.LOOP_SINGLE
                state = "single track"
            elif m in ("queue", "all"):
                player.loop = player.LOOP_QUEUE
                state = "queue"
            else:
                player.loop = player.LOOP_NONE
                state = "disabled"

        await ctx.send(f"Loop set to **{state}**.")

    @commands.hybrid_command(name="pause", usage="pause", help="Pauses the current song.")
    async def pause(self, ctx: Context):
        player = await self.require_playing(ctx)
        if not player:
            return
        if player.paused:
            await ctx.send("The player is already paused.")
            return
        await player.set_pause(True)
        await ctx.send("Paused the player.")

    @commands.hybrid_command(name="resume", usage="resume", help="Resumes the paused song.")
    async def resume(self, ctx: Context):
        player = await self.require_playing(ctx)
        if not player:
            return
        if not player.paused:
            await ctx.send("The player is already playing.")
            return
        await player.set_pause(False)
        await ctx.send("Resumed the player.")

    @commands.hybrid_command(name="skip", usage="skip", help="Skips the current song.")
    async def skip(self, ctx: Context):
        player = await self.require_playing(ctx)
        if not player:
            return
        await player.skip()
        await ctx.send("Skipped the current track.")

    @commands.hybrid_command(name="shuffle", usage="shuffle", help="Shuffles the queue.")
    async def shuffle(self, ctx: Context):
        player = await self.require_playing(ctx)
        if not player:
            return
        if not player.queue:
            await ctx.send("The queue is empty.")
            return
        player.shuffle = not player.shuffle
        await ctx.send(f"Shuffle {'enabled' if player.shuffle else 'disabled'}.")

    @commands.hybrid_command(name="stop", usage="stop", help="Stops the current song and clears the queue.")
    async def stop(self, ctx: Context):
        player = await self.require_playing(ctx)
        if not player:
            return
        player.queue.clear()
        await player.stop()
        await ctx.send("Stopped the player and cleared the queue.")

    @commands.hybrid_command(name="volume", aliases=["vol"], usage="volume <level>", help="Sets the volume of the player.")
    async def volume(self, ctx: Context, level: int = None):
        player = await self.require_playing(ctx)
        if not player:
            return
        if level is None:
            await ctx.send(f"Current volume: `{player.volume}%`.")
            return
        if level < 0 or level > 150:
            await ctx.send("Volume must be between 0 and 150.")
            return
        await player.set_volume(level)
        await ctx.send(f"Set volume to `{level}%`.")

    @commands.hybrid_command(name="queue", usage="queue", help="Shows the current queue.")
    async def queue(self, ctx: Context):
        player = self.client.lavalink.player_manager.get(ctx.guild.id)
        if not player or not player.is_playing:
            await ctx.send("I'm not playing anything right now.")
            return
        if not player.queue:
            await ctx.send("The queue is empty.")
            return

        pages = []
        queue_list = list(player.queue)
        items_per_page = 10
        for i in range(0, len(queue_list), items_per_page):
            chunk = queue_list[i:i+items_per_page]
            description = "\n".join(
                f"`{i+idx+1}.` {self.track_link(t)} — `{format_duration_ms(t.duration)}`"
                for idx, t in enumerate(chunk)
            )
            embed = discord.Embed(
                title=f"Queue for {ctx.guild.name}",
                description=description,
                color=0xFFB7C5
            )
            pages.append(embed)

        paginator = Paginator(ctx, pages)
        await paginator.start()

    @commands.hybrid_command(name="clearqueue", usage="clearqueue", help="Clears the queue.")
    async def clearqueue(self, ctx: Context):
        player = await self.require_playing(ctx)
        if not player:
            return
        player.queue.clear()
        await ctx.send("Cleared the queue.")

    @commands.hybrid_command(name="replay", usage="replay", help="Replays the current song.")
    async def replay(self, ctx: Context):
        player = await self.require_playing(ctx)
        if not player:
            return
        await player.seek(0)
        await ctx.send("Replaying the current song.")

    @commands.hybrid_command(name="join", aliases=["connect"], usage="join", help="Joins the voice channel.")
    async def join(self, ctx: Context):
        if not await self.ensure_lavalink(ctx):
            return
        if not await self.require_voice(ctx):
            return
        vc = ctx.voice_client or await ctx.author.voice.channel.connect(cls=LavalinkVoiceClient)
        await ctx.send(f"Connected to {ctx.author.voice.channel.mention}.")

    @commands.hybrid_command(name="disconnect", aliases=["dc", "leave"], usage="disconnect", help="Disconnects the bot from the voice channel.")
    async def disconnect(self, ctx: Context):
        vc = ctx.voice_client
        if not vc:
            await ctx.send("I'm not in any voice channel.")
            return
        await vc.disconnect(force=True)
        await ctx.send("Disconnected from voice channel.")

    @commands.hybrid_command(name="seek", usage="seek <percentage>", help="Seeks to a specific percentage of the song.")
    async def seek(self, ctx: Context, percentage: int):
        player = await self.require_playing(ctx)
        if not player:
            return
        if percentage < 0 or percentage > 100:
            await ctx.send("Percentage must be between 0 and 100.")
            return
        track = player.current
        position = int(track.duration * (percentage / 100))
        await player.seek(position)
        await ctx.send(f"Seeked to `{percentage}%` of the track.")


async def setup(client: Kyrox):
    await client.add_cog(Music(client))
