from utils.database import get_collection
from utils import emojis

from discord.ext import commands, tasks
import datetime, pytz, time as t
from discord.ui import Button, Select, View
import random, typing
import asyncio
import discord, logging
from discord.utils import get
from utils.Tools import *
import os
import aiohttp
from utils.cv2_compat import embed_to_view, embeds_to_view


GIVEAWAY_SCHEMA = '''CREATE TABLE IF NOT EXISTS Giveaway (
                    guild_id INTEGER,
                    host_id INTEGER,
                    start_time TIMESTAMP,
                    ends_at TIMESTAMP,
                    prize TEXT,
                    winners INTEGER,
                    message_id INTEGER,
                    channel_id INTEGER,
                    PRIMARY KEY (guild_id, message_id)
                )'''

def convert(time):
    pos = ["s","m","h","d"]
    time_dict = {"s" : 1, "m" : 60, "h" : 3600 , "d" : 86400 , "f" : 259200}
    unit = time[-1]
    if unit not in pos:
        return
    try:
        val = int(time[:-1])
    except ValueError:
        return
    return val * time_dict[unit]

def WinnerConverter(winner):
    try:
        int(winner)
    except ValueError:
        try:
           return int(winner[:-1])
        except:
            return -4
    return winner

class Giveaway(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    async def cog_load(self) -> None:
        self.col = await get_collection('giveaways')
        await self.check_for_ended_giveaways()

    async def cog_unload(self) -> None:
        self.GiveawayEnd.cancel()
        pass

    @commands.Cog.listener()
    async def on_ready(self):
        if not self.GiveawayEnd.is_running():
            self.GiveawayEnd.start()

    async def check_for_ended_giveaways(self):
        ended_giveaways = await self.col.find({'ends_at': {'$lte': datetime.datetime.now().timestamp()}}).to_list(length=None)
        ended_giveaways = [(g.get('ends_at'), g.get('guild_id'), g.get('message_id'), g.get('host_id'), g.get('winners'), g.get('prize'), g.get('channel_id')) for g in ended_giveaways]
        for giveaway in ended_giveaways:
            await self.end_giveaway(giveaway)

    async def end_giveaway(self, giveaway):
        try:
            current_time = datetime.datetime.now().timestamp()
            guild = self.bot.get_guild(int(giveaway[1]))
            if guild is None:
                await self.col.delete_one({'message_id': giveaway[2], 'guild_id': giveaway[1]})
                return

            channel = self.bot.get_channel(int(giveaway[6]))
            if channel is not None:
                try:
                    retries = 3
                    for attempt in range(retries):
                        try:
                            message = await channel.fetch_message(int(giveaway[2]))
                            break
                        except discord.NotFound:
                            await self.col.delete_one({'message_id': giveaway[2], 'guild_id': giveaway[1]})
                            return
                        except aiohttp.ClientResponseError as e:
                            if e.status == 503:
                                if attempt < retries - 1:
                                    await asyncio.sleep(2 ** attempt)
                                    continue
                                else:
                                    raise
                            else:
                                raise

                    users = [i.id async for i in message.reactions[0].users()]
                    if self.bot.user.id in users:
                        users.remove(self.bot.user.id)

                    if len(users) < 1:
                        await message.reply(f"No one won the **{giveaway[5]}** giveaway, due to Not enough participants.")
                        await self.col.delete_one({'message_id': message.id, 'guild_id': message.guild.id})
                        return

                    winners_count = min(len(users), int(giveaway[4]))
                    winner = ', '.join(f'<@!{i}>' for i in random.sample(users, k=winners_count))

                    desc = (
                        f"<:dot_flowerblue_nc:1526949160857894922> Winner(s): {winner}\n"
                        f"<:dot_flowerblue_nc:1526949160857894922> Ended: <t:{int(current_time)}:R>\n"
                        f"<:dot_flowerblue_nc:1526949160857894922> Hosted by: <@{int(giveaway[3])}>"
                    )
                    embed = discord.Embed(
                        title=f"<a:giveaway:1526948648066482388> {giveaway[5]} <a:giveaway:1526948648066482388>",
                        description=desc,
                        color=0x1ABC9C
                    )
                    embed.timestamp = discord.utils.utcnow()

                    embed.set_footer(text=f"Ended at")
                    await message.edit(view=embed_to_view(embed))
                    await message.reply(f"{emojis.GIVEAWAYS} Congrats {winner}, you won **{giveaway[5]}!**, Hosted by <@{int(giveaway[3])}>")
                    await self.col.delete_one({'message_id': message.id, 'guild_id': message.guild.id})

                except (discord.HTTPException, aiohttp.ClientResponseError) as e:
                    logging.error(f"Error ending giveaway: {e}")

        except IndexError:
            logging.error(f"Giveaway data is corrupted or missing: {giveaway}")
            await self.col.delete_one({'message_id': giveaway[2], 'guild_id': giveaway[1]})

    @tasks.loop(seconds=5)
    async def GiveawayEnd(self):
        ends_raw = await self.col.find({'ends_at': {'$lte': datetime.datetime.now().timestamp()}}).to_list(length=None)
        ends_raw = [(g.get('ends_at'), g.get('guild_id'), g.get('message_id'), g.get('host_id'), g.get('winners'), g.get('prize'), g.get('channel_id')) for g in ends_raw]
        for giveaway in ends_raw:
            await self.end_giveaway(giveaway)




    @commands.hybrid_command(description="Starts a new giveaway.")
    @blacklist_check()
    @ignore_check()
    @commands.cooldown(1, 5, commands.BucketType.user)
    @commands.guild_only()
    @security_manager_check()
    @commands.has_guild_permissions(manage_guild=True)
    async def gstart(self, ctx,
                      time,
                      winners: int,
                      *,
                      prize: str):
        re_raw = await self.col.find({'guild_id': ctx.guild.id}).to_list(length=None)
        re = [(g.get('message_id'), g.get('channel_id')) for g in re_raw]

        if winners >=  15:
            embed = discord.Embed(title="⚠️ Access Denied",
                                  description=f"Cannot exceed more than 15 winners.",
                                  color=0x000000)
            message = await ctx.send(view = embed_to_view(embed))
            await asyncio.sleep(5)
            await message.delete()
            return

        g_list = [i[0] for i in re]
        if len(g_list) >= 5:
            embed = discord.Embed(title=f"{emojis.ICONS_WARNING} Access Denied",
                                  description=f"You can only host upto 5 giveaways in this Guild.", color=0x000000)
            message = await ctx.send(view = embed_to_view(embed))
            await asyncio.sleep(5)
            await message.delete()
            return

        converted = self.convert(time)
        if converted / 60 >= 50400:
            embed = discord.Embed(title=f"{emojis.ICONS_WARNING} Access Denied",
                                  description=f"Time cannot exceed 31 days!", color=0x000000)
            message = await ctx.send(view = embed_to_view(embed))
            await asyncio.sleep(5)
            await message.delete()
            return

        if converted == -1:
            embed = discord.Embed(title=f"{emojis.CROSSICON} Error",
                                  description=f"Invalid time format", color=0x000000)
            message = await ctx.send(view = embed_to_view(embed))
            await asyncio.sleep(5)
            await message.delete()
            return
        if converted == -2:
            embed = discord.Embed(title=f"{emojis.CROSSICON} Error",
                                  description=f"Invalid time format. Please provide the time in numbers.",
                                  color=0x000000)
            message = await ctx.send(view = embed_to_view(embed))
            await asyncio.sleep(5)
            await message.delete()
            return

        ends = (datetime.datetime.now().timestamp() + converted)

        desc = (
            f"<:dot_flowerblue_nc:1526949160857894922> Winners: {winners}\n"
            f"<:dot_flowerblue_nc:1526949160857894922> Ends: <t:{round(ends)}:R> ( <t:{round(ends)}:f> )\n"
            f"<:dot_flowerblue_nc:1526949160857894922> Hosted by: {ctx.author.mention}\n"
            "\n"
            f"<:dot_flowerblue_nc:1526949160857894922> React with <a:GIVEAWAY:1526948576645615667> to participate!"
        )

        embed = discord.Embed(
            title=f"<a:giveaway:1526948648066482388> {prize} <a:giveaway:1526948648066482388>",
            description=desc,
            color=0x1ABC9C
        )

        ends1 = datetime.datetime.utcnow() + datetime.timedelta(seconds=converted)
        ends_utc = ends1.replace(tzinfo=datetime.timezone.utc)

        embed.timestamp = ends_utc
        embed.set_footer(text=f"Ends at", icon_url=ctx.bot.user.display_avatar.url)

        message = await ctx.send(view=embed_to_view(embed))

        try:
           await ctx.message.delete()
        except:
            pass

        await self.col.insert_one({'guild_id': ctx.guild.id, 'host_id': ctx.author.id, 'start_time': datetime.datetime.now().timestamp(), 'ends_at': ends, 'prize': prize, 'winners': winners, 'message_id': message.id, 'channel_id': ctx.channel.id})

        await message.add_reaction("<a:GIVEAWAY:1526948576645615667>")

    
                                    

    @commands.Cog.listener("on_message_delete")
    async def GiveawayMessageDelete(self, message):
        re_raw = await self.col.find_one({'guild_id': message.guild.id})
        re = (re_raw.get('message_id'),) if re_raw else None

        if message.author != self.bot.user:
            return

        if re is not None:
            if message.id == int(re[0]):
                await self.col.delete_one({'channel_id': message.channel.id, 'message_id': message.id, 'guild_id': message.guild.id})

                print(f"Giveaway message deleted in {message.guild.name} - {message.guild.id}")

    @commands.hybrid_command(name="gend", description="Ends a giveaway before its ending time.", help="Ends a giveaway before its ending time.")
    @blacklist_check()
    @ignore_check()
    @commands.cooldown(1, 5, commands.BucketType.user)
    @commands.guild_only()
    @security_manager_check()
    @commands.has_guild_permissions(manage_guild=True)
    async def gend(self, ctx, message_id = None):
        if message_id:
            try:
                int(message_id)
            except ValueError:
                embed = discord.Embed(title=f"{emojis.ICONS_WARNING} Access Denied",
                                      description="Invalid message ID provided.", color=0x000000)
                message = await ctx.send(view = embed_to_view(embed))
                await asyncio.sleep(5)
                await message.delete()
                return

        if message_id is not None:
            current_time = datetime.datetime.now().timestamp()
            re_raw = await self.col.find_one({'message_id': int(message_id)})
            re = (re_raw.get('ends_at'), re_raw.get('guild_id'), re_raw.get('message_id'), re_raw.get('host_id'), re_raw.get('winners'), re_raw.get('prize'), re_raw.get('channel_id')) if re_raw else None
            
            if re is None:
                embed = discord.Embed(title=f"{emojis.CROSSICON} Error",
                                      description=f" The giveaway was not found.", color=0x000000)
                message = await ctx.send(view = embed_to_view(embed))
                await asyncio.sleep(5)
                await message.delete()
                return

            ch = self.bot.get_channel(int(re[6]))
            message = await ch.fetch_message(int(message_id))

            users = [i.id async for i in message.reactions[0].users()]
            users.remove(self.bot.user.id)

            if len(users) < 1:
                await ctx.send(f"{emojis.TICK} Successfully Ended the giveaway in <#{int(re[6])}>")
                await message.reply(f"No one won the **{re[5]}** giveaway, due to Not enough participants.")
                await self.col.delete_one({'message_id': message.id, 'guild_id': message.guild.id})
                return

            winner = ', '.join(f'<@!{i}>' for i in random.sample(users, k=int(re[4])))

            desc = (
                f"<:dot_flowerblue_nc:1526949160857894922> Winner(s): {winner}\n"
                f"<:dot_flowerblue_nc:1526949160857894922> Ended: <t:{int(current_time)}:R>\n"
                f"<:dot_flowerblue_nc:1526949160857894922> Hosted by: <@{int(re[3])}>"
            )
            embed = discord.Embed(
                title=f"<a:giveaway:1526948648066482388> {re[5]} <a:giveaway:1526948648066482388>",
                description=desc,
                color=0x1ABC9C
            )
            embed.timestamp = discord.utils.utcnow()

            embed.set_footer(text=f"Ended")

            await message.edit(view=embed_to_view(embed))

            if int(ctx.channel.id) != int(re[6]):
                await ctx.send(f"{emojis.TICK} Successfully ended the giveaway in <#{int(re[6])}>")

            await message.reply(f" Congrats {winner}, you won **{re[5]}!**, Hosted by <@{int(re[3])}>")
            await self.col.delete_one({'message_id': message.id, 'guild_id': message.guild.id})
            #print(f"[Gend] Giveaway Ended - {message.guild.name} ({message.guild.id}) - ({re[5]})")

        elif ctx.message.reference:
            re_raw = await self.col.find_one({'message_id': ctx.message.reference.resolved.id})
            re = (re_raw.get('ends_at'), re_raw.get('guild_id'), re_raw.get('message_id'), re_raw.get('host_id'), re_raw.get('winners'), re_raw.get('prize'), re_raw.get('channel_id')) if re_raw else None

            if re is None:
                return await ctx.send(f"The giveaway was not found.")

            current_time = datetime.datetime.now().timestamp()

            message = await ctx.fetch_message(ctx.message.reference.message_id)

            users = [i.id async for i in message.reactions[0].users()]
            if self.bot.user and self.bot.user.id in users:
                users.remove(self.bot.user.id)

            if len(users) < 1:
                await message.reply(f"No one won the **{re[5]}** giveaway, due to not enough participants.")
                await self.col.delete_one({'message_id': message.id, 'guild_id': message.guild.id})
                return

            winner = ', '.join(f'<@!{i}>' for i in random.sample(users, k=int(re[4])))

            desc = (
                f"<:dot_flowerblue_nc:1526949160857894922> Winner(s): {winner}\n"
                f"<:dot_flowerblue_nc:1526949160857894922> Ended: <t:{int(current_time)}:R>\n"
                f"<:dot_flowerblue_nc:1526949160857894922> Hosted by: <@{int(re[3])}>"
            )
            embed = discord.Embed(
                title=f"<a:giveaway:1526948648066482388> {re[5]} <a:giveaway:1526948648066482388>",
                description=desc,
                color=0x1ABC9C
            )
            embed.timestamp = discord.utils.utcnow()

            embed.set_footer(text=f"Ended at")

            await message.edit(view=embed_to_view(embed))

            await message.reply(f"💐 Congrats {winner}, you won **{re[5]}!**, Hosted by <@{int(re[3])}>")
            await self.col.delete_one({'message_id': message.id, 'guild_id': message.guild.id})
            #print(f"[Gend] Giveaway Ended - {message.guild.name} ({message.guild.id}) - ({re[5]})")

        else:
            await ctx.send("Please reply to the giveaway message or provide the giveaway ID.")

    @commands.hybrid_command(description="Rerolls a giveaway on replying the giveaway message.", help="Rerolls a giveaway on replying the giveaway message.")
    @blacklist_check()
    @ignore_check()
    @commands.cooldown(1, 5, commands.BucketType.user)
    @commands.guild_only()
    @security_manager_check()
    @commands.has_guild_permissions(manage_guild=True)
    async def greroll(self, ctx, message_id: typing.Optional[int] = None):
        if not ctx.message.reference:
            message = await ctx.reply("Reply this command with the Giveaway Ended message to reroll.")
            await asyncio.sleep(5)
            await message.delete()
            return

        if ctx.message.reference:
            message_id = ctx.message.reference.resolved.id

        message = await ctx.fetch_message(message_id)

        if ctx.message.reference.resolved.author.id != self.bot.user.id :
            embed = discord.Embed(title=f"{emojis.ICONS_WARNING} Access Denied",
                                  description=f"The giveaway was not found.", color=0x000000)
            message = await ctx.send(view = embed_to_view(embed))
            await asyncio.sleep(5)
            await message.delete()
            return
        re_raw = await self.col.find_one({'message_id': message.id})
        re = (re_raw.get('message_id'),) if re_raw else None

        if re is not None:
            embed = discord.Embed(title=f"{emojis.ICONS_WARNING} Access Denied",
                                  description=f"The giveaway is currently running. Please use the `gend` command instead to end the giveaway.", color=0x000000)
            message = await ctx.send(view = embed_to_view(embed))
            await asyncio.sleep(5)
            await message.delete()
            return

        if not message.reactions:
            await ctx.send(view=embed_to_view(discord.Embed(
                title=f"{emojis.ICONS_WARNING} Reroll Failed",
                description="No reactions found on this giveaway message.",
                color=0x000000,
            )))
            return

        prize = "the"
        if message.embeds and message.embeds[0].title:
            prize = message.embeds[0].title.replace(str(emojis.GIVEAWAY), "").strip() or prize

        users = [i.id async for i in message.reactions[0].users()]
        if self.bot.user.id in users:
            users.remove(self.bot.user.id)

        if len(users) < 1:
            await message.reply(f"No one won the **{prize}** giveaway, due to not enough participants.")
            return

        winners = random.sample(users, k=1)
        await message.reply(f" The new winner is "+", ".join(f"<@{i}>" for i in winners)+". Congratulations!")

    def convert(self, time):
        pos = ["s", "m", "h", "d"]
        time_dict = {"s": 1, "m": 60, "h": 3600, "d": 86400, "f": 259200}

        unit = time[-1]
        if unit not in pos:
            return -1

        try:
            val = int(time[:-1])
        except ValueError:
            return -2

        return val * time_dict[unit]


    @commands.hybrid_command(name="glist", description="Lists all ongoing giveaways.")
    @blacklist_check()
    @ignore_check()
    @commands.cooldown(1, 5, commands.BucketType.user)
    @commands.guild_only()
    @security_manager_check()
    @commands.has_guild_permissions(manage_guild=True)
    async def glist(self, ctx):
        giveaways_raw = await self.col.find({'guild_id': ctx.guild.id}).to_list(length=None)
        giveaways = [(g.get('prize'), g.get('ends_at'), g.get('winners'), g.get('message_id')) for g in giveaways_raw]

        if not giveaways:
            embed = discord.Embed(description=" No ongoing giveaways.", color=0x000000)
            await ctx.send(view = embed_to_view(embed))
            return

        embed = discord.Embed(title="Ongoing Giveaways", color=0x000000)
        for giveaway in giveaways:
            prize, ends_at, winners, message_id = giveaway
            ends = datetime.datetime.fromtimestamp(ends_at)
            embed.add_field(
                name=prize,
                value=f"Ends: <t:{int(ends_at)}:R> (<t:{int(ends_at)}:f>)\nWinners: {winners}\n[Jump to Message](https://discord.com/channels/{ctx.guild.id}/{ctx.channel.id}/{message_id})",
                inline=False
            )

        await ctx.send(view = embed_to_view(embed))
