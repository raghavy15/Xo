from utils.database import get_collection
from utils import emojis

import asyncio
import discord
from discord.ext import commands
from utils.Tools import *
from utils.cv2_compat import embed_to_view, embeds_to_view
from utils.automod_cache import invalidate_automod_state

class ShowRules(discord.ui.View):
    def __init__(self, author, selected_events):
        super().__init__(timeout=60)
        self.author = author
        self.selected_events = selected_events

    @discord.ui.button(label="Show Rules", style=discord.ButtonStyle.secondary)
    async def show_rules(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user != self.author:
            await interaction.response.send_message("You are not allowed to interact with this button.", ephemeral=True)
            return

        rules = {
            "Anti NSFW link": "__**Anti NSFW Link**__:\nâ€¢ Takes action if the message contains a NSFW link.\nâ€¢ Default punishment: Block message (unchangeable)",
            "Anti caps": "__**Anti Caps**__:\nâ€¢ Takes action if the message contains >70% caps.\nâ€¢ Messages under 45 characters are bypassed\nâ€¢ Default punishment: Mute (1 minutes)",
            "Anti link": "__**Anti Link**__:\nâ€¢ Takes action if the message contains a link.\nâ€¢ Server invites, Spotify Music and GIF links are bypassed\nâ€¢ Default punishment: Mute (7 minutes)",
            "Anti invites": "__**Anti Invites**__:\nâ€¢ Takes action if the message contains a Discord server invite.\nâ€¢ Invites from the current server are bypassed\nâ€¢ Default punishment: Mute (12 minutes)",
            "Anti emoji spam": "__**Anti Emoji Spam**__:\nâ€¢ Takes action if a message contains more than 5 emojis.\nâ€¢ Default punishment: Mute (1 minute)",
            "Anti mass mention": "__**Anti Mass Mention**__:\nâ€¢ Takes action if a message contains more than 4 mentions.\nâ€¢ Default punishment: Mute (3 minutes)",
            "Anti spam": "__**Anti Spam**__:\nâ€¢ Takes action if more than 5 messages are sent rapidly in a short time.\nâ€¢ Default punishment: Mute (12 minutes)",
        }

        enabled_rules = "\n\n".join([rules[event] for event in self.selected_events])

        embed = discord.Embed(title="Enabled Automod Rules", description=enabled_rules, color=0xff0000)
        embed.set_footer(text="Punishment type of each event is changeable except for Anti NSFW.")
        await interaction.response.send_message(view = embed_to_view(embed), ephemeral=True)
        

class ConfirmDisable(discord.ui.View):
    def __init__(self, author):
        super().__init__(timeout=30)
        self.author = author
        self.value = None

    @discord.ui.button(label="Yes", style=discord.ButtonStyle.danger)
    async def confirm(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user != self.author:
            await interaction.response.send_message("You are not allowed to interact with this button.", ephemeral=True)
            return
        self.value = True
        self.stop()

    @discord.ui.button(label="No", style=discord.ButtonStyle.secondary)
    async def cancel(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user != self.author:
            await interaction.response.send_message("You are not allowed to interact with this button.", ephemeral=True)
            return
        self.value = False
        self.stop()


        
class Automod(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.default_punishment = "Mute"

    async def cog_load(self) -> None:
        await self.init_db()

    async def _refresh_automod_cache(self, guild_id: int) -> None:
        await invalidate_automod_state(guild_id)

    async def get_exempt_roles_channels(self, guild_id):
        col = await get_collection('automod_ignored')
        roles = await col.find({"guild_id": guild_id, "type": "role"}).to_list(length=None)
        channels = await col.find({"guild_id": guild_id, "type": "channel"}).to_list(length=None)
        
        exempt_roles = [discord.Object(r["id"]) for r in roles]
        exempt_channels = [discord.Object(c["id"]) for c in channels]
        
        return exempt_roles, exempt_channels
            

    async def is_automod_enabled(self, guild_id):
        col = await get_collection('automod')
        result = await col.find_one({"guild_id": guild_id})
        return result is not None and result.get("enabled", 0) == 1

    async def update_punishments(self, guild_id, event, punishment):
        col = await get_collection('automod_punishments')
        await col.update_one(
            {"guild_id": guild_id, "event": event},
            {"$set": {"punishment": punishment}},
            upsert=True
        )

    async def get_current_punishments(self, guild_id):
        col = await get_collection('automod_punishments')
        docs = await col.find({"guild_id": guild_id, "event": {"$ne": "Anti NSFW link"}}).to_list(length=None)
        return [(doc["event"], doc.get("punishment")) for doc in docs]

    async def is_anti_nsfw_enabled(self, guild_id):
        col = await get_collection('automod_punishments')
        result = await col.find_one({"guild_id": guild_id, "event": "Anti NSFW link"})
        return result is not None

                

    async def init_db(self):
        pass # MongoDB collections are created automatically

    @commands.hybrid_group(invoke_without_command=True)
    @blacklist_check()
    @ignore_check()
    @commands.cooldown(1, 4, commands.BucketType.user)
    @commands.guild_only()
    @security_manager_check()
    async def automod(self, ctx):
        if ctx.subcommand_passed is None:
            await ctx.send_help(ctx.command)
            ctx.command.reset_cooldown(ctx)

    @automod.command(name="enable", help="Enable Automod on the server.")
    @blacklist_check()
    @ignore_check()
    @commands.cooldown(1, 5, commands.BucketType.user)
    @commands.max_concurrency(1, per=commands.BucketType.default, wait=False)
    @commands.guild_only()
    @commands.has_permissions(administrator=True)
    @bot_has_permissions(manage_guild=True)
    async def enable(self, ctx):
        guild_id = ctx.guild.id
        if ctx.author != ctx.guild.owner and ctx.author.top_role.position < ctx.guild.me.top_role.position:
            embed = discord.Embed(title=f"{emojis.CROSSICON} Access Denied", description="Your top role must be at the **same** position or **higher** than my top role.", color=0x000000)
            embed.set_footer(text=f"â€œ{ctx.command.qualified_name}â€ Command executed by {ctx.author}",
                       icon_url=ctx.author.avatar.url if ctx.author.avatar else ctx.author.default_avatar.url)
            await ctx.send(view = embed_to_view(embed))
            return
            
        if await self.is_automod_enabled(guild_id):
            embed=discord.Embed(title=f"Automod Settings for {ctx.guild.name}", description=f"**{emojis.DENIED} Your Server already has Automoderation Enabled.**\n\nCurrent Status: {emojis.ENABLED_160063} Enabled\nTo Disable use `{ctx.prefix}automod disable`", color=0x000000)
            embed.set_thumbnail(url=self.bot.user.display_avatar.url)
            embed.set_footer(text=f"â€œ{ctx.command.qualified_name}â€ Command executed by {ctx.author}",
                   icon_url=ctx.author.avatar.url if ctx.author.avatar else ctx.author.default_avatar.url)
            await ctx.send(view = embed_to_view(embed))
            return

        events = [
            "Anti spam",
            "Anti caps",
            "Anti link",
            "Anti invites",
            "Anti mass mention",
            "Anti emoji spam",
            "Anti NSFW link",
        ]

        embed = discord.Embed(title=f"{ctx.guild.name}'s Automod Setup", color=0x000000)
        embed.set_thumbnail(url=self.bot.user.display_avatar.url)
        embed.description = "\n".join([f"{emojis.CROSSICON}{emojis.TICK} : {event}" for event in events])

        select_menu = discord.ui.Select(placeholder="Select events to enable", min_values=1, max_values=len(events), options=[
            discord.SelectOption(label=event, value=event) for event in events
        ])

        async def select_callback(interaction):
            if interaction.user != ctx.author:
                await interaction.response.send_message("You are not allowed to interact with this menu.", ephemeral=True)
                return
            selected_events = interaction.data.get("values") or select_menu.values
            await self.enable_automod(ctx, guild_id, selected_events, interaction)
        select_menu.callback = select_callback

        enable_all_button = discord.ui.Button(label="Enable for All Events", style=discord.ButtonStyle.primary)

        async def enable_all_callback(interaction):
            if interaction.user != ctx.author:
                await interaction.response.send_message("You are not allowed to interact with this button.", ephemeral=True)
                return
                
            await self.enable_automod(ctx, guild_id, events, interaction)

        enable_all_button.callback = enable_all_callback

        cancel_button = discord.ui.Button(label="Cancel", style=discord.ButtonStyle.danger)

        async def cancel_callback(interaction):
            if interaction.user != ctx.author:
                await interaction.response.send_message("You are not allowed to interact with this button.", ephemeral=True)
                return
                
            select_menu.disabled = True
            enable_all_button.disabled = True
            cancel_button.disabled = True
            embed.title = "Automod Setup Cancelled"
            await interaction.response.edit_message(view=embed_to_view(embed, view=view))

        cancel_button.callback = cancel_callback

        view = discord.ui.View()
        view.add_item(select_menu)
        view.add_item(enable_all_button)
        view.add_item(cancel_button)

        await ctx.send(view = embed_to_view(embed, view = view))
        

    async def enable_automod(self, ctx, guild_id, selected_events, interaction):
        try:
            col_am = await get_collection('automod')
            await col_am.update_one({"guild_id": guild_id}, {"$set": {"enabled": 1}}, upsert=True)
            col_punish = await get_collection('automod_punishments')
            for event in selected_events:
                await col_punish.update_one(
                    {"guild_id": guild_id, "event": event},
                    {"$set": {"punishment": self.default_punishment}},
                    upsert=True
                )

            await self._refresh_automod_cache(guild_id)

            nsfw_rule_note = ""
            if "Anti NSFW link" in selected_events:
                exempt_roles, exempt_channels = await self.get_exempt_roles_channels(guild_id)
                nsfw_keywords = [
                    "porn", "xxx", "adult", "sex", "nsfw", "xnxx", "onlyfans", "brazzers",
                    "xhamster", "xvideos", "pornhub", "redtube", "livejasmin", "youporn",
                    "tube8", "pornhat", "swxvid", "ixxx",
                ]

                try:
                    existing_rules = await interaction.guild.fetch_automod_rules()
                    for rule in existing_rules:
                        if rule.name == "Anti NSFW Links":
                            await rule.delete(reason="Automod - refreshing Anti NSFW Link rule")
                            break

                    await interaction.guild.create_automod_rule(
                        name="Anti NSFW Links",
                        event_type=discord.AutoModRuleEventType.message_send,
                        trigger=discord.AutoModTrigger(
                            type=discord.AutoModRuleTriggerType.keyword,
                            keyword_filter=nsfw_keywords,
                        ),
                        actions=[
                            discord.AutoModRuleAction(type=discord.AutoModRuleActionType.block_message),
                        ],
                        enabled=True,
                        exempt_roles=exempt_roles,
                        exempt_channels=exempt_channels,
                        reason="Automod - Anti NSFW Link setup",
                    )
                except discord.Forbidden:
                    nsfw_rule_note = "\n\nâš ï¸ Could not create the Discord Anti NSFW rule â€” I need **Manage Server** permission."
                except discord.HTTPException:
                    nsfw_rule_note = "\n\nâš ï¸ Discord rejected the Anti NSFW rule. Other automod events are still enabled."

            embed = discord.Embed(title="Automod Enabled Successfully", color=0x000000)
            enabled_lines = "\n".join(
                f"{emojis.CROSSICON}{emojis.TICK} : {event}" for event in selected_events
            )
            disabled_lines = "\n".join(
                f"{emojis.CROSSICON}{emojis.TICK} : {event}"
                for event in [
                    "Anti spam", "Anti caps", "Anti link", "Anti invites",
                    "Anti mass mention", "Anti emoji spam", "Anti NSFW link",
                ]
                if event not in selected_events
            )
            embed.description = enabled_lines
            if disabled_lines:
                embed.description += f"\n{disabled_lines}"
            if nsfw_rule_note:
                embed.description += nsfw_rule_note

            enable_logging_button = discord.ui.Button(label="Enable Automod Logging", style=discord.ButtonStyle.success)

            async def enable_logging_callback(logging_interaction: discord.Interaction):
                if logging_interaction.user != ctx.author:
                    await logging_interaction.response.send_message(
                        "You are not allowed to interact with this button.", ephemeral=True
                    )
                    return

                if not logging_interaction.guild.me.guild_permissions.manage_channels:
                    await logging_interaction.response.send_message(
                        "I do not have permission to create channels.", ephemeral=True
                    )
                    return

                overwrites = {
                    logging_interaction.guild.default_role: discord.PermissionOverwrite(view_channel=False),
                    logging_interaction.guild.me: discord.PermissionOverwrite(view_channel=True),
                }

                try:
                    for channel in logging_interaction.guild.channels:
                        if channel.name == "kyrox-automod":
                            await logging_interaction.response.send_message(
                                'A logging channel with the name "quantum-automod" already exists.',
                                ephemeral=True,
                            )
                            return

                    log_channel = await logging_interaction.guild.create_text_channel(
                        "quantum-automod", overwrites=overwrites
                    )

                    col_log = await get_collection('automod_logging')
                    await col_log.update_one(
                        {"guild_id": logging_interaction.guild.id},
                        {"$set": {"log_channel": log_channel.id}},
                        upsert=True
                    )

                    await self._refresh_automod_cache(logging_interaction.guild.id)
                    await logging_interaction.response.send_message(
                        f"Logging channel {log_channel.mention} created and set successfully.",
                        ephemeral=True,
                    )
                except discord.HTTPException as exc:
                    await logging_interaction.response.send_message(
                        f"Failed to create logging channel: {exc}", ephemeral=True
                    )

            enable_logging_button.callback = enable_logging_callback

            view = ShowRules(ctx.author, selected_events)
            view.add_item(enable_logging_button)

            await interaction.response.edit_message(view=embed_to_view(embed, view=view))
        except discord.HTTPException:
            if not interaction.response.is_done():
                await interaction.response.send_message(
                    "Failed to finish automod setup. Please try again.",
                    ephemeral=True,
                )
            else:
                await interaction.followup.send(
                    "Failed to finish automod setup. Please try again.",
                    ephemeral=True,
                )
        except Exception:
            if not interaction.response.is_done():
                await interaction.response.send_message(
                    "Something went wrong while enabling automod. Please try again.",
                    ephemeral=True,
                )
            else:
                await interaction.followup.send(
                    "Something went wrong while enabling automod. Please try again.",
                    ephemeral=True,
                )
            raise


    

    @automod.command(name="punishment", aliases=["punish"], help="Set the punishment for automod events.")
    @blacklist_check()
    @ignore_check()
    @commands.cooldown(1, 5, commands.BucketType.user)
    @commands.max_concurrency(1, per=commands.BucketType.default, wait=False)
    @commands.guild_only()
    @commands.has_permissions(administrator=True)
    async def punishment(self, ctx):
        guild_id = ctx.guild.id
        if ctx.author != ctx.guild.owner and ctx.author.top_role.position < ctx.guild.me.top_role.position:
            embed = discord.Embed(title=f"{emojis.CROSSICON} Access Denied", description="Your top role must be at the **same** position or **higher** than my top role.", color=0x000000)
            embed.set_footer(text=f"â€œ{ctx.command.qualified_name}â€ Command executed by {ctx.author}",
                       icon_url=ctx.author.avatar.url if ctx.author.avatar else ctx.author.default_avatar.url)
            await ctx.send(view = embed_to_view(embed))
            return
            
        if not await self.is_automod_enabled(guild_id):
            embed=discord.Embed(title=f"Automod Settings for {ctx.guild.name}", description=f"Uhh, looks like your server hasn't enabled Automoderation.\n\nCurrent Status:  {emojis.DISABLED1} Disabled\nTo Enable use `{ctx.prefix}automod enable`", color=0x000000)
            embed.set_thumbnail(url=self.bot.user.display_avatar.url)
            embed.set_footer(text=f"â€œ{ctx.command.qualified_name}â€ Command executed by {ctx.author}",
                   icon_url=ctx.author.avatar.url if ctx.author.avatar else ctx.author.default_avatar.url)
            await ctx.send(view = embed_to_view(embed))
            return

        current_punishments = await self.get_current_punishments(guild_id)
        embed = discord.Embed(title=f"Current Automod Punishments for {ctx.guild.name}", color=0x000000)
        punishment_map = {}
        for event, punishment in current_punishments:
            punishment_map[event] = punishment or "None"
            embed.add_field(name=event, value=punishment or "None", inline=False)
            embed.set_footer(text="Keep the default punishment (Mute) to prevent server raids without kicking or banning raiders", icon_url=self.bot.user.display_avatar.url)
            embed.set_thumbnail(url=self.bot.user.display_avatar.url)

        events = [event for event, _ in current_punishments]
        select = discord.ui.Select(placeholder="Select events to update punishment", options=[
            discord.SelectOption(label=event) for event in events
        ], min_values=1, max_values=len(events))

        async def select_callback(interaction):
            if interaction.user != ctx.author:
                await interaction.response.send_message("You cannot interact with this menu.", ephemeral=True)
                return

            selected_events = select.values
            await interaction.response.send_message("You selected: " + ", ".join(selected_events))

            punishment_buttons = discord.ui.View()
            for punishment in ["Mute", "Kick", "Ban"]:
                button = discord.ui.Button(label=punishment, style=discord.ButtonStyle.danger)

                async def punishment_callback(button_interaction, selected_events=selected_events, punishment=punishment):
                    if button_interaction.user != ctx.author:
                        await button_interaction.response.send_message("You cannot interact with this button.", ephemeral=True)
                        return

                    
                    for event in selected_events:
                        await self.update_punishments(guild_id, event, punishment)

                    updated_punishments = await self.get_current_punishments(guild_id)
                    updated_embed = discord.Embed(title=f"Updated Automod Punishments for {ctx.guild.name}", color=0x000000)
                    for event, punishment in updated_punishments:
                        updated_embed.add_field(name=event, value=punishment or "None", inline=False)
                        updated_embed.set_footer(text="You can modify the punishments by running the command again.", icon_url=self.bot.user.display_avatar.url)
                        updated_embed.set_thumbnail(url=self.bot.user.display_avatar.url)

                    
                    await button_interaction.response.edit_message(view = embed_to_view(updated_embed, view = None))

                button.callback = punishment_callback
                punishment_buttons.add_item(button)

            await interaction.edit_original_response(view=punishment_buttons)

        select.callback = select_callback
        view = discord.ui.View()
        view.add_item(select)

        await ctx.send(view = embed_to_view(embed, view = view))




    @automod.group(name="ignore", aliases=["exempt", "whitelist", "wl"], help="Manage whitelisted roles and channels for Automod.")
    @blacklist_check()
    @ignore_check()
    @commands.cooldown(1, 4, commands.BucketType.user)
    @commands.guild_only()
    @security_manager_check()
    async def ignore(self, ctx):
        if ctx.subcommand_passed is None:
            await ctx.send_help(ctx.command)
            ctx.command.reset_cooldown(ctx)
            

    @ignore.command(name="channel", help="Add a channel to the whitelist.")
    @blacklist_check()
    @ignore_check()
    @commands.cooldown(1, 5, commands.BucketType.user)
    @commands.max_concurrency(1, per=commands.BucketType.default, wait=False)
    @commands.guild_only()
    @commands.has_permissions(administrator=True)
    async def ignore_channel(self, ctx, channel: discord.TextChannel):
        guild_id = ctx.guild.id
        if ctx.author != ctx.guild.owner and ctx.author.top_role.position < ctx.guild.me.top_role.position:
            embed = discord.Embed(title=f"{emojis.CROSSICON} Access Denied", description="Your top role must be at the **same** position or **higher** than my top role.", color=0x000000)
            embed.set_thumbnail(url=self.bot.user.display_avatar.url)
            embed.set_footer(text=f"â€œ{ctx.command.qualified_name}â€ Command executed by {ctx.author}",
                       icon_url=ctx.author.avatar.url if ctx.author.avatar else ctx.author.default_avatar.url)
            await ctx.send(view = embed_to_view(embed))
            embed.set_footer(text=f"â€œ{ctx.command.qualified_name}â€  Command executed by {ctx.author}",
                       icon_url=ctx.author.avatar.url if ctx.author.avatar else ctx.author.default_avatar.url)
            await ctx.send(view = embed_to_view(embed))
            return

        if not await self.is_automod_enabled(guild_id):
            embed=discord.Embed(title=f"Automod Settings for {ctx.guild.name}", description=f"Uhh, looks like your server hasn't enabled Automoderation.\n\nCurrent Status:  {emojis.DISABLED1} Disabled\nTo Enable use `{ctx.prefix}automod enable`", color=0x000000)
            embed.set_thumbnail(url=self.bot.user.display_avatar.url)
            embed.set_footer(text=f"â€œ{ctx.command.qualified_name}â€  Command executed by {ctx.author}",
                   icon_url=ctx.author.avatar.url if ctx.author.avatar else ctx.author.default_avatar.url)
            await ctx.send(view = embed_to_view(embed))
            return

        col = await get_collection('automod_ignored')
        if await col.find_one({"guild_id": guild_id, "type": "channel", "id": channel.id}):
            embed = discord.Embed(title="__Channel Already Whitelisted!__", description=f"{emojis.DENIED} The channel {channel.mention} is already in the ignore list.\n\nâžœ Use **{ctx.prefix}automod unignore channel {channel.mention}** to remove it.", color=0x000000)
            embed.set_footer(text=f"â€œ{ctx.command.qualified_name}â€  Command executed by {ctx.author}",
                   icon_url=ctx.author.avatar.url if ctx.author.avatar else ctx.author.default_avatar.url)
            await ctx.send(view = embed_to_view(embed))
            return
                
        count = await col.count_documents({"guild_id": guild_id, "type": "channel"})
        if count >= 10:
            await ctx.send("You can only ignore up to 10 channels.")
            return

        await col.update_one({"guild_id": guild_id, "type": "channel", "id": channel.id}, {"$set": {}}, upsert=True)
        await self._refresh_automod_cache(guild_id)

        if await self.is_anti_nsfw_enabled(guild_id):
            try:
                rules = await ctx.guild.fetch_automod_rules()
                for rule in rules:
                    if rule.name == "Anti NSFW Links":
                        exempt_channels = list(rule.exempt_channels)  
                        exempt_channels.append(channel) 
                        await rule.edit(
                            exempt_channels=exempt_channels,
                            reason="Channel exempted from Anti NSFW Links via automod ignore command"
                        )
                        break
            except discord.HTTPException:
                pass

                
        success = discord.Embed(title=f"{emojis.TICK} Channel Whitelisted", description=f"The channel {channel.mention} has been added to the ignore list \n\nâžœ Use `{ctx.prefix}automod ignore show` to view the ignore list.", color=0x000000)
        success.set_thumbnail(url=self.bot.user.display_avatar.url)
        success.set_footer(text=f"â€œ{ctx.command.qualified_name}â€ Command executed by {ctx.author}",
               icon_url=ctx.author.avatar.url if ctx.author.avatar else ctx.author.default_avatar.url)

        await ctx.send(view = embed_to_view(success))

    @ignore.command(name="role", help="Add a role to the whitelist.")
    @blacklist_check()
    @ignore_check()
    @commands.cooldown(1, 5, commands.BucketType.user)
    @commands.max_concurrency(1, per=commands.BucketType.default, wait=False)
    @commands.guild_only()
    @commands.has_permissions(administrator=True)
    async def ignore_role(self, ctx, role: discord.Role):
        guild_id = ctx.guild.id
        if ctx.author != ctx.guild.owner and ctx.author.top_role.position < ctx.guild.me.top_role.position:
            embed = discord.Embed(title=f"{emojis.CROSSICON} Access Denied", description="Your top role must be at the **same** position or **higher** than my top role.", color=0x000000)
            embed.set_footer(text=f"â€œ{ctx.command.qualified_name}â€ Command executed by {ctx.author}",
                       icon_url=ctx.author.avatar.url if ctx.author.avatar else ctx.author.default_avatar.url)
            await ctx.send(view = embed_to_view(embed))
            return

        if not await self.is_automod_enabled(guild_id):
            embed=discord.Embed(title=f"Automod Settings for {ctx.guild.name}", description=f"Uhh, looks like your server hasn't enabled Automoderation.\n\nCurrent Status:  {emojis.DISABLED1}> Disabled\nTo Enable use `{ctx.prefix}automod enable`", color=0x000000)
            embed.set_thumbnail(url=self.bot.user.display_avatar.url)
            embed.set_footer(text=f"â€œ{ctx.command.qualified_name}â€ Command executed by {ctx.author}",
                   icon_url=ctx.author.avatar.url if ctx.author.avatar else ctx.author.default_avatar.url)
            await ctx.send(view = embed_to_view(embed))
            return

        col = await get_collection('automod_ignored')
        if await col.find_one({"guild_id": guild_id, "type": "role", "id": role.id}):
            embed = discord.Embed(title="__Role Already Whitelisted!__", description=f"{emojis.CROSSICON} The role {role.mention} is already in the ignore list.\n\nâžœ Use **{ctx.prefix}automod unignore role {role.mention}** to remove it.", color=0x000000)
            embed.set_footer(text=f"â€œ{ctx.command.qualified_name}â€ Command executed by {ctx.author}",
                   icon_url=ctx.author.avatar.url if ctx.author.avatar else ctx.author.default_avatar.url)
            await ctx.send(view = embed_to_view(embed))
            return
            
        count = await col.count_documents({"guild_id": guild_id, "type": "role"})
        if count >= 10:
            await ctx.send("You can only ignore up to 10 roles.")
            return

        await col.update_one({"guild_id": guild_id, "type": "role", "id": role.id}, {"$set": {}}, upsert=True)
        await self._refresh_automod_cache(guild_id)

        if await self.is_anti_nsfw_enabled(guild_id):
            try:
                rules = await ctx.guild.fetch_automod_rules()
                for rule in rules:
                    if rule.name == "Anti NSFW Links":
                        exempt_roles = list(rule.exempt_roles)  
                        exempt_roles.append(role) 
                        await rule.edit(
                            exempt_roles=exempt_roles,
                            reason="Role exempted from Anti NSFW Links via automod ignore command"
                        )
                        break
            except discord.HTTPException:
                pass
                
                
        success = discord.Embed(title=f"{emojis.TICK} Role Whitelisted", description=f"The role {role.mention} has been added to the ignore list \n\nâžœ Use `{ctx.prefix}automod ignore show` to view the ignore list.", color=0x000000)
        success.set_thumbnail(url=self.bot.user.display_avatar.url)
        success.set_footer(text=f"â€œ{ctx.command.qualified_name}â€ Command executed by {ctx.author}",
               icon_url=ctx.author.avatar.url if ctx.author.avatar else ctx.author.default_avatar.url)

        await ctx.send(view = embed_to_view(success))

    @ignore.command(name="show", aliases=["view", "list", "config"], help="Show the whitelisted roles and channels.")
    @blacklist_check()
    @ignore_check()
    @commands.cooldown(1, 5, commands.BucketType.user)
    @commands.max_concurrency(1, per=commands.BucketType.default, wait=False)
    @commands.guild_only()
    @commands.has_permissions(administrator=True)
    async def ignore_show(self, ctx):
        guild_id = ctx.guild.id
        if ctx.author != ctx.guild.owner and ctx.author.top_role.position < ctx.guild.me.top_role.position:
            embed = discord.Embed(title=f"{emojis.CROSSICON} Access Denied", description="Your top role must be at the **same** position or **higher** than my top role.", color=0x000000)
            embed.set_footer(text=f"â€œ{ctx.command.qualified_name}â€ Command executed by {ctx.author}",
                       icon_url=ctx.author.avatar.url if ctx.author.avatar else ctx.author.default_avatar.url)
            await ctx.send(view = embed_to_view(embed))
            return

        if not await self.is_automod_enabled(guild_id):
            embed=discord.Embed(title=f"Automod Settings for {ctx.guild.name}", description=f"Uhh, looks like your server hasn't enabled Automoderation.\n\nCurrent Status:  {emojis.DISABLED1} Disabled\nTo Enable use `{ctx.prefix}automod enable`", color=0x000000)
            embed.set_thumbnail(url=self.bot.user.display_avatar.url)
            embed.set_footer(text=f"â€œ{ctx.command.qualified_name}â€ Command executed by {ctx.author}",
                   icon_url=ctx.author.avatar.url if ctx.author.avatar else ctx.author.default_avatar.url)
            await ctx.send(view = embed_to_view(embed))
            return
            

        col = await get_collection('automod_ignored')
        docs = await col.find({"guild_id": guild_id}).to_list(length=None)
        ignored_items = [(d["type"], d["id"]) for d in docs]

        if not ignored_items:
            await ctx.reply("No ignored channels or roles found.")
            return

        ignored_channels = []
        ignored_roles = []

        for item_type, item_id in ignored_items:
            if item_type == "channel":
                channel = ctx.guild.get_channel(item_id)
                if channel:
                    ignored_channels.append(f"{channel.mention} (ID: {channel.id})")
                else:
                    ignored_channels.append(f"Deleted Channel (ID: {item_id})")
            elif item_type == "role":
                role = ctx.guild.get_role(item_id)
                if role:
                    ignored_roles.append(f"{role.mention} (ID: {role.id})")
                else:
                    ignored_roles.append(f"Deleted Role (ID: {item_id})")

        embed = discord.Embed(title="Ignored Channels & Roles for Automod", color=0x000000)

        if ignored_channels:
            embed.add_field(name="__Ignored Channels:__", value="\n".join(ignored_channels), inline=False)
        else:
            embed.add_field(name="__Ignored Channels:__", value="None", inline=False)

        if ignored_roles:
            embed.add_field(name="__Ignored Roles:__", value="\n".join(ignored_roles), inline=False)
        else:
            embed.add_field(name="__Ignored Roles:__", value="None", inline=False)

        await ctx.send(view = embed_to_view(embed))


    @ignore.command(name="reset", help="Reset the whitelist.")
    @blacklist_check()
    @ignore_check()
    @commands.cooldown(1, 5, commands.BucketType.user)
    @commands.max_concurrency(1, per=commands.BucketType.default, wait=False)
    @commands.guild_only()
    @commands.has_permissions(administrator=True)
    async def ignore_reset(self, ctx):
        guild_id = ctx.guild.id
        if ctx.author != ctx.guild.owner and ctx.author.top_role.position < ctx.guild.me.top_role.position:
            embed = discord.Embed(title=f"{emojis.CROSSICON} Access Denied", description="Your top role must be at the **same** position or **higher** than my top role.", color=0x000000)
            embed.set_footer(text=f"â€œ{ctx.command.qualified_name}â€ Command executed by {ctx.author}",
                       icon_url=ctx.author.avatar.url if ctx.author.avatar else ctx.author.default_avatar.url)
            await ctx.send(view = embed_to_view(embed))
            return

        if not await self.is_automod_enabled(guild_id):
            embed=discord.Embed(title=f"Automod Settings for {ctx.guild.name}", description=f"Uhh, looks like your server hasn't enabled Automoderation.\n\nCurrent Status:  {emojis.DISABLED1} Disabled\nTo Enable use `{ctx.prefix}automod enable`", color=0x000000)
            embed.set_thumbnail(url=self.bot.user.display_avatar.url)
            embed.set_footer(text=f"â€œ{ctx.command.qualified_name}â€ Command executed by {ctx.author}",
                   icon_url=ctx.author.avatar.url if ctx.author.avatar else ctx.author.default_avatar.url)
            await ctx.send(view = embed_to_view(embed))
            return

        col = await get_collection('automod_ignored')
        await col.delete_many({"guild_id": guild_id})
        await self._refresh_automod_cache(guild_id)
        embed=discord.Embed(title=f"Automod Settings for {ctx.guild.name}", description=f"** {emojis.TICK} | All ignored channels and roles have been reset!**\n\nTo view current Automod settings use `{ctx.prefix}automod config`", color=0x000000)
        embed.set_thumbnail(url=self.bot.user.display_avatar.url)
        embed.set_footer(text=f"â€œ{ctx.command.qualified_name}â€ Command executed by {ctx.author}",
               icon_url=ctx.author.avatar.url if ctx.author.avatar else ctx.author.default_avatar.url)
        await ctx.send(view = embed_to_view(embed))
        

    @automod.group(name="unignore", aliases=["unwhitelist", "unwl"], invoke_without_command=True, help="Remove channels and roles from the whitelist.")
    @blacklist_check()
    @ignore_check()
    @commands.cooldown(1, 5, commands.BucketType.user)
    @commands.guild_only()
    @security_manager_check()
    async def unignore(self, ctx):
        if ctx.subcommand_passed is None:
            await ctx.send_help(ctx.command)
            ctx.command.reset_cooldown(ctx)

    @unignore.command(name="channel", help="Remove a channel from the whitelist.")
    @blacklist_check()
    @ignore_check()
    @commands.cooldown(1, 5, commands.BucketType.user)
    @commands.max_concurrency(1, per=commands.BucketType.default, wait=False)
    @commands.guild_only()
    @commands.has_permissions(administrator=True)
    async def unignore_channel(self, ctx, channel: discord.TextChannel):
        guild_id = ctx.guild.id
        if ctx.author != ctx.guild.owner and ctx.author.top_role.position < ctx.guild.me.top_role.position:
            embed = discord.Embed(title=f"{emojis.CROSSICON} Access Denied", description="Your top role must be at the **same** position or **higher** than my top role.", color=0x000000)
            embed.set_footer(text=f"â€œ{ctx.command.qualified_name}â€ Command executed by {ctx.author}",
                       icon_url=ctx.author.avatar.url if ctx.author.avatar else ctx.author.default_avatar.url)
            await ctx.send(view = embed_to_view(embed))
            return

        if not await self.is_automod_enabled(guild_id):
            embed=discord.Embed(title=f"Automod Settings for {ctx.guild.name}", description=f"Uhh, looks like your server hasn't enabled Automoderation.\n\nCurrent Status:  {emojis.DISABLED1} Disabled\nTo Enable use `{ctx.prefix}automod enable`", color=0x000000)
            embed.set_thumbnail(url=self.bot.user.display_avatar.url)
            embed.set_footer(text=f"â€œ{ctx.command.qualified_name}â€ Command executed by {ctx.author}",
                   icon_url=ctx.author.avatar.url if ctx.author.avatar else ctx.author.default_avatar.url)
            await ctx.send(view = embed_to_view(embed))
            return

        if await self.is_anti_nsfw_enabled(guild_id):
            try:
                rules = await ctx.guild.fetch_automod_rules()
                for rule in rules:
                    if rule.name == "Anti NSFW Links":
                        exempt_channels = list(rule.exempt_channels)  
                        exempt_channels = [ch for ch in exempt_channels if ch.id != channel.id]
                        await rule.edit(
                            exempt_channels=exempt_channels,
                            reason="Channel removed from Anti NSFW Links exemption via automod unignore command"
                        )
                        break
            except discord.HTTPException:
                pass
        
        col = await get_collection('automod_ignored')
        result = await col.delete_many({"guild_id": guild_id, "type": "channel", "id": channel.id})

        if result.deleted_count > 0:
            embed = discord.Embed(title=f"{emojis.TICK} Success", description=f"{channel.mention} has been removed from the automod ignore list.", color=0x000000)
            embed.set_footer(text=f"â€œ{ctx.command.qualified_name}â€ Command executed by {ctx.author}",
                       icon_url=ctx.author.avatar.url if ctx.author.avatar else ctx.author.default_avatar.url)
            await ctx.send(view = embed_to_view(embed))
        else:
            embed = discord.Embed(title=f"{emojis.CROSSICON} Error", description=f"{channel.mention} is not in the automod ignore list.", color=0x000000)
            embed.set_footer(text=f"â€œ{ctx.command.qualified_name}â€ Command executed by {ctx.author}",
                       icon_url=ctx.author.avatar.url if ctx.author.avatar else ctx.author.default_avatar.url)
            await ctx.send(view = embed_to_view(embed))
            

    @unignore.command(name="role", help="Remove a role from the whitelist.")
    @blacklist_check()
    @ignore_check()
    @commands.cooldown(1, 5, commands.BucketType.user)
    @commands.max_concurrency(1, per=commands.BucketType.default, wait=False)
    @commands.guild_only()
    @commands.has_permissions(administrator=True)
    async def unignore_role(self, ctx, role: discord.Role):
        guild_id = ctx.guild.id
        if ctx.author != ctx.guild.owner and ctx.author.top_role.position < ctx.guild.me.top_role.position:
            embed = discord.Embed(title=f"{emojis.CROSSICON} Access Denied", description="Your top role must be at the **same** position or **higher** than my top role.", color=0x000000)
            embed.set_footer(text=f"â€œ{ctx.command.qualified_name}â€ Command executed by {ctx.author}",
                       icon_url=ctx.author.avatar.url if ctx.author.avatar else ctx.author.default_avatar.url)
            await ctx.send(view = embed_to_view(embed))
            return

        if not await self.is_automod_enabled(guild_id):
            embed=discord.Embed(title=f"Automod Settings for {ctx.guild.name}", description=f"Uhh, looks like your server hasn't enabled Automoderation.\n\nCurrent Status:  {emojis.DISABLED1} Disabled\nTo Enable use `{ctx.prefix}automod enable`", color=0x000000)
            embed.set_thumbnail(url=self.bot.user.display_avatar.url)
            embed.set_footer(text=f"â€œ{ctx.command.qualified_name}â€ Command executed by {ctx.author}",
                   icon_url=ctx.author.avatar.url if ctx.author.avatar else ctx.author.default_avatar.url)
            await ctx.send(view = embed_to_view(embed))
            return

        if await self.is_anti_nsfw_enabled(guild_id):
            try:
                rules = await ctx.guild.fetch_automod_rules()
                for rule in rules:
                    if rule.name == "Anti NSFW Links":
                        exempt_roles = list(rule.exempt_roles)  
                        exempt_roles = [ch for ch in exempt_roles if ch.id != role.id]
                        await rule.edit(
                            exempt_roles=exempt_roles,
                            reason="Role removed from Anti NSFW Links exemption via automod unignore command"
                        )
                        break
            except discord.HTTPException:
                pass

        
        col = await get_collection('automod_ignored')
        result = await col.delete_many({"guild_id": guild_id, "type": "role", "id": role.id})

        if result.deleted_count > 0:
            embed = discord.Embed(title=f"{emojis.TICK} Success", description=f"{role.mention} has been removed from the automod ignore list.", color=0x000000)
            embed.set_footer(text=f"â€œ{ctx.command.qualified_name}â€ Command executed by {ctx.author}",
                       icon_url=ctx.author.avatar.url if ctx.author.avatar else ctx.author.default_avatar.url)
            await ctx.send(view = embed_to_view(embed))
        else:
            embed = discord.Embed(title=f"{emojis.CROSSICON} Error", description=f"{role.mention} is not in the automod ignore list.", color=0x000000)
            embed.set_footer(text=f"â€œ{ctx.command.qualified_name}â€ Command executed by {ctx.author}",
                       icon_url=ctx.author.avatar.url if ctx.author.avatar else ctx.author.default_avatar.url)
            await ctx.send(view = embed_to_view(embed))
    

    @automod.command(name="disable", help="Disable Automod in the server.")
    @blacklist_check()
    @ignore_check()
    @commands.cooldown(1, 5, commands.BucketType.user)
    @commands.max_concurrency(1, per=commands.BucketType.default, wait=False)
    @commands.guild_only()
    @commands.has_permissions(administrator=True)
    async def disable(self, ctx):
        guild_id = ctx.guild.id
        if ctx.author != ctx.guild.owner and ctx.author.top_role.position < ctx.guild.me.top_role.position:
            embed = discord.Embed(title=f"{emojis.CROSSICON} Access Denied", description="Your top role must be at the **same** position or **higher** than my top role.", color=0x000000)
            embed.set_footer(text=f"â€œ{ctx.command.qualified_name}â€ Command executed by {ctx.author}",
                       icon_url=ctx.author.avatar.url if ctx.author.avatar else ctx.author.default_avatar.url)
            await ctx.send(view = embed_to_view(embed))
            return
            
        if not await self.is_automod_enabled(guild_id):
            embed=discord.Embed(title=f"Automod Settings for {ctx.guild.name}", description=f"Uhh, looks like your server hasn't enabled Automoderation.\n\nCurrent Status:  {emojis.DISABLED1} Disabled\nTo Enable use `{ctx.prefix}automod enable`", color=0x000000)
            embed.set_thumbnail(url=self.bot.user.display_avatar.url)
            embed.set_footer(text=f"â€œ{ctx.command.qualified_name}â€ Command executed by {ctx.author}",
                   icon_url=ctx.author.avatar.url if ctx.author.avatar else ctx.author.default_avatar.url)
            await ctx.send(view = embed_to_view(embed))
            return
            
        embed = discord.Embed(
            title="Disable Automod Confirmation",
            description="**Are you sure you want to disable Automod?**\n\nThis will remove all custom event settings, punishments, ignored roles/channels, & logging channel data.",
            color=0x000000
        )
        embed.set_footer(text="Click 'Yes' to disable Automod or 'No' to cancel.")
        embed.set_thumbnail(url=self.bot.user.display_avatar.url)

        view = ConfirmDisable(ctx.author)
        message = await ctx.send(view = embed_to_view(embed, view = view))

        await view.wait()

        if view.value is None:
            embed.title = "Automod Disable Cancelled"
            embed.description = "You took too long to respond. Automod disable process has been canceled."
            embed.color = 0x000000
            
            await message.edit(view = embed_to_view(embed, view = None))

        elif view.value:
            
            col1 = await get_collection('automod')
            col2 = await get_collection('automod_punishments')
            col3 = await get_collection('automod_ignored')
            col4 = await get_collection('automod_logging')
            await col1.delete_many({"guild_id": guild_id})
            await col2.delete_many({"guild_id": guild_id})
            await col3.delete_many({"guild_id": guild_id})
            await col4.delete_many({"guild_id": guild_id})

            await self._refresh_automod_cache(guild_id)

            rules = await ctx.guild.fetch_automod_rules()
            for rule in rules:
                if rule.name == "Anti NSFW Links":
                    try:
                        await rule.delete(reason="Automod disabled - removing Anti NSFW Link rule")
                    except discord.Forbidden:
                        pass
                    except discord.HTTPException:
                        pass


            embed.title = f"{emojis.TICK} Automod Disabled"
            embed.description = f"Automod has been successfully disabled for **{ctx.guild.name}.** \nAll settings, punishments, and logs have been removed.\n\nCurrent Status:  {emojis.DISABLED1} Disabled\nâžœ To Re-enable use `{ctx.prefix}automod enable`."
            embed.color = 0x000000
            embed.set_thumbnail(url=self.bot.user.display_avatar.url)
            embed.set_footer(text=f"â€œ{ctx.command.qualified_name}â€ Command executed by {ctx.author}",
                       icon_url=ctx.author.avatar.url if ctx.author.avatar else ctx.author.default_avatar.url)
            await message.edit(view = embed_to_view(embed, view = None))
            

        else:
            embed.title = "Automod Disable Cancelled"
            embed.description = "Automod disable process has been canceled."
            embed.color = 0x00000
            embed.set_footer(text=f"â€œ{ctx.command.qualified_name}â€ Command executed by {ctx.author}",
                       icon_url=ctx.author.avatar.url if ctx.author.avatar else ctx.author.default_avatar.url)
            await message.edit(view = embed_to_view(embed, view = None))

        

    @automod.command(name="config", aliases=["settings", "show", "view"], help="View Automod settings.")
    @blacklist_check()
    @ignore_check()
    @commands.cooldown(1, 5, commands.BucketType.user)
    @commands.max_concurrency(1, per=commands.BucketType.default, wait=False)
    @commands.guild_only()
    @commands.has_permissions(administrator=True)
    async def config(self, ctx):
        guild_id = ctx.guild.id
        if ctx.author != ctx.guild.owner and ctx.author.top_role.position < ctx.guild.me.top_role.position:
            embed = discord.Embed(title=f"{emojis.CROSSICON}Access Denied", description="Your top role must be at the **same** position or **higher** than my top role.", color=0x000000)
            embed.set_footer(text=f"â€œ{ctx.command.qualified_name}â€ Command executed by {ctx.author}",
                       icon_url=ctx.author.avatar.url if ctx.author.avatar else ctx.author.default_avatar.url)
            await ctx.send(view = embed_to_view(embed))
            return
            
        if not await self.is_automod_enabled(guild_id):
            embed=discord.Embed(title=f"Automod Settings for {ctx.guild.name}", description=f"Uhh, looks like your server hasn't enabled Automoderation.\n\nCurrent Status:  {emojis.DISABLED1}Disabled\nTo Enable use `{ctx.prefix}automod enable`", color=0x000000)
            embed.set_thumbnail(url=self.bot.user.display_avatar.url)
            embed.set_footer(text=f"â€œ{ctx.command.qualified_name}â€ Command executed by {ctx.author}",
                   icon_url=ctx.author.avatar.url if ctx.author.avatar else ctx.author.default_avatar.url)
            await ctx.send(view = embed_to_view(embed))
            return

        current_punishments = await self.get_current_punishments(guild_id)
        embed = discord.Embed(title=f"Enabled Automod Events & their punishment type for {ctx.guild.name}", color=0x000000)
        embed.set_footer(text="Manage punishment type for events by executing â€œautomod punishmentâ€ command.", icon_url=self.bot.user.display_avatar.url)

        if ctx.guild.icon:
            embed.set_thumbnail(url=ctx.guild.icon.url)
        else:
            embed.set_thumbnail(url=self.bot.user.display_avatar.url)

        for event, punishment in current_punishments:
            embed.add_field(name=event, value=punishment or "None", inline=False)

        if await self.is_anti_nsfw_enabled(guild_id):
            embed.add_field(name="Anti NSFW Links", value="Block Message", inline=False)

        col = await get_collection('automod_logging')
        log_channel_doc = await col.find_one({"guild_id": guild_id})

        if log_channel_doc and log_channel_doc.get("log_channel"):
            log_channel = ctx.guild.get_channel(log_channel_doc["log_channel"])
            if log_channel:
                embed.add_field(name="Logging Channel", value=f"{log_channel.mention}", inline=False)
            else:
                embed.add_field(name="Logging Channel", value="Deleted Channel", inline=False)
        else:
            embed.add_field(name="Logging Channel", value="No logging channel", inline=False)

        await ctx.send(view = embed_to_view(embed))


    @automod.command(name="logging", help="Set the logging channel for Automod events.")
    @blacklist_check()
    @ignore_check()
    @commands.cooldown(1, 5, commands.BucketType.user)
    @commands.max_concurrency(1, per=commands.BucketType.default, wait=False)
    @commands.guild_only()
    @commands.has_permissions(administrator=True)
    async def logging(self, ctx, channel: discord.TextChannel):
        guild_id = ctx.guild.id
        if ctx.author != ctx.guild.owner and ctx.author.top_role.position < ctx.guild.me.top_role.position:
            embed = discord.Embed(title=f"{emojis.CROSSICON} Access Denied", description="Your top role must be at the **same** position or **higher** than my top role.", color=0x000000)
            embed.set_footer(text=f"â€œ{ctx.command.qualified_name}â€ Command executed by {ctx.author}",
                       icon_url=ctx.author.avatar.url if ctx.author.avatar else ctx.author.default_avatar.url)
            await ctx.send(view = embed_to_view(embed))
            return
        if not await self.is_automod_enabled(guild_id):
            embed=discord.Embed(title=f"Automod Settings for {ctx.guild.name}", description=f"Uhh, looks like your server hasn't enabled Automoderation.\n\nCurrent Status:  {emojis.DISABLED1} Disabled\nTo Enable use `{ctx.prefix}automod enable`", color=0x000000)
            embed.set_thumbnail(url=self.bot.user.display_avatar.url)
            embed.set_footer(text=f"â€œ{ctx.command.qualified_name}â€ Command executed by {ctx.author}",
                   icon_url=ctx.author.avatar.url if ctx.author.avatar else ctx.author.default_avatar.url)
            await ctx.send(view = embed_to_view(embed))
            return
            
        col = await get_collection('automod_logging')
        await col.update_one({"guild_id": guild_id}, {"$set": {"log_channel": channel.id}}, upsert=True)
        await self._refresh_automod_cache(guild_id)
        embed=discord.Embed(title=f"Automod Settings for {ctx.guild.name}", description=f"**{emojis.TICK} | Automoderation Logging channel set to {channel.mention}.**\n\nâžœ Use `{ctx.prefix}automod config` to view current Automod settings.", color=0x000000)
        embed.set_footer(text=f"â€œ{ctx.command.qualified_name}â€ Command executed by {ctx.author}",
               icon_url=ctx.author.avatar.url if ctx.author.avatar else ctx.author.default_avatar.url)
        await ctx.send(view = embed_to_view(embed))


    @commands.Cog.listener()
    async def on_guild_remove(self, guild):
        guild_id = guild.id

        col1 = await get_collection('automod')
        col2 = await get_collection('automod_punishments')
        col3 = await get_collection('automod_ignored')
        col4 = await get_collection('automod_logging')
        await col1.delete_many({"guild_id": guild_id})
        await col2.delete_many({"guild_id": guild_id})
        await col3.delete_many({"guild_id": guild_id})
        await col4.delete_many({"guild_id": guild_id})


