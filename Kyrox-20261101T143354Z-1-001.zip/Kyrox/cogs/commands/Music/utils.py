import random
import discord
from discord.ext import commands
from utils import emojis
import datetime
import asyncio
import re
from typing import Optional
from PIL import Image, ImageDraw, ImageFont, ImageOps
import io
import aiohttp

import lavalink
from lavalink.server import LoadType

from utils.music_panel import (
    guard_empty_queue, guard_no_results, guard_no_voice, guard_not_connected, guard_not_playing, guard_same_channel,
    inactivity_embed, kawaii_queue_page_source, lavalink_offline_embed, music_toast, now_playing_embed,
    platform_select_embed, player_embed, player_layout_view, queue_ended_embed, queue_entry_line, search_results_embed,
    track_added_embed, NowPlayingView
)
from utils.music_utils import blacklist_check, ignore_check

from helpers.lavalink_client import (
    LavalinkVoiceClient,
    get_state,
    clear_state,
    format_ms,
    progress_bar,
    GuildMusicState,
)

track_histories = {}
active_filters_state = {}  # Safely store active filters per guild without touching __slots__

def get_active_filters(guild_id: int) -> list:
    return active_filters_state.get(guild_id, [])

def set_active_filters(guild_id: int, filters: list):
    active_filters_state[guild_id] = filters

def get_player(bot: commands.Bot, guild_id: int) -> Optional[lavalink.DefaultPlayer]:
    if not hasattr(bot, "lavalink"):
        return None
    return bot.lavalink.player_manager.get(guild_id)


def _get_artwork(track: lavalink.AudioTrack) -> str:
    if hasattr(track, "artwork_url") and track.artwork_url:
        return track.artwork_url
    if hasattr(track, "plugin_info") and isinstance(track.plugin_info, dict):
        art = track.plugin_info.get("artworkUrl", "")
        if art:
            return art
    if hasattr(track, "extra") and isinstance(track.extra, dict):
        art = track.extra.get("artworkUrl", "")
        if art:
            return art
    # Fallback to YouTube thumbnail if it is a YouTube track
    if "youtube.com" in (track.uri or "") or "youtu.be" in (track.uri or ""):
        return f"https://img.youtube.com/vi/{track.identifier}/maxresdefault.jpg"
    return ""


def get_font(size: int):
    import os
    windir = os.environ.get('WINDIR', 'C:/Windows')
    font_path = os.path.join(windir, 'Fonts', 'arial.ttf')
    if not os.path.exists(font_path):
        font_path = "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"
    if not os.path.exists(font_path):
        font_path = "arial.ttf"
    try:
        return ImageFont.truetype(font_path, size)
    except Exception:
        return ImageFont.load_default()


def truncate_text(text: str, font, max_width: int, draw) -> str:
    if not text:
        return ""
    try:
        width = draw.textlength(text, font)
    except AttributeError:
        try:
            width = font.getsize(text)[0]
        except AttributeError:
            try:
                width = font.getbbox(text)[2]
            except Exception:
                return text[:25] + "..." if len(text) > 28 else text
                
    if width <= max_width:
        return text
        
    for i in range(len(text) - 1, 0, -1):
        candidate = text[:i] + "..."
        try:
            w = draw.textlength(candidate, font)
        except AttributeError:
            try:
                w = font.getsize(candidate)[0]
            except AttributeError:
                try:
                    w = font.getbbox(candidate)[2]
                except Exception:
                    w = len(candidate) * (font.size * 0.5)
        if w <= max_width:
            return candidate
    return text[:10] + "..."


async def generate_player_card(track, player, guild, requester) -> io.BytesIO:
    import os
    template_path = "theme/images/music.png"
    if os.path.exists(template_path):
        base_img = Image.open(template_path).convert("RGBA")
    else:
        # Create fallback dark theme rounded card if template is missing
        base_img = Image.new("RGBA", (997, 357), (20, 20, 20, 255))
        draw = ImageDraw.Draw(base_img)
        draw.rounded_rectangle([(10, 10), (987, 347)], radius=25, fill=(15, 15, 15, 255), outline=(100, 100, 100, 255), width=2)

    # Apply beautiful semi-transparent black overlay for text readability
    overlay = Image.new("RGBA", base_img.size, (0, 0, 0, 0))
    draw_overlay = ImageDraw.Draw(overlay)
    draw_overlay.rounded_rectangle([(20, 20), (977, 337)], radius=30, fill=(10, 10, 10, 160))
    base_img = Image.alpha_composite(base_img, overlay)
    
    # Draw elements
    draw = ImageDraw.Draw(base_img)
    
    # Fonts
    font_title = get_font(38)
    font_artist = get_font(26)
    font_info = get_font(22)
    font_status = get_font(20)
    
    # Fetch and draw artwork
    artwork_url = _get_artwork(track)
    artwork_pasted = False
    if artwork_url:
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(artwork_url, timeout=5) as resp:
                    if resp.status == 200:
                        artwork_bytes = await resp.read()
                        art_img = Image.open(io.BytesIO(artwork_bytes)).convert("RGBA")
                        art_img = ImageOps.fit(art_img, (260, 260), centering=(0.5, 0.5))
                        
                        # Rounded corners for artwork
                        mask = Image.new("L", (260, 260), 0)
                        mask_draw = ImageDraw.Draw(mask)
                        mask_draw.rounded_rectangle([(0, 0), (260, 260)], radius=25, fill=255)
                        
                        art_img.putalpha(mask)
                        base_img.paste(art_img, (48, 48), art_img)
                        artwork_pasted = True
        except Exception:
            pass

    if not artwork_pasted:
        # Draw placeholder
        draw.rounded_rectangle([(48, 48), (308, 308)], radius=25, fill=(40, 40, 40, 255))
        try:
            draw.text((178, 178), "🎵", font=get_font(70), fill=(150, 150, 150, 255), anchor="mm")
        except Exception:
            draw.text((150, 140), "🎵", font=get_font(70), fill=(150, 150, 150, 255))

    # Platform accent color logic
    source_name = (getattr(track, "source_name", "unknown") or "unknown").lower()
    if "spotify" in source_name:
        accent_color = (29, 185, 84, 255)
    elif "youtube" in source_name:
        accent_color = (255, 0, 0, 255)
    elif "jiosaavn" in source_name:
        accent_color = (0, 230, 167, 255)
    elif "soundcloud" in source_name:
        accent_color = (255, 85, 0, 255)
    else:
        accent_color = (88, 101, 242, 255) # Discord Purple

    # Status: NOW PLAYING / PAUSED
    status_text = "PAUSED" if player.paused else "NOW PLAYING"
    status_color = (180, 180, 180, 255) if player.paused else accent_color
    draw.text((340, 50), status_text, font=font_status, fill=status_color)
    
    # Title
    title_text = track.title or "Unknown Title"
    truncated_title = truncate_text(title_text, font_title, 590, draw)
    draw.text((340, 80), truncated_title, font=font_title, fill=(255, 255, 255, 255))
    
    # Artist
    artist_text = f"by {track.author}" if track.author else "Unknown Artist"
    truncated_artist = truncate_text(artist_text, font_artist, 590, draw)
    draw.text((340, 135), truncated_artist, font=font_artist, fill=(200, 200, 200, 255))
    
    # Requester
    req_name = requester.display_name if requester else "Unknown User"
    req_text = f"Requested by: {req_name}"
    truncated_req = truncate_text(req_text, font_info, 590, draw)
    draw.text((340, 180), truncated_req, font=font_info, fill=(160, 160, 160, 255))
    
    # Draw Developed by Krishna.xyz credits
    draw.text((340, 240), "Developed by Krishna.xyz", font=font_info, fill=(160, 160, 160, 255))
    
    # Save image to bytes
    image_bytes = io.BytesIO()
    base_img.save(image_bytes, format="PNG")
    image_bytes.seek(0)
    return image_bytes


class MusicFiltersHelper:
    """Helper to apply filters using standard lavalink.py 5.x methods safely."""
    
    AVAILABLE = [
        "bassboost", "nightcore", "vaporwave", "8d", 
        "karaoke", "tremolo", "vibrato", "lowpass"
    ]

    @staticmethod
    async def apply(player: lavalink.DefaultPlayer, filters: list[str]):
        try:
            # Clear them first to prevent filter overlaps
            await player.remove_filters()
            
            for f in filters:
                f = f.lower()
                if f == "bassboost":
                    await player.update_filter(lavalink.Equalizer, bands=[(0, 0.6), (1, 0.4), (2, 0.2)])
                elif f == "nightcore":
                    await player.update_filter(lavalink.Timescale, speed=1.2, pitch=1.2, rate=1.0)
                elif f == "vaporwave":
                    await player.update_filter(lavalink.Timescale, speed=0.8, pitch=0.8, rate=1.0)
                elif f == "8d":
                    await player.update_filter(lavalink.Rotation, rotation_hz=0.2)
                elif f == "karaoke":
                    await player.update_filter(lavalink.Karaoke, level=1.0, mono_level=1.0, filter_band=220.0, filter_width=100.0)
                elif f == "tremolo":
                    await player.update_filter(lavalink.Tremolo, frequency=2.0, depth=0.5)
                elif f == "vibrato":
                    await player.update_filter(lavalink.Vibrato, frequency=2.0, depth=0.5)
                elif f == "lowpass":
                    await player.update_filter(lavalink.LowPass, smoothing=20.0)
        except Exception as e:
            print(f"MusicFiltersHelper application error: {e}")


# ─────────────────────────────────────────────────────────────────────────────
# COMPONENTS V2 HELPER VIEWS
# ─────────────────────────────────────────────────────────────────────────────

class music_toast(discord.ui.LayoutView):
    """A standard premium Components V2 LayoutView enclosing a container box with buttons inside it."""
    def __init__(self, text: str, tone: str = "info", accent_color: Optional[int] = None, title: Optional[str] = None, thumbnail: Optional[str] = None, buttons: Optional[list] = None, timeout: Optional[float] = 60.0):
        super().__init__(timeout=timeout)
        
        if accent_color is None:
            if tone == "error":
                accent_color = 0xFF9E9E
            elif tone == "success":
                accent_color = 0x1DB954
            else:
                accent_color = 0xFFB7C5
                
        displays = []
        if title:
            displays.append(discord.ui.TextDisplay(title))
        displays.append(discord.ui.TextDisplay(text))

        row = None
        if buttons:
            row = discord.ui.ActionRow()
            for btn in buttons:
                row.add_item(btn)

        if thumbnail:
            section = discord.ui.Section(*displays, accessory=discord.ui.Thumbnail(thumbnail))
            container_ns = {"_sec": section}
        else:
            container_ns = {}
            for i, disp in enumerate(displays):
                container_ns[f"_disp_{i}"] = disp

        if row:
            container_ns["_row"] = row

        container_cls = type("_DynamicContainer", (discord.ui.Container,), container_ns)
        self.container = container_cls(accent_color=accent_color)
        self.add_item(self.container)


class ContainerPaginator(discord.ui.LayoutView):
    """A pagination interface using Discord Components V2 Containers enclosing navigation buttons."""
    def __init__(self, ctx, entries, title="Current Queue", description="List of upcoming songs.", per_page=10, color=0xFFE5B4):
        super().__init__(timeout=60)
        self.ctx = ctx
        self.entries = entries
        self.title = title
        self.description = description
        self.per_page = per_page
        self.color = color
        self.current_page = 0
        
        self.total_pages = max(1, (len(entries) - 1) // per_page + 1)
        
        # Navigation buttons
        self.prev_btn = discord.ui.Button(label="Previous", style=discord.ButtonStyle.secondary, emoji="◀")
        self.next_btn = discord.ui.Button(label="Next", style=discord.ButtonStyle.secondary, emoji=emojis.get("icons_next"))
        
        self.prev_btn.callback = self.go_prev
        self.next_btn.callback = self.go_next
        
        self.row = discord.ui.ActionRow(self.prev_btn, self.next_btn)
        
        self.container = self.build_page_container()
        self.add_item(self.container)
        self.update_buttons()

    def build_page_container(self) -> discord.ui.Container:
        start = self.current_page * self.per_page
        end = start + self.per_page
        page_entries = self.entries[start:end]
        
        content = self.description + "\n\n" + "\n".join(page_entries)
        
        sep = discord.ui.Separator(spacing=discord.SeparatorSpacing.small, visible=True)
        footer = discord.ui.TextDisplay(f"*Page {self.current_page + 1}/{self.total_pages}*")
        
        container_ns = {
            "_title": discord.ui.TextDisplay(f"## {self.title}"),
            "_content": discord.ui.TextDisplay(content),
            "_sep": sep,
            "_row": self.row,
            "_footer": footer
        }
        container_cls = type("_PageContainer", (discord.ui.Container,), container_ns)
        return container_cls(accent_color=self.color)

    def update_buttons(self):
        self.prev_btn.disabled = self.current_page == 0
        self.next_btn.disabled = self.current_page == self.total_pages - 1

    async def go_prev(self, interaction: discord.Interaction):
        if interaction.user != self.ctx.author:
            await interaction.response.send_message(view=music_toast("You cannot use this menu.", tone="error"), ephemeral=True)
            return
        if self.current_page > 0:
            self.current_page -= 1
            self.remove_item(self.container)
            self.container = self.build_page_container()
            self.add_item(self.container)
            self.update_buttons()
            await interaction.response.edit_message(view=self)

    async def go_next(self, interaction: discord.Interaction):
        if interaction.user != self.ctx.author:
            await interaction.response.send_message(view=music_toast("You cannot use this menu.", tone="error"), ephemeral=True)
            return
        if self.current_page < self.total_pages - 1:
            self.current_page += 1
            self.remove_item(self.container)
            self.container = self.build_page_container()
            self.add_item(self.container)
            self.update_buttons()
            await interaction.response.edit_message(view=self)

    async def paginate(self):
        if not self.entries:
            return
        await self.ctx.send(view=self)


class PagesPaginator(discord.ui.LayoutView):
    """A pagination interface for viewing pre-formatted pages of text (like lyrics) inside V2 containers."""
    def __init__(self, ctx, pages, title="Song Lyrics", color=0xFFB7C5):
        super().__init__(timeout=120)
        self.ctx = ctx
        self.pages = pages
        self.title = title
        self.color = color
        self.current_page = 0
        self.total_pages = len(pages)

        # Navigation buttons
        self.prev_btn = discord.ui.Button(label="Previous", style=discord.ButtonStyle.secondary, emoji="◀")
        self.next_btn = discord.ui.Button(label="Next", style=discord.ButtonStyle.secondary, emoji=emojis.get("icons_next"))
        
        self.prev_btn.callback = self.go_prev
        self.next_btn.callback = self.go_next
        
        self.row = discord.ui.ActionRow(self.prev_btn, self.next_btn)
        
        self.container = self.build_page_container()
        self.add_item(self.container)
        self.update_buttons()

    def build_page_container(self) -> discord.ui.Container:
        content = self.pages[self.current_page]
        
        sep = discord.ui.Separator(spacing=discord.SeparatorSpacing.small, visible=True)
        footer = discord.ui.TextDisplay(f"*Page {self.current_page + 1}/{self.total_pages}*")
        
        container_ns = {
            "_title": discord.ui.TextDisplay(f"## {self.title}"),
            "_content": discord.ui.TextDisplay(content),
            "_sep": sep,
            "_row": self.row,
            "_footer": footer
        }
        container_cls = type("_PagesContainer", (discord.ui.Container,), container_ns)
        return container_cls(accent_color=self.color)

    def update_buttons(self):
        self.prev_btn.disabled = self.current_page == 0
        self.next_btn.disabled = self.current_page == self.total_pages - 1

    async def go_prev(self, interaction: discord.Interaction):
        if interaction.user != self.ctx.author:
            await interaction.response.send_message(view=music_toast("You cannot use this menu.", tone="error"), ephemeral=True)
            return
        if self.current_page > 0:
            self.current_page -= 1
            self.remove_item(self.container)
            self.container = self.build_page_container()
            self.add_item(self.container)
            self.update_buttons()
            await interaction.response.edit_message(view=self)

    async def go_next(self, interaction: discord.Interaction):
        if interaction.user != self.ctx.author:
            await interaction.response.send_message(view=music_toast("You cannot use this menu.", tone="error"), ephemeral=True)
            return
        if self.current_page < self.total_pages - 1:
            self.current_page += 1
            self.remove_item(self.container)
            self.container = self.build_page_container()
            self.add_item(self.container)
            self.update_buttons()
            await interaction.response.edit_message(view=self)

    async def paginate(self):
        if not self.pages:
            return
        await self.ctx.send(view=self)


class PlatformSelectView(discord.ui.LayoutView):
    def __init__(self, ctx, query):
        super().__init__(timeout=60)
        self.ctx = ctx
        self.query = query

        row = discord.ui.ActionRow()
        platforms = [
            ("YouTube Music", "ytmsearch", discord.ButtonStyle.red),
            ("JioSaavn", "jssearch", discord.ButtonStyle.green),
            ("SoundCloud", "scsearch", discord.ButtonStyle.grey),
        ]

        for name, source, style in platforms:
            button = discord.ui.Button(label=name, style=style, custom_id=source)
            button.callback = self.create_callback(source)
            row.add_item(button)

        container_ns = {
            "text": discord.ui.TextDisplay("## Select a platform to search from:\nClick a button below to choose."),
            "row": row
        }
        container_cls = type("_PlatformSelectContainer", (discord.ui.Container,), container_ns)
        self.container = container_cls(accent_color=0xFFB7C5)
        self.add_item(self.container)

    def create_callback(self, source):
        async def callback(interaction: discord.Interaction):
            if interaction.user != self.ctx.author:
                await interaction.response.send_message(view=music_toast("Only the command author can select a platform.", tone="error"), ephemeral=True)
                return

            await interaction.response.send_message(view=music_toast(f"Searching on {source}...", tone="info"), ephemeral=True)
            await self.perform_search(source)
            try:
                await interaction.message.delete()
            except:
                pass
        return callback

    async def perform_search(self, source):
        query = f"{source}:{self.query}"
        try:
            results = await self.ctx.bot.lavalink.get_tracks(query)
        except Exception as exc:
            err_container = discord.ui.Container(
                discord.ui.TextDisplay(f"## {emojis.get('CrossIcon')} Search failed\n{exc}"),
                accent_color=0xFF9E9E
            )
            view = type("_ErrView", (discord.ui.LayoutView,), {"container": err_container})()
            return await self.ctx.send(view=view)

        if not results or not results.tracks:
            err_container = discord.ui.Container(
                discord.ui.TextDisplay(f"## {emojis.get('CrossIcon')} No results found\nNo tracks matched your query."),
                accent_color=0xFF9E9E
            )
            view = type("_ErrView", (discord.ui.LayoutView,), {"container": err_container})()
            return await self.ctx.send(view=view)

        top_results = results.tracks[:5]
        
        description_lines = []
        for i, track in enumerate(top_results, start=1):
            dur_sec = track.duration // 1000
            duration_str = f"{dur_sec // 60}:{dur_sec % 60:02d}"
            description_lines.append(f"{i}. **[{track.title}]({track.uri})**\n   *Duration: `{duration_str}`*")
            
        results_text = f"## Top 5 Results for '{self.query}' ({source})\n\n" + "\n".join(description_lines)
        
        await self.ctx.send(view=SearchResultView(self.ctx, top_results, results_text))


class SearchResultView(discord.ui.LayoutView):
    def __init__(self, ctx, results, results_text):
        super().__init__(timeout=60)
        self.ctx = ctx
        self.results = results

        row = discord.ui.ActionRow()
        for i in range(len(results)):
            button = discord.ui.Button(label=str(i + 1), style=discord.ButtonStyle.primary)
            button.callback = self.create_callback(i)
            row.add_item(button)

        container_ns = {
            "display": discord.ui.TextDisplay(results_text),
            "row": row
        }
        container_cls = type("_SearchResultContainer", (discord.ui.Container,), container_ns)
        self.container = container_cls(accent_color=0xFFE5B4)
        self.add_item(self.container)

    def create_callback(self, index):
        async def callback(interaction: discord.Interaction):
            if interaction.user != self.ctx.author:
                await interaction.response.send_message(view=music_toast("Only the command author can select a track.", tone="error"), ephemeral=True)
                return

            track = self.results[index]
            player = get_player(self.ctx.bot, self.ctx.guild.id)
            if not player or not player.is_connected:
                await self.ctx.author.voice.channel.connect(cls=LavalinkVoiceClient, self_deaf=True)
                player = self.ctx.bot.lavalink.player_manager.create(self.ctx.guild.id)
                vc = self.ctx.voice_client
                if vc and hasattr(vc, 'voice_ready'):
                    try:
                        await asyncio.wait_for(vc.voice_ready.wait(), timeout=10)
                    except asyncio.TimeoutError:
                        pass

            state = get_state(self.ctx.guild.id)
            state.text_channel_id = self.ctx.channel.id

            player.add(track=track, requester=self.ctx.author.id)
            if not player.is_playing:
                await player.play()
                await interaction.response.send_message(view=music_toast(f"Started playing `{track.title}`.", tone="info"))
            else:
                await interaction.response.send_message(view=music_toast(f"Added `{track.title}` to the queue.", tone="info"))
        return callback


class MusicButton(discord.ui.Button):
    def __init__(self, label: str, style: discord.ButtonStyle, emoji: str, custom_id: str):
        super().__init__(label=label, style=style, emoji=emoji, custom_id=custom_id)

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        player = get_player(interaction.client, interaction.guild.id)
        if not player or not player.is_playing:
            await interaction.response.send_message(view=music_toast("I'm not currently playing anything.", tone="error"), ephemeral=True)
            return False
            
        vc = interaction.guild.voice_client
        if not vc:
            await interaction.response.send_message(view=music_toast("I'm not connected to a voice channel.", tone="error"), ephemeral=True)
            return False

        if interaction.user in vc.channel.members:
            return True
        await interaction.response.send_message(
            view=music_toast("Only members in the same voice channel as me can control the player.", tone="error"),
            ephemeral=True
        )
        return False


class PauseButton(MusicButton):
    def __init__(self, player):
        label = "Resume" if player.paused else "Pause"
        emoji = f"{emojis.get('icons_next')}" if player.paused else f"{emojis.get('icons_pause')}"
        style = discord.ButtonStyle.success if player.paused else discord.ButtonStyle.primary
        super().__init__(label=label, style=style, emoji=emoji, custom_id="np_pause")

    async def callback(self, interaction: discord.Interaction):
        if not await self.interaction_check(interaction):
            return
        player = get_player(interaction.client, interaction.guild.id)
        vc = interaction.guild.voice_client
        if player.paused:
            await player.set_pause(False)
            if vc:
                try:
                    await vc.channel.edit(status=f"<a:music:1448966355935301643> Playing: {player.current.title}")
                except:
                    pass
        else:
            await player.set_pause(True)
            if vc:
                try:
                    await vc.channel.edit(status=f"<i:icons_pause:1327829480835780609> Paused: {player.current.title}")
                except:
                    pass
        
        new_view, file = await build_now_playing_view(player, player.current, interaction.guild, interaction.client)
        await interaction.response.edit_message(view=new_view, attachments=[file])


class SkipButton(MusicButton):
    def __init__(self):
        super().__init__(label="Skip", style=discord.ButtonStyle.secondary, emoji=f"{emojis.get('skip')}", custom_id="np_skip")

    async def callback(self, interaction: discord.Interaction):
        if not await self.interaction_check(interaction):
            return
        player = get_player(interaction.client, interaction.guild.id)
        state = get_state(interaction.guild.id)
        if getattr(state, 'autoplay', False) or player.queue or player.is_playing:
            await player.skip()
            await interaction.response.send_message(view=music_toast(f"Skipped song by **{interaction.user.display_name}**.", tone="info"))
        else:
            await interaction.response.send_message(view=music_toast("No song in queue to skip.", tone="error"), ephemeral=True)


class StopButton(MusicButton):
    def __init__(self):
        super().__init__(label="Stop", style=discord.ButtonStyle.danger, emoji=f"{emojis.get('musicstop_icons')}", custom_id="np_stop")

    async def callback(self, interaction: discord.Interaction):
        if not await self.interaction_check(interaction):
            return
        player = get_player(interaction.client, interaction.guild.id)
        vc = interaction.guild.voice_client
        if vc:
            try:
                await vc.channel.edit(status=None)
            except:
                pass
            player.queue.clear()
            await player.stop()
            await vc.disconnect(force=True)
            await interaction.response.send_message(view=music_toast(f"Stopped and disconnected by **{interaction.user.display_name}**.", tone="error"))
        else:
            await interaction.response.send_message(view=music_toast("Not connected.", tone="error"), ephemeral=True)


class LoopButton(MusicButton):
    def __init__(self, player):
        emoji = f"{emojis.get('shuffle')}" if player.loop != 0 else "🔄"
        style = discord.ButtonStyle.primary if player.loop != 0 else discord.ButtonStyle.secondary
        label = "Loop" if player.loop == 0 else "Loop Single" if player.loop == 1 else "Loop Queue"
        super().__init__(label=label, style=style, emoji=emoji, custom_id="np_loop")

    async def callback(self, interaction: discord.Interaction):
        if not await self.interaction_check(interaction):
            return
        player = get_player(interaction.client, interaction.guild.id)
        new_loop = 2 if player.loop != 2 else 0
        player.set_loop(new_loop)
        
        new_view, file = await build_now_playing_view(player, player.current, interaction.guild, interaction.client)
        await interaction.response.edit_message(view=new_view, attachments=[file])
        
        accent = 0xFFB7C5 if new_loop == 2 else 0xFF9E9E
        await interaction.followup.send(view=music_toast(f"Loop {'enabled' if new_loop == 2 else 'disabled'} by **{interaction.user.display_name}**.", tone="info"))


class AutoplayButton(MusicButton):
    def __init__(self, guild_id: int):
        state = get_state(guild_id)
        style = discord.ButtonStyle.success if getattr(state, 'autoplay', False) else discord.ButtonStyle.secondary
        emoji = "🌸" if getattr(state, 'autoplay', False) else "💮"
        super().__init__(label="Autoplay", style=style, emoji=emoji, custom_id="np_autoplay")

    async def callback(self, interaction: discord.Interaction):
        if not await self.interaction_check(interaction):
            return
        state = get_state(interaction.guild.id)
        state.autoplay = not getattr(state, 'autoplay', False)
        
        player = get_player(interaction.client, interaction.guild.id)
        new_view, file = await build_now_playing_view(player, player.current, interaction.guild, interaction.client)
        await interaction.response.edit_message(view=new_view, attachments=[file])
        
        accent = 0xFFB7C5 if state.autoplay else 0xFF9E9E
        await interaction.followup.send(view=music_toast(f"Autoplay {'enabled' if state.autoplay else 'disabled'} by **{interaction.user.display_name}**.", tone="info"))


# ─────────────────────────────────────────────────────────────────────────────
# NEW: CONTROLS PANEL & FILTERS UI
# ─────────────────────────────────────────────────────────────────────────────

class VolumeModal(discord.ui.Modal, title='Set Custom Volume'):
    vol_input = discord.ui.TextInput(
        label='Volume Percentage',
        placeholder='Enter a number between 0 and 150',
        min_length=1,
        max_length=3,
        required=True
    )

    def __init__(self, panel_view):
        super().__init__()
        self.panel_view = panel_view

    async def on_submit(self, interaction: discord.Interaction):
        try:
            val = int(self.vol_input.value)
            val = max(0, min(150, val))
            
            # Defer interaction safely 
            await interaction.response.defer()
            await self.panel_view.player.set_volume(val)
            
            self.panel_view.build_ui()
            await interaction.edit_original_response(view=self.panel_view)
        except ValueError:
            if not interaction.response.is_done():
                await interaction.response.send_message("Please enter a valid number.", ephemeral=True)


class VolButton(discord.ui.Button):
    def __init__(self, panel_view, label, custom_id, amount=None):
        super().__init__(label=label, style=discord.ButtonStyle.secondary, custom_id=custom_id)
        self.panel_view = panel_view
        self.amount = amount

    async def callback(self, interaction: discord.Interaction):
        if self.amount is not None:
            await interaction.response.defer()
            new_vol = max(0, min(150, self.panel_view.player.volume + self.amount))
            await self.panel_view.player.set_volume(new_vol)
            
            self.panel_view.build_ui()
            await interaction.edit_original_response(view=self.panel_view)
        else:
            await interaction.response.send_modal(VolumeModal(self.panel_view))


class FilterSelect(discord.ui.Select):
    def __init__(self, panel_view, active_filters):
        self.panel_view = panel_view
        
        options = []
        for f in MusicFiltersHelper.AVAILABLE:
            options.append(discord.SelectOption(
                label=f.capitalize(),
                value=f,
                default=(f in active_filters)
            ))
            
        super().__init__(
            placeholder="Select music filters to apply...",
            min_values=0,
            max_values=len(options),
            options=options,
            custom_id="filter_select"
        )

    async def callback(self, interaction: discord.Interaction):
        await interaction.response.defer()
        
        guild_id = interaction.guild.id
        set_active_filters(guild_id, self.values)
        
        await MusicFiltersHelper.apply(self.panel_view.player, self.values)
        self.panel_view.active_filters = self.values
        
        self.panel_view.build_ui()
        await interaction.edit_original_response(view=self.panel_view)


class ResetFiltersButton(discord.ui.Button):
    def __init__(self, panel_view):
        super().__init__(label="Reset Filters", style=discord.ButtonStyle.danger, custom_id="reset_filters")
        self.panel_view = panel_view

    async def callback(self, interaction: discord.Interaction):
        await interaction.response.defer()
        
        guild_id = interaction.guild.id
        set_active_filters(guild_id, [])
        self.panel_view.active_filters = []
        
        await MusicFiltersHelper.apply(self.panel_view.player, [])
        
        self.panel_view.build_ui()
        await interaction.edit_original_response(view=self.panel_view)


class ControlsPanelView(discord.ui.LayoutView):
    def __init__(self, player, active_filters, artwork_url=None):
        super().__init__(timeout=180)
        self.player = player
        self.active_filters = active_filters
        self.artwork_url = artwork_url
        self.build_ui()

    def build_ui(self):
        self.clear_items()
        container_ns = {}
        
        # 1. The Banner Section (at the very top)
        if self.artwork_url:
            container_ns["_gallery"] = discord.ui.MediaGallery(
                discord.MediaGalleryItem(self.artwork_url, description="Artwork")
            )
            container_ns["_sep_img"] = discord.ui.Separator(spacing=discord.SeparatorSpacing.small, visible=True)
            
        vol = self.player.volume
        vol_ratio = min(max(vol, 0), 150) / 150
        filled = round(vol_ratio * 15)
        vol_bar = "🟩" * filled + "⬛" * (15 - filled)

        vol_text = (
            f"## {emojis.get('Gear')} Music Controls Panel\n"
            "Use buttons below to add or reduce volume by 10, or set a custom level.\n\n"
            f"**Volume:** {vol_bar} `{vol}%`"
        )

        row_vol = discord.ui.ActionRow(
            VolButton(self, "-10", "vol_minus", -10),
            VolButton(self, "Set Vol", "vol_custom", None),
            VolButton(self, "+10", "vol_plus", +10)
        )

        # 2. Volume Controls Stacked below image
        container_ns["_vol_text"] = discord.ui.TextDisplay(vol_text)
        container_ns["_row_vol"] = row_vol
        container_ns["_sep_vol"] = discord.ui.Separator(spacing=discord.SeparatorSpacing.small, visible=True)

        filters_display = ", ".join([f.capitalize() for f in self.active_filters]) if self.active_filters else "None"
        filter_text = (
            f"## {emojis.get('filder')} Filters Selection\n"
            "From the dropdown below you can select multiple music filters to enhance the audio.\n"
            f"-# Active Filters: **{filters_display}**"
        )

        row_select = discord.ui.ActionRow(FilterSelect(self, self.active_filters))
        row_reset = discord.ui.ActionRow(ResetFiltersButton(self))

        # 3. Filter Controls
        container_ns["_filter_text"] = discord.ui.TextDisplay(filter_text)
        container_ns["_row_select"] = row_select
        container_ns["_row_reset"] = row_reset
        
        container_cls = type("_ControlsContainer", (discord.ui.Container,), container_ns)
        self.container = container_cls(accent_color=0xFFB7C5)
        self.add_item(self.container)


class ControlsButton(MusicButton):
    def __init__(self):
        super().__init__(label="Controls", style=discord.ButtonStyle.secondary, emoji=f"{emojis.get('Gear')}", custom_id="np_controls")

    async def callback(self, interaction: discord.Interaction):
        if not await self.interaction_check(interaction):
            return
        player = get_player(interaction.client, interaction.guild.id)
        
        filters = get_active_filters(interaction.guild.id)
        
        # Pull current song artwork dynamically for the banner! 
        # (Or you can change this to a static link like "https://i.imgur.com/example.png")
        # Replace the URL inside the quotes with your actual image link
        artwork_url = "https://media.discordapp.net/attachments/1511760488994832558/1517176978976014356/image.png?ex=6a3554ab&is=6a34032b&hm=73dd36584fb0b822057efa9bb4a77fe30173db785f1eb7d0266a7969a93b0afe&=&format=webp&quality=lossless"
        
        view = ControlsPanelView(player, filters, artwork_url)
        await interaction.response.send_message(view=view, ephemeral=True)


async def build_now_playing_view(player, track, guild, client) -> tuple[discord.ui.LayoutView, discord.File]:
    requester_id = getattr(track, "requester", 0)
    requester = guild.get_member(requester_id) if requester_id else None
    req_mention = requester.mention if requester else "Unknown User"
    
    # Platform accent color logic
    source_name = (getattr(track, "source_name", "unknown") or "unknown").lower()
    if "spotify" in source_name:
        accent_color = 0x1DB954
    elif "youtube" in source_name:
        accent_color = 0xFF0000
    elif "jiosaavn" in source_name:
        accent_color = 0x00E6A7
    elif "soundcloud" in source_name:
        accent_color = 0xFF5500
    else:
        accent_color = 0x5865F2
        
    status_text = "Paused" if player.paused else "Now Playing"
    dur_str = "LIVE" if track.is_stream else format_ms(track.duration)
    artwork_url = _get_artwork(track)
    
    # Generate player card image via PIL helper
    try:
        card_bytes = await generate_player_card(track, player, guild, requester)
    except Exception as e:
        print(f"Error generating player card image: {e}")
        fallback_img = Image.new("RGBA", (10, 10), (0, 0, 0, 0))
        card_bytes = io.BytesIO()
        fallback_img.save(card_bytes, format="PNG")
        card_bytes.seek(0)
        
    file = discord.File(card_bytes, filename="card.png")
    
    row1 = discord.ui.ActionRow()
    row1.add_item(PauseButton(player))
    row1.add_item(SkipButton())
    row1.add_item(StopButton())
    row1.add_item(LoopButton(player))
    row1.add_item(AutoplayButton(guild.id))

    row2 = discord.ui.ActionRow()
    row2.add_item(ControlsButton())
    
    container_ns = {}
    container_ns["_gallery"] = discord.ui.MediaGallery(
        discord.MediaGalleryItem("attachment://card.png", description="Player Card")
    )
    container_ns["_sep1"] = discord.ui.Separator(spacing=discord.SeparatorSpacing.small, visible=True)
        
    content_text = (
        f"**{status_text}**\n\n"
        f"**[{track.title}]({track.uri or ''}) - {track.author or 'Unknown Artist'}**\n"
        f"Duration: `{dur_str}`\n"
        f"-# Requested by {req_mention}"
    )
    
    if artwork_url:
        container_ns["_section"] = discord.ui.Section(
            discord.ui.TextDisplay(content_text),
            accessory=discord.ui.Thumbnail(artwork_url)
        )
    else:
        container_ns["_content"] = discord.ui.TextDisplay(content_text)
    
    container_ns["_sep2"] = discord.ui.Separator(spacing=discord.SeparatorSpacing.small, visible=True)
    
    container_ns["_row1"] = row1
    container_ns["_row2"] = row2
    
    container_cls = type("_NPContainer", (discord.ui.Container,), container_ns)
    container_instance = container_cls()
    
    view_cls = type("_NPView", (discord.ui.LayoutView,), {
        "_container": container_instance
    })
    return view_cls(), file


def build_enqueued_view(track, requester, position) -> discord.ui.LayoutView:
    sec = track.duration // 1000
    duration = f"{sec // 60}:{sec % 60:02d}"
    
    details = (
        f"> **Author:** {track.author}\n"
        f"> **Duration:** `{duration}`\n"
        f"> **Requester:** {requester.mention}\n"
        f"> **Position:** `{position}`"
    )
    
    title_text = track.title or "Unknown Title"
    if len(title_text) > 65:
        title_text = title_text[:62] + "..."
        
    artwork = _get_artwork(track)
    
    source_name = (getattr(track, "source_name", "unknown") or "unknown").lower()
    accent_color = 0xBFFCC6 if "spotify" in source_name else 0xCEF0D2 if "jiosaavn" in source_name else 0xFF9E9E if "youtube" in source_name else 0xFFD2B2
    
    if artwork:
        section = discord.ui.Section(
            discord.ui.TextDisplay(f"### Enqueued **{title_text}**"),
            discord.ui.TextDisplay(details),
            accessory=discord.ui.Thumbnail(artwork)
        )
        container_ns = {
            "_sec": section
        }
    else:
        container_ns = {
            "_title": discord.ui.TextDisplay(f"### Enqueued **{title_text}**"),
            "_details": discord.ui.TextDisplay(details)
        }
    
    container_cls = type("_EnqueuedContainer", (discord.ui.Container,), container_ns)
    container_instance = container_cls(accent_color=accent_color)
    
    view_cls = type("_EnqueuedView", (discord.ui.LayoutView,), {"_container": container_instance})
    return view_cls()


def build_playlist_enqueued_view(name, count, requester, type_="playlist") -> discord.ui.LayoutView:
    details = (
        f"• **Type:** {type_.capitalize()}\n"
        f"• **Tracks:** `{count}`\n"
        f"• **Requester:** {requester.mention}"
    )
    
    container_ns = {
        "_title": discord.ui.TextDisplay(f"### Enqueued **{name}**"),
        "_details": discord.ui.TextDisplay(details)
    }
    container_cls = type("_PlaylistEnqueuedContainer", (discord.ui.Container,), container_ns)
    container_instance = container_cls(accent_color=0xFFE5B4)
    
    view_cls = type("_PlaylistEnqueuedView", (discord.ui.LayoutView,), {"_container": container_instance})
    return view_cls()


def build_lyrics_panel(data: dict, color: int = 0xFFB7C5) -> discord.ui.LayoutView:
    container_ns = {}
    container_ns["_title"] = discord.ui.TextDisplay(f"# **{data['title']}**\n-# {data['artist']}")
    
    if data.get("image"):
        container_ns["_gallery"] = discord.ui.MediaGallery(
            discord.MediaGalleryItem(data["image"], description="Album Art")
        )
    
    lines = data.get("lyrics", "").split("\n")
    truncated_lines = []
    for line in lines:
        if len(line) > 60:
            truncated_lines.append(line[:57] + "...")
        else:
            truncated_lines.append(line)
    processed_lyrics = "\n".join(truncated_lines)[:1800]
    if not processed_lyrics:
        processed_lyrics = "_No lyrics available_"
        
    container_ns["_body"] = discord.ui.TextDisplay(processed_lyrics)
    container_ns["_sep"] = discord.ui.Separator(spacing=discord.SeparatorSpacing.small, visible=True)
    container_ns["_footer"] = discord.ui.TextDisplay(f"-# Source: {data['source']}")
    
    container_cls = type("_LyricsContainer", (discord.ui.Container,), container_ns)
    
    class LyricsView(discord.ui.LayoutView):
        def __init__(self):
            super().__init__(timeout=120)
            self.container = container_cls(accent_color=color)
            self.add_item(self.container)
            
    return LyricsView()


def build_synced_lyrics_panel(data: dict, display_lines: list[str], current_line_no: int, total_lines: int, color: int = 0xFFB7C5) -> discord.ui.LayoutView:
    container_ns = {}
    container_ns["_title"] = discord.ui.TextDisplay(f"# **{data['title']}**\n-# {data['artist']}")
    
    if data.get("image"):
        container_ns["_gallery"] = discord.ui.MediaGallery(
            discord.MediaGalleryItem(data["image"], description="Album Art")
        )
    
    body_content = "\n".join(display_lines) or "_No lyrics available_"
    container_ns["_body"] = discord.ui.TextDisplay(body_content)
    container_ns["_sep"] = discord.ui.Separator(spacing=discord.SeparatorSpacing.small, visible=True)
    container_ns["_footer"] = discord.ui.TextDisplay(f"-# Live Synced Lyrics \u00b7 Line {current_line_no} of {total_lines}")
    
    container_cls = type("_SyncedLyricsContainer", (discord.ui.Container,), container_ns)
    
    class SyncedLyricsView(discord.ui.LayoutView):
        def __init__(self):
            super().__init__(timeout=120)
            self.container = container_cls(accent_color=color)
            self.add_item(self.container)
            
    return SyncedLyricsView()


def build_stopped_panel(data: dict, reason: str, failed_color: int = 0xFF9E9E) -> discord.ui.LayoutView:
    container_ns = {}
    title = "Track Skipped" if reason == "skipped" else "Playback Stopped"
    emoji = f"{emojis.get('skip')}" if reason == "skipped" else f"{emojis.get('musicstop_icons')}"
    
    description = (
        f"The song **{data['title']}** was skipped or changed. Live lyrics syncing has ended."
        if reason == "skipped"
        else f"Playback for **{data['title']}** has stopped or the player disconnected. Live lyrics syncing has ended."
    )
    
    container_ns["_body"] = discord.ui.TextDisplay(f"## {emoji} {title}\n{description}")
    
    container_cls = type("_StoppedLyricsContainer", (discord.ui.Container,), container_ns)
    
    class StoppedLyricsView(discord.ui.LayoutView):
        def __init__(self):
            super().__init__(timeout=60)
            self.container = container_cls(accent_color=failed_color)
            self.add_item(self.container)
            
    return StoppedLyricsView()


async def sync_lyrics_loop(ctx, loading_msg, track, lines, data, color=0xFFB7C5, failed_color=0xFF9E9E):
    import logging
    log = logging.getLogger("music.lyrics")
    active = True
    stop_reason = "stopped"
    update_rate = 3.0
    last_index = -2

    async def update_message():
        nonlocal active, stop_reason, last_index
        player = get_player(ctx.bot, ctx.guild.id)
        if not player or not player.is_playing or not player.current:
            stop_reason = "stopped"
            active = False
            return False
        
        if player.current.title != track.title:
            stop_reason = "skipped"
            active = False
            return False
            
        pos = player.position + 1000
        cur_idx = 0
        for i, line in enumerate(lines):
            if line["time"] <= pos:
                cur_idx = i
            else:
                break
                
        if cur_idx == last_index:
            return True
        last_index = cur_idx
        
        display_lines = []
        if cur_idx - 2 >= 0:
            display_lines.append(lines[cur_idx - 2]["text"])
        else:
            display_lines.append("\u200b")
            
        if cur_idx - 1 >= 0:
            display_lines.append(lines[cur_idx - 1]["text"])
        else:
            display_lines.append("\u200b")
            
        display_lines.append(f"### **{lines[cur_idx]['text']}**")
        
        if cur_idx + 1 < len(lines):
            display_lines.append(lines[cur_idx + 1]["text"])
        else:
            display_lines.append("\u200b")
            
        if cur_idx + 2 < len(lines):
            display_lines.append(lines[cur_idx + 2]["text"])
        else:
            display_lines.append("\u200b")
            
        view = build_synced_lyrics_panel(data, display_lines, cur_idx + 1, len(lines), color)
        try:
            await loading_msg.edit(view=view)
        except Exception:
            active = False
            return False
            
        return True

    try:
        success = await update_message()
        if not success:
            view = build_stopped_panel(data, stop_reason, failed_color)
            await loading_msg.edit(view=view)
            return
            
        while active:
            await asyncio.sleep(update_rate)
            if not active:
                break
            success = await update_message()
            if not success:
                break
    except Exception as e:
        log.error("Error in sync_lyrics_loop: %s", e)
    
    try:
        view = build_stopped_panel(data, stop_reason, failed_color)
        await loading_msg.edit(view=view)
    except Exception:
        pass


