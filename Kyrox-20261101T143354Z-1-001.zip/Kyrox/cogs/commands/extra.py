from utils.database import connect
from utils import emojis
import math
from PIL import Image, ImageDraw, ImageFont
from io import BytesIO

import os 
import discord
from discord.ext import commands
from discord.ui import View, Button
from utils.cv2_compat import embed_to_view
from utils import emojis as cemojis
import datetime
import sys
import psutil
import time
from utils.Tools import *
from discord.ext import commands, menus
from discord.ext.commands import BucketType, cooldown
import requests
from typing import *
from utils import *
from utils.config import BotName, serverLink
from utils import Paginator, DescriptionEmbedPaginator, FieldPagePaginator, TextPaginator
from core import Cog, Kyrox, Context
from typing import Optional
import aiosqlite 
import asyncio
import aiohttp


start_time = time.time()


def datetime_to_seconds(thing: datetime.datetime):
  current_time = datetime.datetime.fromtimestamp(time.time())
  return round(
    round(time.time()) +
    (current_time - thing.replace(tzinfo=None)).total_seconds())

tick = f"{emojis.TICK}"
cross = f"{emojis.CROSSICON}"


class RoleInfoView(View):
  def __init__(self, role: discord.Role, author_id):
    super().__init__(timeout=180)
    self.role = role
    self.author_id = author_id

  @discord.ui.button(label='Show Permissions',  emoji=f"{emojis.COMMANDS}", style=discord.ButtonStyle.secondary)
  async def show_permissions(self, interaction: discord.Interaction, button: Button):
    if interaction.user.id != self.author_id:
          await interaction.response.send_message("Uh oh! That message doesn't belong to you. You must run this command to interact with it.", ephemeral=True)
          return

    permissions = [perm.replace("_", " ").title() for perm, value in self.role.permissions if value]
    permission_text = ", ".join(permissions) if permissions else "None"
    embed = discord.Embed(title=f"Permissions for {self.role.name}", description=permission_text or "No permissions.", color=self.role.color)
    await interaction.response.send_message(view = embed_to_view(embed), ephemeral=True)

    
class OverwritesView(View):
  def __init__(self, channel, author_id):
      super().__init__(timeout=180)
      self.channel = channel
      self.author_id = author_id

  @discord.ui.button(label='Show Overwrites', style=discord.ButtonStyle.primary)
  async def show_overwrites(self, interaction: discord.Interaction, button: Button):
      if interaction.user.id != self.author_id:
          await interaction.response.send_message("Uh oh! That message doesn't belong to you. You must run this command to interact with it.", ephemeral=True)
          return

      overwrites = []
      for target, perms in self.channel.overwrites.items():
          permissions = {
              "View Channel": perms.view_channel,
              "Send Messages": perms.send_messages,
              "Read Message History": perms.read_message_history,
              "Manage Messages": perms.manage_messages,
              "Embed Links": perms.embed_links,
              "Attach Files": perms.attach_files,
              "Manage Channels": perms.manage_channels,
              "Manage Permissions": perms.manage_permissions,
              "Manage Webhooks": perms.manage_webhooks,
              "Create Instant Invite": perms.create_instant_invite,
              "Add Reactions": perms.add_reactions,
              "Mention Everyone": perms.mention_everyone,
              "Kick Members": perms.kick_members,
              "Ban Members": perms.ban_members,
              "Moderate Members": perms.moderate_members,
              "Send TTS Messages": perms.send_tts_messages,
              "Use External Emojis": perms.external_emojis,
              "Use External Stickers": perms.external_stickers,
              "View Audit Log": perms.view_audit_log,
              "Voice Mute Members": perms.mute_members,
              "Voice Deafen Members": perms.deafen_members,
              "Administrator": perms.administrator
          }

          overwrites.append(f"**For {target.name}**\n" +
                            "\n".join(f"  * **{perm}:** {f'{emojis.TICK}' if value else f'{emojis.CROSSICON}' if value is False else '⛔'}" for perm, value in permissions.items()))

      embed = discord.Embed(title=f"Overwrites for {self.channel.name}", color=discord.Color.blurple())
      embed.description = "\n".join(overwrites) if overwrites else "No overwrites for this channel."
      embed.set_footer(text=f"{emojis.TICK} = Allowed, {emojis.CROSSICON} = Denied, ⛔ = None")
      await interaction.response.send_message(view = embed_to_view(embed), ephemeral=True)


def generate_ping_card(
    bg_path,
    avatar_bytes,
    bot_name,
    websocket_latency,
    db_latency,
    lavalink_latency,
    response_time,
    bold_font_path,
    light_font_path
) -> BytesIO:
    bg = Image.open(bg_path)
    
    target_w, target_h = 1600, 520
    bg_w, bg_h = bg.size
    
    ratio = max(target_w / bg_w, target_h / bg_h)
    new_w = int(bg_w * ratio)
    new_h = int(bg_h * ratio)
    bg_resized = bg.resize((new_w, new_h), Image.Resampling.LANCZOS)
    
    left = (new_w - target_w) // 2
    top = (new_h - target_h) // 2
    bg_cropped = bg_resized.crop((left, top, left + target_w, top + target_h))
    
    canvas = bg_cropped.convert("RGBA")
    overlay = Image.new("RGBA", canvas.size, (0, 0, 0, 0))
    draw = ImageDraw.Draw(overlay)
    
    draw.rectangle([0, 0, target_w, target_h], fill=(10, 15, 20, 70))
    
    title_font = ImageFont.truetype(bold_font_path, 72)
    subtitle_font = ImageFont.truetype(light_font_path, 28)
    label_font = ImageFont.truetype(bold_font_path, 26)
    value_font = ImageFont.truetype(light_font_path, 24)
    
    center_x, center_y = 220, 260
    
    cyan_glow = (0, 229, 255, 255)
    draw.ellipse(
        [center_x - 147, center_y - 147, center_x + 147, center_y + 147],
        outline=cyan_glow,
        width=8
    )
    
    pink_glow = (255, 0, 127, 255)
    draw.ellipse(
        [center_x - 141, center_y - 141, center_x + 141, center_y + 141],
        outline=pink_glow,
        width=6
    )
    
    avatar = None
    if avatar_bytes:
        try:
            avatar = Image.open(BytesIO(avatar_bytes)).convert("RGBA")
        except Exception:
            avatar = None
            
    if avatar is None:
        avatar = Image.new("RGBA", (270, 270), (20, 30, 45, 255))
        av_draw = ImageDraw.Draw(avatar)
        av_draw.ellipse([40, 40, 230, 230], fill=(255, 0, 127, 100))
        av_draw.ellipse([80, 80, 190, 190], fill=(0, 229, 255, 120))
        
    avatar_resized = avatar.resize((270, 270), Image.Resampling.LANCZOS)
    
    mask = Image.new("L", (270, 270), 0)
    mask_draw = ImageDraw.Draw(mask)
    mask_draw.ellipse([0, 0, 270, 270], fill=255)
    
    avatar_circular = Image.new("RGBA", (270, 270), (0, 0, 0, 0))
    avatar_circular.paste(avatar_resized, (0, 0), mask=mask)
    overlay.paste(avatar_circular, (center_x - 135, center_y - 135), mask=mask)
    
    draw.text((420, 100), f"{bot_name} Latency", font=title_font, fill=(255, 255, 255, 255))
    draw.text((420, 185), "Real-time API & connection response status", font=subtitle_font, fill=(200, 220, 220, 230))
    
    api_text = f"API LATENCY ({websocket_latency}MS)"
    draw.text((420, 265), api_text, font=label_font, fill=pink_glow)
    
    graph1_start_x = 420
    graph1_end_x = 740
    graph_w = graph1_end_x - graph1_start_x
    baseline_y = 380
    
    wave1_points = []
    fill_poly1 = [(graph1_start_x, baseline_y + 60)]
    
    for px in range(graph1_start_x, graph1_end_x + 1):
        x_norm = (px - graph1_start_x) / graph_w
        y = baseline_y + 35 * math.sin(x_norm * 2.6 * math.pi + 0.6 * math.pi)
        y += 10 * math.sin(x_norm * 5.0 * math.pi)
        wave1_points.append((px, y))
        fill_poly1.append((px, y))
        
    fill_poly1.append((graph1_end_x, baseline_y + 60))
    
    draw.polygon(fill_poly1, fill=(255, 0, 127, 20))
    
    for i in range(len(wave1_points) - 1):
        draw.line([wave1_points[i], wave1_points[i+1]], fill=pink_glow, width=6)
        
    end_x, end_y = wave1_points[-1]
    draw.ellipse([end_x - 10, end_y - 10, end_x + 10, end_y + 10], fill=(255, 255, 255, 255))
    
    resp_text = f"RESPONSE TIME ({response_time}MS)"
    draw.text((820, 265), resp_text, font=label_font, fill=cyan_glow)
    
    graph2_start_x = 820
    graph2_end_x = 1140
    graph_w2 = graph2_end_x - graph2_start_x
    
    wave2_points = []
    fill_poly2 = [(graph2_start_x, baseline_y + 60)]
    
    for px in range(graph2_start_x, graph2_end_x + 1):
        x_norm = (px - graph2_start_x) / graph_w2
        y = baseline_y + 35 * math.sin(x_norm * 2.5 * math.pi + 1.2 * math.pi)
        y += 12 * math.cos(x_norm * 4.5 * math.pi)
        wave2_points.append((px, y))
        fill_poly2.append((px, y))
        
    fill_poly2.append((graph2_end_x, baseline_y + 60))
    
    draw.polygon(fill_poly2, fill=(0, 229, 255, 20))
    
    for i in range(len(wave2_points) - 1):
        draw.line([wave2_points[i], wave2_points[i+1]], fill=cyan_glow, width=6)
        
    end_x2, end_y2 = wave2_points[-1]
    draw.ellipse([end_x2 - 10, end_y2 - 10, end_x2 + 10, end_y2 + 10], fill=(255, 255, 255, 255))
    
    db_val = f"{db_latency}ms" if isinstance(db_latency, (int, float)) else str(db_latency)
    lava_val = f"{lavalink_latency}ms" if isinstance(lavalink_latency, (int, float)) else str(lavalink_latency)
    footer_text = f"Database: {db_val}   •   Lavalink: {lava_val}"
    draw.text((420, 450), footer_text, font=value_font, fill=(240, 250, 250, 240))
    
    final_img = Image.alpha_composite(canvas, overlay)
    final_img_resized = final_img.resize((800, 260), Image.Resampling.LANCZOS)
    
    buf = BytesIO()
    final_img_resized.save(buf, "PNG")
    buf.seek(0)
    return buf


class Extra(commands.Cog):

  def __init__(self, bot):
    self.bot = bot
    self.color = 0x000000
    self.start_time = datetime.datetime.now()

  @commands.hybrid_group(name="banner")
  @blacklist_check()
  @ignore_check()
  @commands.cooldown(1, 3, commands.BucketType.user)
  async def banner(self, ctx):
    if ctx.invoked_subcommand is None:
      await ctx.send_help(ctx.command)

  @banner.command(name="server")
  @blacklist_check()
  @ignore_check()
  @commands.cooldown(1, 3, commands.BucketType.user)
  @commands.max_concurrency(1, per=commands.BucketType.default, wait=False)
  async def server(self, ctx):
    if not ctx.guild.banner:
      await ctx.reply(f"{cross} This server doesn't have a banner.")
    else:
      webp = ctx.guild.banner.replace(format='webp')
      jpg = ctx.guild.banner.replace(format='jpg')
      png = ctx.guild.banner.replace(format='png')
      embed = discord.Embed(
        color=self.color,
        description=f"[`PNG`]({png}) | [`JPG`]({jpg}) | [`WEBP`]({webp})"
        if not ctx.guild.banner.is_animated() else
        f"[`PNG`]({png}) | [`JPG`]({jpg}) | [`WEBP`]({webp}) | [`GIF`]({ctx.guild.banner.replace(format='gif')})"
      )
      embed.set_image(url=ctx.guild.banner)
      embed.set_author(name=ctx.guild.name,
                       icon_url=ctx.guild.icon.url
                       if ctx.guild.icon else ctx.guild.default_icon.url)
      embed.set_footer(text=f"Requested By {ctx.author}",
                       icon_url=ctx.author.avatar.url
                       if ctx.author.avatar else ctx.author.default_avatar.url)
      await ctx.reply(view = embed_to_view(embed))

  
  @banner.command(name="user")
  @blacklist_check()
  @ignore_check()
  @commands.cooldown(1, 3, commands.BucketType.user)
  @commands.max_concurrency(1, per=commands.BucketType.default, wait=False)
  @commands.guild_only()
  async def _user(self,
                  ctx,
                  member: Optional[Union[discord.Member,
                                         discord.User]] = None):
    if member == None or member == "":
      member = ctx.author
    bannerUser = await self.bot.fetch_user(member.id)
    if not bannerUser.banner:
      await ctx.reply("{} | {} doesn't have a banner.".format(cross, member))
    else:
      webp = bannerUser.banner.replace(format='webp')
      jpg = bannerUser.banner.replace(format='jpg')
      png = bannerUser.banner.replace(format='png')
      embed = discord.Embed(
        color=self.color,
        description=f"[`PNG`]({png}) | [`JPG`]({jpg}) | [`WEBP`]({webp})"
        if not bannerUser.banner.is_animated() else
        f"[`PNG`]({png}) | [`JPG`]({jpg}) | [`WEBP`]({webp}) | [`GIF`]({bannerUser.banner.replace(format='gif')})"
      )
      embed.set_author(name=f"{member}",
                       icon_url=member.avatar.url
                       if member.avatar else member.default_avatar.url)
      embed.set_image(url=bannerUser.banner)
      embed.set_footer(text=f"Requested By {ctx.author}",
                       icon_url=ctx.author.avatar.url
                       if ctx.author.avatar else ctx.author.default_avatar.url)

      await ctx.send(view = embed_to_view(embed))


  
  

  @commands.command(name="uptime", description="Shows the Bot's Uptime.")
  @blacklist_check() 
  @ignore_check()
  @commands.cooldown(1, 3, commands.BucketType.user)
  async def uptime(self, ctx):
      pfp = ctx.author.display_avatar.url

      uptime_seconds = int(round(time.time() - start_time))
      uptime_timedelta = datetime.timedelta(seconds=uptime_seconds)

      uptime_string = f"Up since {datetime.datetime.utcfromtimestamp(start_time).strftime('%Y-%m-%d %H:%M:%S')} UTC"
      uptime_duration_string = f"{uptime_timedelta.days} days, {uptime_timedelta.seconds // 3600} hours, {(uptime_timedelta.seconds // 60) % 60} minutes, {uptime_timedelta.seconds % 60} seconds"

      embed = discord.Embed(
        title="Uptime",
        description=f"**Online:** `{uptime_duration_string}`\n**Started:** `{uptime_string}`",
        color=self.color
      )
      embed.set_footer(text=f"Requested by {ctx.author}", icon_url=pfp)

      await ctx.send(view = embed_to_view(embed))

    

  @commands.hybrid_command(name="serverinfo",
                           aliases=["sinfo", "si"],
                           with_app_command=True)
  @blacklist_check() 
  @ignore_check()
  @commands.cooldown(1, 3, commands.BucketType.user)
  async def serverinfo(self, ctx):
        guild = ctx.guild
        from utils import emojis as cemojis
        
        # 1. About Server
        owner = guild.owner
        owner_text = f"{owner.mention}" if owner else f"<@{guild.owner_id}>"
        created_timestamp = round(guild.created_at.timestamp())
        total_members = guild.member_count or len(guild.members)
        
        # 2. Extras
        verification_levels = {
            discord.VerificationLevel.none: "None",
            discord.VerificationLevel.low: "Low",
            discord.VerificationLevel.medium: "Medium",
            discord.VerificationLevel.high: "High",
            discord.VerificationLevel.highest: "Highest"
        }
        ver_level = verification_levels.get(guild.verification_level, str(guild.verification_level).capitalize())
        mfa_level = "Enabled" if guild.mfa_level == discord.MFALevel.require_2fa else "Disabled"
        
        content_filter_levels = {
            discord.ContentFilter.disabled: "Disabled",
            discord.ContentFilter.no_role: "Members Without Roles",
            discord.ContentFilter.all_members: "All Members"
        }
        content_filter = content_filter_levels.get(guild.explicit_content_filter, str(guild.explicit_content_filter).capitalize())
        
        # 3. Features
        feature_map = {
            "ANIMATED_BANNER": "Animated Banner",
            "ANIMATED_ICON": "Animated Icon",
            "BANNER": "Banner",
            "COMMUNITY": "Community",
            "DISCOVERABLE": "Discoverable",
            "FEATURABLE": "Featurable",
            "INVITE_SPLASH": "Invite Splash",
            "MEMBER_VERIFICATION_GATE_ENABLED": "Member Verification Gate",
            "NEWS": "News Channels",
            "PARTNERED": "Partnered Server",
            "VANITY_URL": "Vanity URL",
            "VERIFIED": "Verified Server",
            "VIP_REGIONS": "VIP Voice Regions",
            "WELCOME_SCREEN_ENABLED": "Welcome Screen Enabled",
            "SOUNDBOARD": "Soundboard",
            "GUILD_ONBOARDING_EVER_ENABLED": "Guild Onboarding Ever Enabled",
            "GUILD_ONBOARDING": "Guild Onboarding",
            "GUILD_SERVER_GUIDE": "Guild Server Guide",
        }
        
        feature_list = []
        for f in guild.features:
            name = feature_map.get(f, f.replace("_", " ").title())
            feature_list.append(f"> ✅ : {name}")
            
        if len(feature_list) > 15:
            features_displayed = feature_list[:15]
            features_displayed.append("> ✅ : And many more ...")
        else:
            features_displayed = feature_list
        features_text = "\n".join(features_displayed) if features_displayed else "> None"
        
        # 4. Members
        humans = sum(1 for m in guild.members if not m.bot)
        bots = sum(1 for m in guild.members if m.bot)
        
        # 5. Channels
        categories = len(guild.categories)
        text_channels = len(guild.text_channels)
        voice_channels = len(guild.voice_channels)
        stage_channels = len(guild.stage_channels)
        
        # 6. Emojis
        regular_emojis = sum(1 for emoji in guild.emojis if not emoji.animated)
        animated_emojis = sum(1 for emoji in guild.emojis if emoji.animated)
        stickers = len(guild.stickers)
        total_emojis = len(guild.emojis) + stickers
        
        # 7. Boosts
        boost_level = f"{guild.premium_tier} Level"
        boost_count = guild.premium_subscription_count
        boosters = len(guild.premium_subscribers)
        booster_role = guild.premium_subscriber_role.mention if guild.premium_subscriber_role else "None"
        
        # 8. Roles
        roles = [role for role in reversed(guild.roles) if not role.is_default()]
        total_roles = len(roles)
        max_roles_to_show = 25
        role_mentions = [role.mention for role in roles[:max_roles_to_show]]
        if total_roles > max_roles_to_show:
            roles_text = ", ".join(role_mentions) + f", and {total_roles - max_roles_to_show} more..."
        else:
            roles_text = ", ".join(role_mentions) if role_mentions else "None"
            
        # Create Embed
        embed = discord.Embed(
            title=f"{guild.name}'s Info",
            color=self.color
        )
        
        # Add Fields in order matching user request
        embed.add_field(
            name=f"{cemojis.HOME} __About Server__",
            value=(
                f"> **Name :** {guild.name}\n"
                f"> **Server ID :** {guild.id}\n"
                f"> **Owner [ {cemojis.AXON_OWNER} ] :** {owner_text}\n"
                f"> **Created At :** <t:{created_timestamp}:R>\n"
                f"> **Total Members :** {total_members}"
            ),
            inline=False
        )
        
        embed.add_field(
            name=f"{cemojis.TICK} __Extras__",
            value=(
                f"> **Verification Level :** {ver_level}\n"
                f"> **MFA Level :** {mfa_level}\n"
                f"> **Content Filter :** {content_filter}"
            ),
            inline=False
        )
        
        desc_lines = (guild.description or "No description set.").split("\n")
        desc_value = "\n".join(f"> {line}" for line in desc_lines)
        embed.add_field(
            name=f"{cemojis.FILE} __Description__",
            value=desc_value,
            inline=False
        )
        
        embed.add_field(
            name=f"{cemojis.COMMANDS} __Features__",
            value=features_text,
            inline=False
        )
        
        embed.add_field(
            name=f"{cemojis.USER} __Members__",
            value=(
                f"> **Total Members :** {total_members}\n"
                f"> **Humans :** {humans}\n"
                f"> **Bots :** {bots}"
            ),
            inline=False
        )
        
        embed.add_field(
            name=f"{cemojis.ICONS_CHANNEL} __Channels__",
            value=(
                f"> **Categories :** {categories}\n"
                f"> **Text Channels :** {text_channels}\n"
                f"> **Voice Channels :** {voice_channels}\n"
                f"> **Stage Channels :** {stage_channels}"
            ),
            inline=False
        )
        
        embed.add_field(
            name=f"{cemojis.ICONS_BOT} __Emojis__",
            value=(
                f"> **Regular emojis :** {regular_emojis}\n"
                f"> **Animated emojis :** {animated_emojis}\n"
                f"> **Stickers :** {stickers}\n"
                f"> **Total :** {total_emojis}"
            ),
            inline=False
        )
        
        embed.add_field(
            name=f"{cemojis.ICON_BOOSTER} __Boosts__",
            value=(
                f"> **Boost Level :** {boost_level}\n"
                f"> **Boost count :** {boost_count}\n"
                f"> **Boosters :** {boosters}\n"
                f"> **Booster Role :** {booster_role}"
            ),
            inline=False
        )
        
        roles_value = f"> {roles_text}"
        embed.add_field(
            name=f"{cemojis.CUSTOMROLE} __Roles__",
            value=roles_value,
            inline=False
        )
        
        # Set thumbnail (icon)
        if guild.icon:
            embed.set_thumbnail(url=guild.icon.url)
            
        # Set banner
        if guild.banner:
            embed.set_image(url=guild.banner.url)
            
        embed.set_footer(
            text=f"requested by {ctx.author.name}",
            icon_url=ctx.author.display_avatar.url
        )
        embed.timestamp = discord.utils.utcnow()
        
        await ctx.send(embed=embed)
        

  
  @commands.hybrid_command(name="userinfo",
                           aliases=["whois", "ui"],
                           usage="Userinfo [user]",
                           with_app_command=True)
  @blacklist_check()
  @ignore_check()
  @commands.cooldown(1, 3, commands.BucketType.user)
  @commands.max_concurrency(1, per=commands.BucketType.default, wait=False)
  @commands.guild_only()
  async def _userinfo(self,
                      ctx,
                      member: Optional[Union[discord.Member,
                                             discord.User]] = None):
    if member == None or member == "":
      member = ctx.author
    elif member not in ctx.guild.members:
      member = await self.bot.fetch_user(member.id)

    if member in ctx.guild.members:
      nickk = f"{member.nick if member.nick else 'None'}"
      joinedat = f"<t:{round(member.joined_at.timestamp())}:R>"
    else:
      nickk = "None"
      joinedat = "None"

    # Key perms logic
    kp = []
    if member in ctx.guild.members:
      if member.guild_permissions.administrator:
        kp.append("Administrator")
      if member.guild_permissions.manage_guild:
        kp.append("Manage Guild")
      if member.guild_permissions.manage_roles:
        kp.append("Manage Roles")
      if member.guild_permissions.manage_channels:
        kp.append("Manage Channels")
      if member.guild_permissions.manage_messages:
        kp.append("Manage Messages")
      if member.guild_permissions.manage_webhooks:
        kp.append("Manage Webhooks")
      if member.guild_permissions.manage_nicknames:
        kp.append("Manage Nicknames")
      if member.guild_permissions.kick_members:
        kp.append("Kick Members")
      if member.guild_permissions.ban_members:
        kp.append("Ban Members")
      if member.guild_permissions.mute_members:
        kp.append("Mute Members")
      if member.guild_permissions.deafen_members:
        kp.append("Deafen Members")
      if member.guild_permissions.move_members:
        kp.append("Move Members")
      if member.guild_permissions.view_audit_log:
        kp.append("View Audit Log")

    kp_text = ", ".join(kp) if kp else "None"

    if member in ctx.guild.members:
      if member == ctx.guild.owner:
        aklm = "Server Owner"
      elif member.guild_permissions.administrator:
        aklm = "Administrator"
      elif member.guild_permissions.ban_members or member.guild_permissions.kick_members:
        aklm = "Moderator"
      else:
        aklm = "Member"
    else:
      aklm = "Not in server"

    bannerUser = await self.bot.fetch_user(member.id)
    top_role = member.top_role.mention if member in ctx.guild.members and len(member.roles) > 1 else "None"
    role_count = len(member.roles) - 1 if member in ctx.guild.members else 0
    
    voice = "Not in voice"
    if member in ctx.guild.members and member.voice:
        voice = member.voice.channel.mention
        
    boosting = "Not boosting"
    if member in ctx.guild.members and member in ctx.guild.premium_subscribers:
        boosting = f"<t:{round(member.premium_since.timestamp())}:R>"

    embed = discord.Embed(
      title=f"{member.name}'s info",
      color=0X000000
    )
    
    embed.add_field(
        name=f"{cemojis.USER} General",
        value=(
            f"> **Name :** {member.name}\n"
            f"> **ID :** {member.id}\n"
            f"> **Nickname :** {nickk}\n"
            f"> **Is Bot :** {'Yes' if member.bot else 'No'}\n"
            f"> **Account Created :** <t:{round(member.created_at.timestamp())}:R>\n"
            f"> **Server Joined :** {joinedat}\n"
        ),
        inline=False
    )
    
    embed.add_field(
        name=f"<:website:1475416574419537920> Roles",
        value=(
            f"> **Top Role :** {top_role}\n"
            f"> **Total Roles :** {role_count}\n"
        ),
        inline=False
    )
    
    embed.add_field(
        name=f"{cemojis.ICONS_PLUS} Extras",
        value=(
            f"> **Boosting :** {boosting}\n"
            f"> **Voice :** {voice}\n"
        ),
        inline=False
    )
    
    embed.add_field(
        name=f"{cemojis.MOD} Key Perms",
        value=f"> {kp_text}\n",
        inline=False
    )
    
    embed.add_field(
        name="<:icons_verified:1475416654811758682> Acknowledgement",
        value=f"> {aklm}",
        inline=False
    )

    embed.set_thumbnail(url=member.display_avatar.url)
    if bannerUser.banner:
      embed.set_image(url=bannerUser.banner)

    now = discord.utils.utcnow().strftime('%A, %d %B %Y %H:%M')
    embed.set_footer(
        text=f"requested by {ctx.author.name} • {now}",
        icon_url=ctx.author.display_avatar.url
    )

    from utils.cv2_compat import embed_to_view
    await ctx.send(view=embed_to_view(embed))



  @commands.hybrid_command(name='roleinfo', aliases=["ri"], help="Displays information about a specified role.")
  @blacklist_check()
  @ignore_check()
  @commands.cooldown(1, 3, commands.BucketType.user)
  async def roleinfo(self, ctx, role: discord.Role):
    members = role.members
    created_at = role.created_at.strftime("%Y-%m-%d %H:%M:%S")

    embed = discord.Embed(
      title=f"Role Information - {role.name}",
      color=role.color,
      timestamp=discord.utils.utcnow()
    )
    embed.add_field(name="__General Information__", value=f"**ID:** {role.id}\n**Name:** {role.name}\n**Mention:** <@&{role.id}>\n**Color:** {str(role.color)}\n**Total Member:** {len(role.members)}\n", inline=True)
    total_roles = len(ctx.guild.roles) - 0
    role_position = total_roles - role.position
    embed.add_field(name="Position", value=str(role_position), inline=True)
    embed.add_field(name="Mentionable", value=str(role.mentionable), inline=True)
    embed.add_field(name="Hoisted", value=str(role.hoist), inline=True)
    embed.add_field(name="Managed", value=str(role.managed), inline=True)
    embed.add_field(name="Created At", value=created_at, inline=True)
    embed.set_footer(text=f"Requested By {ctx.author}",
                    icon_url=ctx.author.avatar.url if ctx.author.avatar else ctx.author.default_avatar.url)

    view = RoleInfoView(role, ctx.author.id)
    await ctx.send(view = embed_to_view(embed, view = view))





  @commands.command(name="boostcount",
                    help="Shows boosts count",
                    usage="boosts",
                    aliases=["bco"],
                    with_app_command=True)
  @blacklist_check()
  @ignore_check()
  @commands.cooldown(1, 3, commands.BucketType.user)
  async def boosts(self, ctx):
    await ctx.send(
      view = embed_to_view(discord.Embed(title=f"{emojis.ICON_BOOSTER} Boosts Count Of {ctx.guild.name}",
                          description="**Total `%s` boosts**" %
                          (ctx.guild.premium_subscription_count),
                          color=self.color)))

  @commands.hybrid_group(name="list",
                         invoke_without_command=True,
                         with_app_command=True)
  @blacklist_check()
  @ignore_check()
  @commands.cooldown(1, 3, commands.BucketType.user)
  async def __list_(self, ctx: commands.Context):
    if ctx.subcommand_passed is None:
      await ctx.send_help(ctx.command)
      ctx.command.reset_cooldown(ctx)

  @__list_.command(name="boosters",
                   aliases=["boost", "booster"],
                   usage="List boosters",
                   help="List of boosters in the Guild",
                   with_app_command=True)
  @blacklist_check()
  @ignore_check()
  @commands.cooldown(1, 3, commands.BucketType.user)
  async def list_boost(self, ctx):
    guild = ctx.guild
    entries = [
      f"`#{no}.` [{mem}](https://discord.com/users/{mem.id}) [{mem.mention}] - <t:{round(mem.premium_since.timestamp())}:R>"
      for no, mem in enumerate(guild.premium_subscribers, start=1)
    ]
    paginator = Paginator(source=DescriptionEmbedPaginator(
      entries=entries,
      title=
      f"List of Boosters in {guild.name} - {len(guild.premium_subscribers)}",
      description="",
      per_page=10),
                          ctx=ctx)
    await paginator.paginate()

  @__list_.command(name="bans", help= "List of all banned members in Guild", aliases=["ban"], with_app_command=True)
  @blacklist_check()
  @ignore_check()
  @commands.cooldown(1, 3, commands.BucketType.user)
  @commands.has_permissions(view_audit_log=True)
  @bot_has_permissions(view_audit_log=True)
  async def list_ban(self, ctx):
    bans = [member async for member in ctx.guild.bans()]
    if len(bans) == 0:
      return await ctx.reply("There aren't any banned users in this guild.", mention_author=False)
    else:
      mems = ([
      member async for member in ctx.guild.bans()
    ])
      guild = ctx.guild
      entries = [
      f"`#{no}.` {mem}"
      for no, mem in enumerate(mems, start=1)
    ]
      paginator = Paginator(source=DescriptionEmbedPaginator(
      entries=entries,
      title=f"Banned Users in {guild.name} - {len(bans)}",
      description="",
      per_page=10),
                          ctx=ctx)
      await paginator.paginate()

  @__list_.command(
    name="inrole",
    aliases=["inside-role"],
    help="List of members that are in the specified role",
    with_app_command=True)
  @blacklist_check()
  @ignore_check()
  @commands.cooldown(1, 3, commands.BucketType.user)
  async def list_inrole(self, ctx, role: discord.Role):
    guild = ctx.guild
    entries = [
      f"`#{no}.` [{mem}](https://discord.com/users/{mem.id}) [{mem.mention}] - <t:{int(mem.created_at.timestamp())}:D>"
      for no, mem in enumerate(role.members, start=1)
    ]
    paginator = Paginator(source=DescriptionEmbedPaginator(
      entries=entries,
      title=f"List of Members in {role} - {len(role.members)}",
      description="",
      per_page=10),
                          ctx=ctx)
    await paginator.paginate()

  @__list_.command(name="emojis",
                   aliases=["emoji"],
                   help="List of emojis in the Guild with ids",
                   with_app_command=True)
  @blacklist_check()
  @ignore_check()
  @commands.cooldown(1, 3, commands.BucketType.user)
  async def list_emojis(self, ctx):
    guild = ctx.guild
    entries = [
      f"`#{no}.` {e} - `{e}`"
      for no, e in enumerate(ctx.guild.emojis, start=1)
    ]
    paginator = Paginator(source=DescriptionEmbedPaginator(
      entries=entries,
      title=f"List of Emojis in {guild.name} - {len(ctx.guild.emojis)}",
      description="",
      per_page=10),
                          ctx=ctx)
    await paginator.paginate()

  @__list_.command(name="roles",
                   aliases=["role"],
                   help="List of all roles in the server with ids",
                   with_app_command=True)
  @blacklist_check()
  @ignore_check()
  @commands.cooldown(1, 3, commands.BucketType.user)
  @commands.has_permissions(manage_roles=True)
  async def list_roles(self, ctx):
    guild = ctx.guild
    entries = [
      f"`#{no}.` {e.mention} - `[{e.id}]`"
      for no, e in enumerate(ctx.guild.roles, start=1)
    ]
    paginator = Paginator(source=DescriptionEmbedPaginator(
      entries=entries,
      title=f"List of Roles in {guild.name} - {len(ctx.guild.roles)}",
      description="",
      per_page=10),
                          ctx=ctx)
    await paginator.paginate()

  @__list_.command(name="bots",
                   aliases=["bot"],
                   help="List of All Bots in a server",
                   with_app_command=True)
  @blacklist_check()
  @ignore_check()
  @commands.cooldown(1, 3, commands.BucketType.user)
  async def list_bots(self, ctx):
    guild = ctx.guild
    people = filter(lambda member: member.bot, ctx.guild.members)
    people = sorted(people, key=lambda member: member.joined_at)
    entries = [
      f"`#{no}.` [{mem}](https://discord.com/users/{mem.id}) [{mem.mention}]"
      for no, mem in enumerate(people, start=1)
    ]
    paginator = Paginator(source=DescriptionEmbedPaginator(
      entries=entries,
      title=f"Bots in {guild.name} - {len(people)}",
      description="",
      per_page=10),
                          ctx=ctx)
    await paginator.paginate()

  @__list_.command(name="admins",
                   aliases=["admin"],
                   help="List of all Admins of the Guild",
                   with_app_command=True)
  @blacklist_check()
  @ignore_check()
  @commands.cooldown(1, 3, commands.BucketType.user)
  async def list_admin(self, ctx):
    mems = ([
      mem for mem in ctx.guild.members
      if mem.guild_permissions.administrator
    ])
    mems = sorted(mems, key=lambda mem: not mem.bot)
    admins = len([
      mem for mem in ctx.guild.members
      if mem.guild_permissions.administrator
    ])
    guild = ctx.guild
    entries = [
      f"`#{no}.` [{mem}](https://discord.com/users/{mem.id}) [{mem.mention}] - <t:{int(mem.created_at.timestamp())}:D>"
      for no, mem in enumerate(mems, start=1)
    ]
    paginator = Paginator(source=DescriptionEmbedPaginator(
      entries=entries,
      title=f"Admins in {guild.name} - {admins}",
      description="",
      per_page=10),
                          ctx=ctx)
    await paginator.paginate()

  @__list_.command(name="invoice", help="List of all users in a voice channel", aliases=["invc"], with_app_command=True)
  @blacklist_check()
  @ignore_check()
  @commands.cooldown(1, 3, commands.BucketType.user)
  async def listusers(self, ctx):
    if not ctx.author.voice:
      return await ctx.send("You are not connected to a voice channel")
    members = ctx.author.voice.channel.members
    entries = [
      f"`[{n}]` | {member} [{member.mention}]"
      for n, member in enumerate(members, start=1)
    ]
    paginator = Paginator(source=DescriptionEmbedPaginator(
      entries=entries,
      description="",
      title=f"Voice List of {ctx.author.voice.channel.name} - {len(members)}",
      color=self.color),
                          ctx=ctx)
    await paginator.paginate()

  @__list_.command(name="moderators", help= "List of All Admins of a server", aliases=["mods"], with_app_command=True)
  @blacklist_check()
  @ignore_check()
  @commands.cooldown(1, 3, commands.BucketType.user)
  async def list_mod(self, ctx):
    membs = ([
      mem for mem in ctx.guild.members
      if mem.guild_permissions.ban_members
      or mem.guild_permissions.kick_members
    ])
    mems = filter(lambda member: member.bot, ctx.guild.members)
    mems = sorted(membs, key=lambda mem: mem.joined_at)
    admins = len([
      mem for mem in ctx.guild.members
      if mem.guild_permissions.ban_members
      or mem.guild_permissions.kick_members
    ])
    guild = ctx.guild
    entries = [
      f"`#{no}.` [{mem}](https://discord.com/users/{mem.id}) [{mem.mention}] - <t:{int(mem.created_at.timestamp())}:D>"
      for no, mem in enumerate(mems, start=1)
    ]
    paginator = Paginator(source=DescriptionEmbedPaginator(
      entries=entries,
      title=f"Mods in {guild.name} - {admins}",
      description="",
      per_page=10),
                          ctx=ctx)
    await paginator.paginate()

  @__list_.command(name="early", aliases=["sup"], help= "List of members that have Early Supporter badge.", with_app_command=True)
  @blacklist_check()
  @ignore_check()
  @commands.cooldown(1, 3, commands.BucketType.user)
  async def list_early(self, ctx):
    mems = ([
      memb for memb in ctx.guild.members
      if memb.public_flags.early_supporter
    ])
    mems = sorted(mems, key=lambda memb: memb.created_at)
    admins = len([
      memb for memb in ctx.guild.members
      if memb.public_flags.early_supporter
    ])
    guild = ctx.guild
    entries = [
      f"`#{no}.` [{mem}](https://discord.com/users/{mem.id})  [{mem.mention}] - <t:{int(mem.created_at.timestamp())}:D>"
      for no, mem in enumerate(mems, start=1)
    ]
    paginator = Paginator(source=DescriptionEmbedPaginator(
      entries=entries,
      title=f"Early Supporters Id's in {guild.name} - {admins}",
      description="",
      per_page=10),
                          ctx=ctx)
    await paginator.paginate()

  @__list_.command(name="activedeveloper", help= "List of members that have Active Developer badge.",
                   aliases=["activedev"],
                   with_app_command=True)
  @blacklist_check()
  @ignore_check()
  @commands.cooldown(1, 3, commands.BucketType.user)
  async def list_activedeveloper(self, ctx):
    mems = ([
      memb for memb in ctx.guild.members
      if memb.public_flags.active_developer
    ])
    mems = sorted(mems, key=lambda memb: memb.created_at)
    admins = len([
      memb for memb in ctx.guild.members
      if memb.public_flags.active_developer
    ])
    guild = ctx.guild
    entries = [
      f"`#{no}.` [{mem}](https://discord.com/users/{mem.id}) [{mem.mention}] - <t:{int(mem.created_at.timestamp())}:D>"
      for no, mem in enumerate(mems, start=1)
    ]
    paginator = Paginator(source=DescriptionEmbedPaginator(
      entries=entries,
      title=f"Active Developer Id's in {guild.name} - {admins}",
      description="",
      per_page=10),
                          ctx=ctx)
    await paginator.paginate()

  @__list_.command(name="createdat", help= "List of Account Creation Date of all Users", with_app_command=True)
  @blacklist_check()
  @ignore_check()
  @commands.cooldown(1, 3, commands.BucketType.user)
  async def list_cpos(self, ctx):
    mems = ([memb for memb in ctx.guild.members])
    mems = sorted(mems, key=lambda memb: memb.created_at)
    admins = len([memb for memb in ctx.guild.members])
    guild = ctx.guild
    entries = [
      f"`[{no}]` | [{mem}](https://discord.com/users/{mem.id}) - <t:{int(mem.created_at.timestamp())}:D>"
      for no, mem in enumerate(mems, start=1)
    ]
    paginator = Paginator(source=DescriptionEmbedPaginator(
      entries=entries,
      title=f"Creation every id in {guild.name} - {admins}",
      description="",
      per_page=10),
                          ctx=ctx)
    await paginator.paginate()

  @__list_.command(name="joinedat", help= "List of Guild Joined date of all Users", with_app_command=True)
  @blacklist_check()
  @ignore_check()
  @commands.cooldown(1, 3, commands.BucketType.user)
  async def list_joinpos(self, ctx):
    mems = ([memb for memb in ctx.guild.members])
    mems = sorted(mems, key=lambda memb: memb.joined_at)
    admins = len([memb for memb in ctx.guild.members])
    guild = ctx.guild
    entries = [
      f"`#{no}.` [{mem}](https://discord.com/users/{mem.id}) Joined At - <t:{int(mem.joined_at.timestamp())}:D>"
      for no, mem in enumerate(mems, start=1)
    ]
    paginator = Paginator(source=DescriptionEmbedPaginator(
      entries=entries,
      title=f"Join Position of every user in {guild.name} - {admins}",
      description="",
      per_page=10),
                          ctx=ctx)
    await paginator.paginate()




  @commands.command(name="joined-at",
                    help="Shows when a user joined",
                    usage="joined-at [user]",
                    with_app_command=True)
  @blacklist_check()
  @ignore_check()
  @commands.cooldown(1, 3, commands.BucketType.user)
  async def joined_at(self, ctx):
    joined = ctx.author.joined_at.strftime("%a, %d %b %Y %I:%M %p")
    await ctx.send(view = embed_to_view(discord.Embed(
      title="joined-at", description="**`%s`**" % (joined), color=self.color)))

  @commands.command(name="github", usage="github [search]")
  @blacklist_check()
  @ignore_check()
  @commands.cooldown(1, 3, commands.BucketType.user)
  async def github(self, ctx, *, search_query):
    json = requests.get(
      f"https://api.github.com/search/repositories?q={search_query}").json()

    if json["total_count"] == 0:
      await ctx.send(f"No matching repositories found with the name: {search_query}")
    else:
      await ctx.send(
        f"Found result for '{search_query}':\n{json['items'][0]['html_url']}")

  @commands.hybrid_command(name="vcinfo",
                           description="View information about a voice channel.",
                           help="View information about a voice channel.", 
                           usage="<VoiceChannel>",
                           with_app_command=True)
  @blacklist_check()
  @ignore_check()
  @commands.cooldown(1, 3, commands.BucketType.user)
  async def vcinfo(self, ctx, channel: discord.VoiceChannel = None):
    if channel is None:
      await ctx.reply(f"{cross} Please provide a valid voice channel.")
      return
    embed = discord.Embed(title=f"Voice Channel Info for: {channel.name}", color=self.color)
    embed.add_field(name="ID", value=channel.id, inline=True)
    embed.add_field(name="Members", value=len(channel.members), inline=True)
    embed.add_field(name="Bitrate", value=f"{channel.bitrate/1000} kbps", inline=True)
    embed.add_field(name="Created At", value=channel.created_at.strftime("%Y-%m-%d %H:%M:%S"), inline=True)
    embed.add_field(name="Category", value=channel.category.name if channel.category else "None", inline=True)
    embed.add_field(name="Region", value=channel.rtc_region, inline=True)

    if channel.user_limit:
      embed.add_field(name="User Limit", value=channel.user_limit, inline=True)

    if channel.overwrites:
      overwrites = []
      for role, permissions in channel.overwrites.items():
        overwrites.append(f"**{role}**: {permissions}")
      embed.add_field(name="Overwrites", value="\n".join(overwrites), inline=False)

    view = View()
    view.add_item(Button(label="Join", style=discord.ButtonStyle.green, url=f"https://discord.com/channels/{ctx.guild.id}/{channel.id}"))
    view.add_item(Button(label="Invite", style=discord.ButtonStyle.link, url=f"https://discord.com/channels/{ctx.guild.id}/{channel.id}/invite"))

    await ctx.send(view = embed_to_view(embed, view = view))


  @commands.hybrid_command(name="channelinfo",
     aliases=['cinfo', 'ci'],
     description='Get information about a channel.',
     help='Get information about a channel.',
     usage="<Channel>",
     with_app_command=True)
  @blacklist_check()
  @ignore_check()
  @commands.cooldown(1, 3, commands.BucketType.user)
  async def channelinfo(self, ctx, channel: discord.TextChannel = None):
    if channel is None:
      channel = ctx.channel
      
    embed = discord.Embed(title=f"Channel Info - {channel.name}",
    color=0x000000)
    embed.add_field(name="ID", value=channel.id, inline=False)
    embed.add_field(name="Created At", value=channel.created_at.strftime("%Y-%m-%d %H:%M:%S"), inline=False)
    embed.add_field(name="Category", value=channel.category.name if channel.category else "None", inline=False)
    embed.add_field(name="Topic", value=channel.topic if channel.topic else "None", inline=False)
    embed.add_field(name="Slowmode", value=f"{channel.slowmode_delay} seconds" if channel.slowmode_delay else "None", inline=False)
    embed.add_field(name="NSFW", value=channel.is_nsfw(), inline=False)
    embed.set_thumbnail(url="https://cdn.discordapp.com/emojis/1205345282158501899.png")
    embed.set_footer(text=f"Requested By {ctx.author}",
                       icon_url=ctx.author.avatar.url if ctx.author.avatar else ctx.author.default_avatar.url)
      
      
    view = OverwritesView(channel, ctx.author.id)
    view.add_item(Button(label="Redirect Channel", style=discord.ButtonStyle.green, url=f"https://discord.com/channels/{ctx.guild.id}/{channel.id}"))
      
    await ctx.send(view = embed_to_view(embed, view = view))


  @commands.command(name="ping", aliases=['latency'],
                      help="Checks the bot latency.",
                      with_app_command=True)
  @ignore_check()
  @blacklist_check()
  @commands.cooldown(1, 2, commands.BucketType.user)
  async def ping(self, ctx):
    start_time = time.perf_counter()
    msg = await ctx.reply("Checking latency...", mention_author=False)
    response_time = round((time.perf_counter() - start_time) * 1000)
    
    # 1. Websocket Latency
    websocket_latency = round(self.bot.latency * 1000)
    
    # 2. Database Latency
    db_latency = None
    try:
      async with connect('afk.db') as db:
        db_start = time.perf_counter()
        await db.execute("SELECT 1")
        db_end = time.perf_counter()
        db_latency = round((db_end - db_start) * 1000)
    except Exception as e:
      print(f"Error measuring database latency: {e}")
      db_latency = "N/A"
      
    # 3. Lavalink Latency
    lavalink_latency = None
    if hasattr(self.bot, 'lavalink') and self.bot.lavalink.node_manager.nodes:
      node = self.bot.lavalink.node_manager.nodes[0]
      if node.available:
        try:
          latency = await node.get_rest_latency()
          if latency != -1:
            lavalink_latency = round(latency)
        except Exception:
          pass
    if lavalink_latency is None:
      lavalink_latency = "N/A"
      
    # 4. Fetch Bot Avatar Bytes
    avatar_bytes = None
    if self.bot.user and self.bot.user.display_avatar:
      try:
        avatar_url = self.bot.user.display_avatar.with_format("png").url
        async with aiohttp.ClientSession() as session:
          async with session.get(avatar_url, timeout=5) as resp:
            if resp.status == 200:
              avatar_bytes = await resp.read()
      except Exception as e:
        print(f"Error fetching bot avatar: {e}")
        
    # 5. Resolve Paths
    root_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    bg_path = os.path.join(root_dir, "assets", "images", "cool-aesthetic-cloud-05bsl7m2e5bh01ki.jpg")
    bold_font_path = os.path.join(root_dir, "games", "assets", "HelveticaNeuBold.ttf")
    light_font_path = os.path.join(root_dir, "games", "assets", "segoe-ui-semilight-411.ttf")
    
    # 6. Generate Card Image in Executor
    try:
      image_buf = await asyncio.to_thread(
        generate_ping_card,
        bg_path,
        avatar_bytes,
        self.bot.user.name,
        websocket_latency,
        db_latency,
        lavalink_latency,
        response_time,
        bold_font_path,
        light_font_path
      )
      file = discord.File(image_buf, filename="ping.png")
    except Exception as e:
      print(f"Error generating ping card: {e}")
      file = None

    # 7. Create Embed
    embed = discord.Embed(
      title=f"{self.bot.user.name}'s Latency",
      color=self.color
    )
    
    # Description formatting
    db_str = f"{db_latency}ms" if isinstance(db_latency, (int, float)) else str(db_latency)
    lava_str = f"{lavalink_latency}ms" if isinstance(lavalink_latency, (int, float)) else str(lavalink_latency)
    
    desc = (
      f"{emojis.RED_DOT} **Websocket :** `{websocket_latency}ms`\n"
      f"{emojis.RED_DOT} **Database :** `{db_str}`\n"
      f"{emojis.RED_DOT} **Lavalink :** `{lava_str}`\n"
      f"{emojis.RED_DOT} **Response :** `{response_time}ms`"
    )
    embed.description = desc
    
    if file:
      embed.set_image(url="attachment://ping.png")
      
    embed.set_footer(
      text=f"requested by {ctx.author.name}",
      icon_url=ctx.author.display_avatar.url
    )
    embed.timestamp = discord.utils.utcnow()
    
    if file:
      await msg.edit(content=None, view=embed_to_view(embed), attachments=[file])
    else:
      await msg.edit(content=None, view=embed_to_view(embed))
    
    
    



  
  @commands.command(name="permissions", aliases= ["perms"],
                           help="Check and list the key permissions of a specific user",
                           usage="perms <user>",
                           with_app_command=True)
  @blacklist_check()
  @ignore_check()
  @commands.cooldown(1, 3, commands.BucketType.user)
  async def keyperms(self, ctx, member: discord.Member):
    key_permissions = []

    if member.guild_permissions.create_instant_invite:
      key_permissions.append("Create Instant Invite")
    if member.guild_permissions.kick_members:
      key_permissions.append("Kick Members")
    if member.guild_permissions.ban_members:
      key_permissions.append("Ban Members")
    if member.guild_permissions.administrator:
      key_permissions.append("Administrator")
    if member.guild_permissions.manage_channels:
      key_permissions.append("Manage Channels")
    if member.guild_permissions.manage_messages:
      key_permissions.append("Manage Messages")
    if member.guild_permissions.mention_everyone:
      key_permissions.append("Mention Everyone")
    if member.guild_permissions.manage_nicknames:
      key_permissions.append("Manage Nicknames")
    if member.guild_permissions.manage_roles:
      key_permissions.append("Manage Roles")
    if member.guild_permissions.manage_webhooks:
      key_permissions.append("Manage Webhooks")
    if member.guild_permissions.manage_emojis:
      key_permissions.append("Manage Emojis")
    if member.guild_permissions.manage_guild:
      key_permissions.append("Manage Server")
    if member.guild_permissions.manage_permissions:
      key_permissions.append("Manage Permissions")
    if member.guild_permissions.manage_threads:
      key_permissions.append("Manage Threads")
    if member.guild_permissions.moderate_members:
      key_permissions.append("Moderate Members")
    if member.guild_permissions.move_members:
      key_permissions.append("Move Members")
    if member.guild_permissions.mute_members:
      key_permissions.append("Mute Members (VC)")
    if member.guild_permissions.deafen_members:
      key_permissions.append("Deafen Members")
    if member.guild_permissions.priority_speaker:
      key_permissions.append("Priority Speaker")
    if member.guild_permissions.stream:
      key_permissions.append("Stream")
    
    
    

    permissions_list = ", ".join(key_permissions) if key_permissions else "None"

    embed = discord.Embed(title=f"Key Permissions of {member}",
                          color=0x000000)
    embed.add_field(name="__**Key Permissions**__", value=permissions_list, inline=False)

    await ctx.reply(view = embed_to_view(embed))

  




  @commands.hybrid_command(name="report",
                           aliases=["bug"],
                           usage='Report <bug>',
                           description='Report a bug to the Development team.',
                           help='Report a bug to the Development team.',
                           with_app_command=True)
  @blacklist_check()
  @ignore_check()
  @commands.cooldown(1, 30, commands.BucketType.channel)
  async def report(self, ctx, *, bug):
    channel = self.bot.get_channel(1373962059460382810)
    embed = discord.Embed(title='Bug Reported',
                          description=bug,
                          color=0x000000)
    embed.add_field(name='Reported By',
                    value=f'{ctx.author.name}',
                    inline=True)
    embed.add_field(name="Server", value=ctx.guild.name, inline=False)
    embed.add_field(name="Channel", value=ctx.channel.name, inline=False)
    await channel.send(view = embed_to_view(embed))
    confirm_embed = discord.Embed(title=f"{emojis.TICK} Bug Reported",
      description="Thank you for reporting the bug. We will look into it.",
      color=0x000000)
    await ctx.reply(view = embed_to_view(confirm_embed))
