from utils import emojis
from utils.database import get_collection
import json
import discord
from discord.ext import commands
from discord import app_commands
from discord.ui import View, Button
import asyncio
import io
import re
from datetime import datetime
from utils.Tools import is_moderation_staff, blacklist_check, ignore_check
import chat_exporter
from utils.cv2_compat import embed_to_view, embeds_to_view

EMOJI_DOT = f"{emojis.BLUEDOT}"

class TicketView(discord.ui.View):
    def __init__(self, creator_id: int, channel_id: int, bot: commands.Bot, claimed_by: int = None):
        super().__init__(timeout=None)
        self.creator_id = creator_id
        self.channel_id = channel_id
        self.bot = bot
        self.claimed_by = claimed_by

        lock_btn = discord.ui.Button(label="Lock", emoji="🔒", style=discord.ButtonStyle.primary, custom_id=f"ticket_lock_{channel_id}", row=0)
        lock_btn.callback = self.lock
        self.add_item(lock_btn)

        unlock_btn = discord.ui.Button(label="Unlock", emoji="🔓", style=discord.ButtonStyle.secondary, custom_id=f"ticket_unlock_{channel_id}", row=0)
        unlock_btn.callback = self.unlock
        self.add_item(unlock_btn)

        claim_btn = discord.ui.Button(label="Claim", emoji="✅", style=discord.ButtonStyle.success, custom_id=f"ticket_claim_{channel_id}", row=0)
        claim_btn.callback = self.claim
        self.add_item(claim_btn)

        delete_btn = discord.ui.Button(label="Delete", emoji="🗑️", style=discord.ButtonStyle.danger, custom_id=f"ticket_delete_{channel_id}", row=1)
        delete_btn.callback = self.delete_channel
        self.add_item(delete_btn)

        dt_btn = discord.ui.Button(label="Delete & Transcript", emoji="📝", style=discord.ButtonStyle.danger, custom_id=f"ticket_dt_{channel_id}", row=1)
        dt_btn.callback = self.delete_transcript
        self.add_item(dt_btn)

    async def check_perms(self, interaction: discord.Interaction):
        if interaction.user.id != self.creator_id and not (
            isinstance(interaction.user, discord.Member) and is_moderation_staff(interaction.user)
        ):
            await interaction.response.send_message("Only the ticket creator or staff can perform this action.", ephemeral=True)
            return False
        return True

    async def lock(self, interaction: discord.Interaction):
        if not await self.check_perms(interaction): return
        creator = interaction.guild.get_member(self.creator_id)
        if creator:
            overwrites = interaction.channel.overwrites_for(creator)
            overwrites.send_messages = False
            await interaction.channel.set_permissions(creator, overwrite=overwrites)
        await interaction.response.send_message("Ticket locked.", ephemeral=True)

    async def unlock(self, interaction: discord.Interaction):
        if not await self.check_perms(interaction): return
        creator = interaction.guild.get_member(self.creator_id)
        if creator:
            overwrites = interaction.channel.overwrites_for(creator)
            overwrites.send_messages = True
            await interaction.channel.set_permissions(creator, overwrite=overwrites)
        await interaction.response.send_message("Ticket unlocked.", ephemeral=True)

    async def claim(self, interaction: discord.Interaction):
        if not isinstance(interaction.user, discord.Member) or not is_moderation_staff(interaction.user):
            return await interaction.response.send_message("Only ticket staff can claim tickets.", ephemeral=True)
        if self.claimed_by is not None:
            return await interaction.response.send_message("This ticket is already claimed.", ephemeral=True)
            
        self.claimed_by = interaction.user.id
        col = await get_collection('tickets')
        await col.update_one({'channel_id': self.channel_id}, {'$set': {'claimed_by': self.claimed_by}}, upsert=True)
        await interaction.channel.send(f"{interaction.user.mention} has claimed this ticket.")
        await interaction.response.defer()

    async def delete_channel(self, interaction: discord.Interaction):
        if not await self.check_perms(interaction): return
        if not interaction.guild.me.guild_permissions.manage_channels:
            return await interaction.response.send_message("I need Manage Channels to delete this ticket.", ephemeral=True)
        col = await get_collection('tickets')
        await col.delete_one({'channel_id': self.channel_id})
        
        await interaction.response.send_message("Deleting ticket channel...", ephemeral=True)
        await interaction.channel.delete(reason=f"Ticket closed by {interaction.user}")

    async def delete_transcript(self, interaction: discord.Interaction):
        if not await self.check_perms(interaction): return
        if not interaction.guild.me.guild_permissions.manage_channels:
            return await interaction.response.send_message("I need Manage Channels to delete this ticket.", ephemeral=True)

        await interaction.response.defer(ephemeral=True)
        
        transcript = await chat_exporter.export(interaction.channel)
        if transcript:
            transcript_file = discord.File(
                io.BytesIO(transcript.encode('utf-8')),
                filename=f"transcript-{interaction.channel.name}.html"
            )
            try:
                await interaction.user.send("Here is the ticket transcript:", file=transcript_file)
            except discord.Forbidden:
                await interaction.followup.send("I could not DM you the transcript, please enable DMs.")
                return
        col = await get_collection('tickets')
        await col.delete_one({'channel_id': self.channel_id})
        
        await interaction.channel.delete(reason=f"Ticket closed (with transcript) by {interaction.user}")


class PanelView(discord.ui.View):
    def __init__(self, bot: commands.Bot, guild_id: int, message_id: int, panel_type: str, options: list):
        super().__init__(timeout=None)
        self.bot = bot
        self.guild_id = guild_id
        self.message_id = message_id
        self.panel_type = panel_type
        self.options = options

        if panel_type == "dropdown":
            select = discord.ui.Select(
                custom_id=f"ticket_panel_{message_id}",
                placeholder="Select a ticket type",
                options=[discord.SelectOption(label=opt["label"], value=opt["label"], emoji=opt.get("emoji")) for opt in options]
            )
            select.callback = self.ticket_callback
            self.add_item(select)
        else:
            for opt in options:
                btn = Button(
                    label=opt["label"], 
                    emoji=opt.get("emoji"), 
                    custom_id=f"ticket_panel_{message_id}_{opt['label']}", 
                    style=discord.ButtonStyle.primary
                )
                btn.callback = self.ticket_callback
                self.add_item(btn)

    async def ticket_callback(self, i: discord.Interaction):
        selected_label = i.data.get("values", [None])[0] if self.panel_type == "dropdown" else i.data["custom_id"].split("_")[-1]
        option = next((opt for opt in self.options if opt["label"] == selected_label), None)

        if option is None:
            return await i.response.send_message("Option not found.", ephemeral=True)

        staff_r = i.guild.get_role(option["staff_role"])
        if staff_r is None:
            return await i.response.send_message("Ticket staff role is missing. Ask an admin to recreate this panel.", ephemeral=True)
        
        me = i.guild.me
        if not me.guild_permissions.manage_channels:
            return await i.response.send_message("I need Manage Channels to create tickets.", ephemeral=True)
        col = await get_collection('tickets')
        ticket_count = await col.count_documents({'guild_id': i.guild.id}) + 1
        
        overwrites = {
            i.guild.default_role: discord.PermissionOverwrite(view_channel=False),
            i.user: discord.PermissionOverwrite(view_channel=True, send_messages=True, read_message_history=True),
            staff_r: discord.PermissionOverwrite(view_channel=True, send_messages=True, read_message_history=True)
        }

        safe_label = "".join(ch for ch in selected_label.lower() if ch.isalnum() or ch in "-_")[:30] or "ticket"
        try:
            ticket_channel = await i.guild.create_text_channel(
                name=f"{safe_label}-{ticket_count}",
                overwrites=overwrites,
                reason=f"New support ticket by {i.user} ({i.user.id})"
            )
        except Exception as e:
            return await i.response.send_message("Failed to create ticket channel. Make sure I have correct permissions.", ephemeral=True)
        await col.insert_one({'guild_id': i.guild.id, 'channel_id': ticket_channel.id, 'creator_id': i.user.id, 'claimed_by': None})

        ticket_embed = discord.Embed(
            title=ticket_channel.name,
            description=f"{i.user.mention} has created a ticket under **{selected_label}** category.",
            color=0x5865F2,
            timestamp=discord.utils.utcnow()
        )

        ticket_view = TicketView(i.user.id, ticket_channel.id, self.bot)
        await ticket_channel.send(view=embed_to_view(ticket_embed, view=ticket_view, content=f"{i.user.mention} {staff_r.mention}"))
        await i.response.send_message(f"Ticket created: {ticket_channel.mention}", ephemeral=True)


class TicketSystem(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    async def cog_load(self):
        panel_col = await get_collection('ticket_panels')
        ticket_col = await get_collection('tickets')
        
        # Reload persistent panels
        panels = await panel_col.find({}).to_list(length=None)
        panels = [(p.get('guild_id'), p.get('message_id'), p.get('panel_type'), p.get('options_json')) for p in panels]
        for guild_id, message_id, panel_type, options_json in panels:
            options = json.loads(options_json)
            self.bot.add_view(PanelView(self.bot, guild_id, message_id, panel_type, options))
        # Reload persistent tickets
        tickets = await ticket_col.find({}).to_list(length=None)
        tickets = [(t.get('channel_id'), t.get('creator_id'), t.get('claimed_by')) for t in tickets]
        for channel_id, creator_id, claimed_by in tickets:
            self.bot.add_view(TicketView(creator_id, channel_id, self.bot, claimed_by))
            # Optional: if you also want CloseOptionsView to be persistent if the bot restarts while it's pending:
            # We can't perfectly reconstruct CloseOptionsView without channel obj, but since we have channel_id
            # we can fetch it dynamically or just rely on the UI being ephemeral.
            # Usually CloseOptionsView is ephemeral so it doesn't need persistence!

    @commands.hybrid_command(name="tickets", description="List all open tickets in this server")
    @commands.has_permissions(manage_channels=True)
    async def list_tickets(self, ctx: commands.Context):
        col = await get_collection('tickets')
        rows = await col.find({'guild_id': ctx.guild.id}).to_list(length=None)
        rows = [(r.get('channel_id'), r.get('creator_id'), r.get('claimed_by')) for r in rows]
        
        if not rows:
            return await ctx.send("There are no open tickets in this server.", ephemeral=True)
            
        embed = discord.Embed(title="Open Tickets", color=discord.Color.blue())
        for idx, row in enumerate(rows[:25], 1):
            channel_id, creator_id, claimed_by = row
            channel = ctx.guild.get_channel(channel_id)
            creator = ctx.guild.get_member(creator_id)
            claimer = ctx.guild.get_member(claimed_by) if claimed_by else None
            
            chan_str = channel.mention if channel else f"Unknown ({channel_id})"
            creator_str = creator.mention if creator else f"Unknown ({creator_id})"
            claim_str = f"\nClaimed by: {claimer.mention}" if claimer else ""
            
            embed.add_field(name=f"{idx}. {channel.name if channel else 'Ticket'}", value=f"Channel: {chan_str}\nCreator: {creator_str}{claim_str}", inline=False)
            
        await ctx.send(embed=embed, ephemeral=True)


    @commands.hybrid_command(name="ticketsetup", aliases=["ticket"], description="Create and send a custom ticket panel")
    @blacklist_check()
    @ignore_check()
    @commands.cooldown(1, 7, commands.BucketType.user)
    @commands.has_permissions(manage_channels=True)
    async def ticketsetup(self, ctx: commands.Context, panel_type: str = None):
        if not isinstance(ctx.author, discord.Member) or not (
            ctx.author.guild_permissions.administrator
            or ctx.author.guild_permissions.manage_guild
            or ctx.author.guild_permissions.manage_channels
        ):
            return await ctx.send("You need Manage Server or Manage Channels to create ticket panels.", ephemeral=True)
        
        if panel_type is None:
            class PanelTypeView(discord.ui.View):
                def __init__(self):
                    super().__init__(timeout=60)
                    self.value = None

                @discord.ui.button(label="Buttons", style=discord.ButtonStyle.primary)
                async def btn_buttons(self, interaction: discord.Interaction, button: discord.ui.Button):
                    if interaction.user.id != ctx.author.id:
                        return await interaction.response.send_message("This isn't your command.", ephemeral=True)
                    self.value = "buttons"
                    await interaction.response.defer()
                    self.stop()

                @discord.ui.button(label="Dropdown", style=discord.ButtonStyle.primary)
                async def btn_dropdown(self, interaction: discord.Interaction, button: discord.ui.Button):
                    if interaction.user.id != ctx.author.id:
                        return await interaction.response.send_message("This isn't your command.", ephemeral=True)
                    self.value = "dropdown"
                    await interaction.response.defer()
                    self.stop()

            view = PanelTypeView()
            prompt_msg = await ctx.send("Select the type of ticket panel you want to create:", view=view)
            await view.wait()
            
            if view.value is None:
                return await prompt_msg.edit(content="Ticket setup timed out.", view=None)
            
            panel_type = view.value
            await prompt_msg.delete()

        panel_type = panel_type.lower()
        if panel_type not in ["buttons", "dropdown"]:
            return await ctx.send("Usage: `!ticketsetup <buttons | dropdown>`\nExample: `!ticketsetup dropdown`", ephemeral=True)

        embed = discord.Embed(
            title="Ticket Setup Builder!", 
            description="Use the buttons below to build your ticket panel layout.\n\nMust edit title & description to remove these instructions.", 
            color=0x2B2D31
        )
        interaction_user = ctx.author
        options_list = []

        def chk(m):
            return m.channel.id == ctx.channel.id and m.author.id == ctx.author.id and not m.author.bot

        msg = None

        def get_edit_view():
            view = View(timeout=900)
            for btn in edit_buttons:
                view.add_item(btn)
            view.add_item(next_button)
            view.add_item(cancel_button)
            return view

        def get_options_view():
            view = View(timeout=900)
            view.add_item(add_opt_btn)
            view.add_item(clear_opt_btn)
            view.add_item(finish_btn)
            view.add_item(cancel_button)
            return view

        async def select_callback(interaction, value):
            if interaction.user.id != interaction_user.id:
                return await interaction.response.send_message("Uh oh! That message doesn't belong to you.", ephemeral=True)

            await interaction.response.defer()

            if value == "Title":
                await ctx.send("Please enter the **Title of the ticket panel**:")
                try:
                    tit = await ctx.bot.wait_for("message", timeout=60, check=chk)
                    embed.title = tit.content
                    await msg.edit(view=embed_to_view(embed, view=get_edit_view()))
                except asyncio.TimeoutError:
                    await ctx.send("Timed Out")
            elif value == "Description":
                await ctx.send("Please enter the **Description of the ticket panel**:")
                try:
                    desc = await ctx.bot.wait_for("message", timeout=60, check=chk)
                    embed.description = desc.content
                    await msg.edit(view=embed_to_view(embed, view=get_edit_view()))
                except asyncio.TimeoutError:
                    await ctx.send("Timed Out")
            elif value == "Color":
                await ctx.send("Please enter the color as a hexadecimal value (e.g., #FF0000 for red):")
                try:
                    col = await ctx.bot.wait_for("message", timeout=60, check=chk)
                    color = discord.Colour(int(col.content.strip("#"), 16))
                    embed._colour = color
                    await msg.edit(view=embed_to_view(embed, view=get_edit_view()))
                except ValueError:
                    await ctx.send("Invalid color format. Please retry.")
                except asyncio.TimeoutError:
                    await ctx.send("Timed Out")
            elif value == "Thumbnail":
                await ctx.send("Please enter the **URL of the thumbnail:**")
                try:
                    thumb = await ctx.bot.wait_for("message", timeout=60, check=chk)
                    embed.set_thumbnail(url=thumb.content)
                    await msg.edit(view=embed_to_view(embed, view=get_edit_view()))
                except asyncio.TimeoutError:
                    await ctx.send("Timed Out")
            elif value == "Image":
                await ctx.send("Please enter the **URL of the image:**")
                try:
                    img = await ctx.bot.wait_for("message", timeout=60, check=chk)
                    embed.set_image(url=img.content)
                    await msg.edit(view=embed_to_view(embed, view=get_edit_view()))
                except asyncio.TimeoutError:
                    await ctx.send("Timed Out")
            elif value == "Footer Text":
                await ctx.send("Please enter the **text of the footer:**")
                try:
                    foot = await ctx.bot.wait_for("message", timeout=60, check=chk)
                    embed.set_footer(text=foot.content, icon_url=embed.footer.icon_url)
                    await msg.edit(view=embed_to_view(embed, view=get_edit_view()))
                except asyncio.TimeoutError:
                    await ctx.send("Timed Out")
            elif value == "Footer Icon":
                await ctx.send("Please enter the **URL of the footer icon:**")
                try:
                    foot_icon = await ctx.bot.wait_for("message", timeout=60, check=chk)
                    embed.set_footer(text=embed.footer.text, icon_url=foot_icon.content)
                    await msg.edit(view=embed_to_view(embed, view=get_edit_view()))
                except asyncio.TimeoutError:
                    await ctx.send("Timed Out")
            elif value == "Author Text":
                await ctx.send("Please enter the **author text:**")
                try:
                    auth_text = await ctx.bot.wait_for("message", timeout=60, check=chk)
                    embed.set_author(name=auth_text.content, icon_url=embed.author.icon_url)
                    await msg.edit(view=embed_to_view(embed, view=get_edit_view()))
                except asyncio.TimeoutError:
                    await ctx.send("Timed Out")
            elif value == "Author Icon":
                await ctx.send("Please enter the **URL of the author icon:**")
                try:
                    auth_icon = await ctx.bot.wait_for("message", timeout=60, check=chk)
                    embed.set_author(name=embed.author.name, icon_url=auth_icon.content)
                    await msg.edit(view=embed_to_view(embed, view=get_edit_view()))
                except asyncio.TimeoutError:
                    await ctx.send("Timed Out")

        options_buttons = ["Title", "Description", "Color", "Thumbnail", "Image", "Footer Text", "Footer Icon", "Author Text", "Author Icon"]
        edit_buttons = []
        for opt in options_buttons:
            btn = Button(label=opt, style=discord.ButtonStyle.primary)
            def make_callback(val):
                async def cb(interaction):
                    await select_callback(interaction, val)
                return cb
            btn.callback = make_callback(opt)
            edit_buttons.append(btn)

        async def cancel_callback(interaction):
            if interaction.user.id != interaction_user.id:
                return await interaction.response.send_message("Uh oh! That message doesn't belong to you.", ephemeral=True)
            await interaction.response.defer()
            await msg.delete()

        async def next_callback(interaction):
            if interaction.user.id != interaction_user.id:
                return await interaction.response.send_message("Uh oh! That message doesn't belong to you.", ephemeral=True)
            await interaction.response.defer()
            embed.set_footer(text=f"Total options: {len(options_list)}/6")
            await msg.edit(view=embed_to_view(embed, view=get_options_view()))

        async def add_opt_callback(interaction):
            if interaction.user.id != interaction_user.id:
                return await interaction.response.send_message("Uh oh! That message doesn't belong to you.", ephemeral=True)
            if len(options_list) >= 6:
                return await interaction.response.send_message("You can only have up to 6 options.", ephemeral=True)
            await interaction.response.defer()

            await ctx.send("Please enter the **Option Label** (e.g. Support, Giveaways):")
            try:
                label_msg = await ctx.bot.wait_for("message", timeout=60, check=chk)
                label = label_msg.content[:80]

                await ctx.send("Please enter the **Emoji** (e.g. 🎫 or an emoji ID):")
                emoji_msg = await ctx.bot.wait_for("message", timeout=60, check=chk)
                
                emoji = emoji_msg.content

                await ctx.send("Please enter the **Staff Role ID** to ping when this ticket is created:")
                role_msg = await ctx.bot.wait_for("message", timeout=60, check=chk)
                
                try:
                    staff_role_id = int(role_msg.content.strip())
                except ValueError:
                    return await ctx.send("Invalid Role ID. Option creation cancelled.")

                options_list.append({
                    "label": label,
                    "emoji": emoji,
                    "staff_role": staff_role_id
                })

                embed.set_footer(text=f"Added option: {label} | Total options: {len(options_list)}/6")
                await msg.edit(view=embed_to_view(embed, view=get_options_view()))
                await ctx.send("Option added successfully!")
            except asyncio.TimeoutError:
                await ctx.send("Timed Out")

        async def clear_opt_callback(interaction):
            if interaction.user.id != interaction_user.id:
                return await interaction.response.send_message("Uh oh! That message doesn't belong to you.", ephemeral=True)
            await interaction.response.defer()
            options_list.clear()
            embed.set_footer(text="Options cleared. Total options: 0/6")
            await msg.edit(view=embed_to_view(embed, view=get_options_view()))

        async def finish_callback(interaction):
            if interaction.user.id != interaction_user.id:
                return await interaction.response.send_message("Uh oh! That message doesn't belong to you.", ephemeral=True)
            if not options_list:
                return await interaction.response.send_message("Please add at least one ticket option first.", ephemeral=True)
            await interaction.response.defer()

            await ctx.send("Please mention the **channel** where you want to send this ticket panel:")
            try:
                chnl_msg = await ctx.bot.wait_for("message", timeout=60, check=chk)
                if not chnl_msg.channel_mentions:
                    return await ctx.send("No channel mentioned. Setup cancelled.")
                chnl = chnl_msg.channel_mentions[0]

                # Send a temporary placeholder to get the message_id for the database
                embed.remove_footer()
                panel_msg = await chnl.send(view=embed_to_view(embed))

                # Initialize the panel view with custom_ids tied to the message_id
                final_view = PanelView(self.bot, interaction.guild.id, panel_msg.id, panel_type, options_list)
                await panel_msg.edit(view=embed_to_view(embed, view=final_view))
                # Save to database
                col = await get_collection('ticket_panels')
                await col.insert_one({'guild_id': interaction.guild.id, 'channel_id': chnl.id, 'message_id': panel_msg.id, 'panel_type': panel_type, 'options_json': json.dumps(options_list)})
                
                self.bot.add_view(final_view)

                success_embed = discord.Embed(title=f"{emojis.TICK} Success", description=f"Sent the ticket panel to {chnl.mention}", color=0x000000)
                await ctx.send(view=embed_to_view(success_embed))
            except asyncio.TimeoutError:
                await ctx.send("Timed Out")

        cancel_button = Button(label="Cancel Setup", emoji=f"{emojis.CROSSICON}", style=discord.ButtonStyle.danger)
        cancel_button.callback = cancel_callback

        next_button = Button(label="Next Step ➡", style=discord.ButtonStyle.success)
        next_button.callback = next_callback

        add_opt_btn = Button(label="➕ Add Option", style=discord.ButtonStyle.primary)
        add_opt_btn.callback = add_opt_callback

        clear_opt_btn = Button(label="🗑️ Clear Options", style=discord.ButtonStyle.danger)
        clear_opt_btn.callback = clear_opt_callback

        finish_btn = Button(label="✅ Finish Setup", emoji=f"{emojis.TICK}", style=discord.ButtonStyle.success)
        finish_btn.callback = finish_callback

        msg = await ctx.send(view=embed_to_view(embed, view=get_edit_view()))

async def setup(bot):
    await bot.add_cog(TicketSystem(bot))
