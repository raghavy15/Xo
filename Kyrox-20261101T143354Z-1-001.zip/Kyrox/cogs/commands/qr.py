import discord
from discord.ext import commands
from utils.cv2_compat import embed_to_view, embeds_to_view

class QR(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command(
        name="qr",
        aliases=["qrcode"],
        help="Sends a QR code image.",
        with_app_command=True
    )
    @commands.has_permissions(administrator=True)
    @commands.cooldown(1, 5, commands.BucketType.user)
    async def qr(self, ctx):
        embed = discord.Embed(
            title="Payment Platform",
            description="Here's you can pay UPI With Below QR",
            color=discord.Color.blurple()
        )
        embed.set_image(url="https://cdn.discordapp.com/attachments/1511760488994832558/1514637147343163532/image.png?ex=6a5a3bc4&is=6a58ea44&hm=7cfed3841a8798967681c342a05e4f10e9be27c91093dbdea903a788efbef9bc&animated=true&py")
        await ctx.reply(view = embed_to_view(embed))

    @qr.error
    async def qr_error(self, ctx, error):
        if isinstance(error, commands.MissingPermissions):
            await ctx.reply("❌ You must be an **administrator** to use this command.")
        elif isinstance(error, commands.CommandOnCooldown):
            await ctx.reply(f"⏳ You're on cooldown. Try again in `{round(error.retry_after, 1)}s`.")
        else:
            await ctx.reply(f"⚠️ An error occurred: `{str(error)}`")

# Required for bot.load_extension()
async def setup(bot):
    await bot.add_cog(QR(bot))
