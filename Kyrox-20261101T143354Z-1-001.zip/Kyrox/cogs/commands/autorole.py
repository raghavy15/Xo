from __future__ import annotations
from utils import emojis
from utils.components_v2 import success_panel, error_panel, info_panel

import asyncio
import discord
import logging
from discord.ext import commands
from typing import List, Dict
from utils.Tools import *
from utils.config import OWNER_IDS

from utils.database import get_collection

class BasicView(discord.ui.View):
    def __init__(self, ctx: commands.Context, timeout=60):
        super().__init__(timeout=timeout)
        self.ctx = ctx

    async def interaction_check(self, interaction: discord.Interaction):
        if interaction.user.id != self.ctx.author.id and interaction.user.id not in OWNER_IDS:
            await interaction.response.send_message("Uh oh! That message doesn't belong to you.\nYou must run this command to interact with it.", ephemeral=True)
            return False
        return True


class AutoRole(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.color = 0x000000

    async def cog_load(self) -> None:
        pass

    async def get_autorole(self, guild_id: int) -> Dict[str, List[int]]:
        col = await get_collection('autorole')
        data = await col.find_one({'guild_id': guild_id})
        if data:
            return {'bots': data.get('bots', []), 'humans': data.get('humans', [])}
        return {'bots': [], 'humans': []}

    @commands.group(name="autorole", invoke_without_command=True)
    @commands.cooldown(1, 5, commands.BucketType.user)
    @commands.max_concurrency(1, per=commands.BucketType.default, wait=False)
    @commands.guild_only()
    @commands.has_permissions(administrator=True)
    async def _autorole(self, ctx):
        if ctx.subcommand_passed is None:
            await ctx.send_help(ctx.command)
            ctx.command.reset_cooldown(ctx)

    @_autorole.command(name="config", help="Shows the current autorole configuration")
    @commands.cooldown(1, 5, commands.BucketType.user)
    @commands.max_concurrency(1, per=commands.BucketType.default, wait=False)
    @commands.guild_only()
    @blacklist_check()
    @ignore_check()
    @commands.has_permissions(administrator=True)
    async def _ar_config(self, ctx):
        data = await self.get_autorole(ctx.guild.id)
        if data and (data['humans'] or data['bots']):
            fetched_humans = [ctx.guild.get_role(role_id) for role_id in data["humans"] if ctx.guild.get_role(role_id)]
            fetched_bots = [ctx.guild.get_role(role_id) for role_id in data["bots"] if ctx.guild.get_role(role_id)]

            hums = "\n".join(role.mention for role in fetched_humans) or "None"
            bos = "\n".join(role.mention for role in fetched_bots) or "None"

            await ctx.send(view=info_panel(
                "",
                title=f"Autorole Configuration for {ctx.guild.name}",
                fields=[(" __Humans__", hums), (" __Bots__", bos)]
            ))
        else:
            await ctx.reply(view=info_panel("No autorole configuration found in this Guild."))

    @_autorole.group(name="reset", help="Clear autorole config in the Guild")
    @commands.max_concurrency(1, per=commands.BucketType.default, wait=False)
    @commands.guild_only()
    @blacklist_check()
    @ignore_check()
    @commands.has_permissions(administrator=True)
    async def _autorole_reset(self, ctx):
        if ctx.subcommand_passed is None:
            await ctx.send_help(ctx.command)
            ctx.command.reset_cooldown(ctx)

    @_autorole_reset.command(name="humans", help="Clear autorole configuration for humans")
    @commands.cooldown(1, 3, commands.BucketType.user)
    @commands.max_concurrency(1, per=commands.BucketType.default, wait=False)
    @commands.guild_only()
    @blacklist_check()
    @ignore_check()
    @commands.has_permissions(administrator=True)
    async def _autorole_humans_reset(self, ctx):
        col = await get_collection('autorole')
        data = await col.find_one({'guild_id': ctx.guild.id})
        if data and data.get('humans'):
            await col.update_one({'guild_id': ctx.guild.id}, {'$set': {'humans': []}})
            await ctx.reply(view=success_panel(
                "Cleared all human autoroles in this Guild.",
                title=f"{emojis.TICK} Success"
            ))
        else:
            await ctx.reply(view=error_panel(
                "No Autoroles set for humans in this Guild.",
                title=f"{emojis.CROSSICON} Error"
            ))

    @_autorole_reset.command(name="bots", help="Clear autorole configuration for bots")
    @commands.cooldown(1, 3, commands.BucketType.user)
    @commands.max_concurrency(1, per=commands.BucketType.default, wait=False)
    @commands.guild_only()
    @blacklist_check()
    @ignore_check()
    @commands.has_permissions(administrator=True)
    async def _autorole_bots_reset(self, ctx):
        col = await get_collection('autorole')
        data = await col.find_one({'guild_id': ctx.guild.id})
        if data and data.get('bots'):
            await col.update_one({'guild_id': ctx.guild.id}, {'$set': {'bots': []}})
            await ctx.reply(view=success_panel(
                "Cleared all bot autoroles in this Guild.",
                title=f"{emojis.TICK} Success"
            ))
        else:
            await ctx.reply(view=error_panel(
                "No Autoroles set for Bots in this Guild.",
                title=f"{emojis.CROSSICON} Error"
            ))

    @_autorole_reset.command(name="all", help="Clear all autorole configuration in the Guild")
    @blacklist_check()
    @ignore_check()
    @commands.cooldown(1, 3, commands.BucketType.user)
    @commands.max_concurrency(1, per=commands.BucketType.default, wait=False)
    @commands.guild_only()
    @commands.has_permissions(administrator=True)
    async def _autorole_reset_all(self, ctx):
        col = await get_collection('autorole')
        data = await col.find_one({'guild_id': ctx.guild.id})
        if data and (data.get('humans') or data.get('bots')):
            await col.update_one({'guild_id': ctx.guild.id}, {'$set': {'humans': [], 'bots': []}})
            await ctx.reply(view=success_panel(
                "Cleared all autoroles in this Guild.",
                title=f"{emojis.TICK} Success"
            ))
        else:
            await ctx.reply(view=error_panel(
                "No Autoroles set in this Guild.",
                title=f"{emojis.CROSSICON} Error"
            ))

    @_autorole.group(name="humans", help="Setup autoroles for human")
    @blacklist_check()
    @ignore_check()
    @commands.max_concurrency(1, per=commands.BucketType.default, wait=False)
    @commands.guild_only()
    @commands.has_permissions(administrator=True)
    async def _autorole_humans(self, ctx):
        if ctx.subcommand_passed is None:
            await ctx.send_help(ctx.command)
            ctx.command.reset_cooldown(ctx)

    @_autorole_humans.command(name="add", help="Add role to list of human Autoroles.")
    @blacklist_check()
    @ignore_check()
    @commands.cooldown(1, 3, commands.BucketType.user)
    @commands.max_concurrency(1, per=commands.BucketType.default, wait=False)
    @commands.guild_only()
    @commands.has_permissions(administrator=True)
    async def _autorole_humans_add(self, ctx, *, role: discord.Role):
        col = await get_collection('autorole')
        data = await col.find_one({'guild_id': ctx.guild.id})
        
        humans = data.get('humans', []) if data else []
        
        if role.id in humans:
            await ctx.reply(view=error_panel(
                f"{role.mention} is already in human autoroles.",
                title=f"{emojis.ICONS_WARNING} Access Denied"
            ))
        elif len(humans) >= 10:
            await ctx.reply(view=error_panel(
                "You can only add upto 10 human autoroles.",
                title=f"{emojis.ICONS_WARNING} Access Denied"
            ))
        else:
            humans.append(role.id)
            await col.update_one({'guild_id': ctx.guild.id}, {'$set': {'humans': humans}}, upsert=True)
            await ctx.reply(view=success_panel(
                f"{role.mention} has been added to human autoroles.",
                title=f"{emojis.TICK} Success"
            ))

    @_autorole_humans.command(name="remove", help="Remove a role from human Autoroles.")
    @blacklist_check()
    @ignore_check()
    @commands.cooldown(1, 3, commands.BucketType.user)
    @commands.max_concurrency(1, per=commands.BucketType.default, wait=False)
    @commands.guild_only()
    @commands.has_permissions(administrator=True)
    async def _autorole_humans_remove(self, ctx, *, role: discord.Role):
        col = await get_collection('autorole')
        data = await col.find_one({'guild_id': ctx.guild.id})
        humans = data.get('humans', []) if data else []

        if role.id not in humans:
            await ctx.reply(view=error_panel(
                f"{role.mention} is not in human autoroles.",
                title=f"{emojis.CROSSICON} Error"
            ))
        else:
            humans.remove(role.id)
            await col.update_one({'guild_id': ctx.guild.id}, {'$set': {'humans': humans}})
            await ctx.reply(view=success_panel(
                f"{role.mention} has been removed from human autoroles.",
                title=f"{emojis.TICK} Success"
            ))

    @_autorole.group(name="bots", help="Setup autoroles for bots")
    @blacklist_check()
    @ignore_check()
    @commands.max_concurrency(1, per=commands.BucketType.default, wait=False)
    @commands.guild_only()
    @commands.has_permissions(administrator=True)
    async def _autorole_bots(self, ctx):
        if ctx.subcommand_passed is None:
            await ctx.send_help(ctx.command)
            ctx.command.reset_cooldown(ctx)

    @_autorole_bots.command(name="add", help="Add role to bot Autoroles.")
    @blacklist_check()
    @ignore_check()
    @commands.cooldown(1, 3, commands.BucketType.user)
    @commands.max_concurrency(1, per=commands.BucketType.default, wait=False)
    @commands.guild_only()
    @commands.has_permissions(administrator=True)
    async def _autorole_bots_add(self, ctx, *, role: discord.Role):
        col = await get_collection('autorole')
        data = await col.find_one({'guild_id': ctx.guild.id})
        
        bots = data.get('bots', []) if data else []
        
        if role.id in bots:
            await ctx.reply(view=error_panel(
                f"{role.mention} is already in bot autoroles.",
                title=f"{emojis.ICONS_WARNING} Access Denied"
            ))
        elif len(bots) >= 10:
            await ctx.reply(view=error_panel(
                "You can only add upto 10 bot autoroles",
                title=f"{emojis.ICONS_WARNING} Access Denied"
            ))
        else:
            bots.append(role.id)
            await col.update_one({'guild_id': ctx.guild.id}, {'$set': {'bots': bots}}, upsert=True)
            await ctx.reply(view=success_panel(
                f"{role.mention} has been added to bot autoroles.",
                title=f"{emojis.TICK} Success"
            ))

    @_autorole_bots.command(name="remove", help="Remove a role from bot Autoroles.")
    @blacklist_check()
    @ignore_check()
    @commands.cooldown(1, 3, commands.BucketType.user)
    @commands.max_concurrency(1, per=commands.BucketType.default, wait=False)
    @commands.guild_only()
    @commands.has_permissions(administrator=True)
    async def _autorole_bots_remove(self, ctx, *, role: discord.Role):
        col = await get_collection('autorole')
        data = await col.find_one({'guild_id': ctx.guild.id})
        bots = data.get('bots', []) if data else []

        if role.id not in bots:
            await ctx.reply(view=error_panel(
                f"{role.mention} is not in bot autoroles.",
                title=f"{emojis.CROSSICON} Error"
            ))
        else:
            bots.remove(role.id)
            await col.update_one({'guild_id': ctx.guild.id}, {'$set': {'bots': bots}})
            await ctx.reply(view=success_panel(
                f"{role.mention} has been removed from bot autoroles.",
                title=f"{emojis.TICK} Success"
            ))

    @commands.Cog.listener()
    async def on_member_join(self, member):
        data = await self.get_autorole(member.guild.id)
        role_ids = data.get('bots', []) if member.bot else data.get('humans', [])
        
        if not role_ids:
            return
            
        roles_to_add = []
        for role_id in role_ids:
            role = member.guild.get_role(role_id)
            if role:
                roles_to_add.append(role)
                
        if roles_to_add:
            try:
                await member.add_roles(*roles_to_add, reason="Kyrox Autorole")
            except discord.Forbidden:
                pass
            except discord.HTTPException:
                pass

async def setup(bot):
    await bot.add_cog(AutoRole(bot))
