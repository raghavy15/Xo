import discord
from discord.ext import commands
from datetime import datetime

from utils.database import get_collection
from utils.cv2_compat import embed_to_view, embeds_to_view

LOG_CHANNELS = {
    "system-logs": "system",
    "join-logs": "join",
    "leave-logs": "leave",
    "member-logs": "member",
    "message-logs": "message",
    "thread-logs": "thread",
    "voice-logs": "voice",
    "stage-logs": "stage",
    "moderation-logs": "mod",
    "channel-logs": "channel",
    "server-logs": "server",
    "event-logs": "event",
    "webhook-logs": "webhook",
    "role-logs": "role",
    "application-logs": "application",
    "alert-logs": "alert"
}

class Logging(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    async def cog_load(self) -> None:
        pass

    async def cog_unload(self) -> None:
        pass

    async def set_log_channel(self, guild_id, log_type, channel_id):
        col = await get_collection('log_channels')
        await col.update_one(
            {'guild_id': guild_id, 'log_type': log_type},
            {'$set': {'channel_id': channel_id}},
            upsert=True
        )

    async def get_log_channel(self, guild_id, log_type):
        col = await get_collection('log_channels')
        result = await col.find_one({'guild_id': guild_id, 'log_type': log_type})
        return result['channel_id'] if result else None

    async def is_logging_enabled(self, guild_id):
        col = await get_collection('logging_config')
        result = await col.find_one({'guild_id': guild_id})
        return result.get('enabled', False) if result else False

    async def set_logging_enabled(self, guild_id, enabled: bool):
        col = await get_collection('logging_config')
        await col.update_one({'guild_id': guild_id}, {'$set': {'enabled': enabled}}, upsert=True)

    async def send_log(self, guild, log_type, embed):
        if not await self.is_logging_enabled(guild.id):
            return
        embed.timestamp = datetime.utcnow()
        channel_id = await self.get_log_channel(guild.id, log_type)
        if channel_id:
            channel = guild.get_channel(channel_id)
            if channel:
                try:
                    await channel.send(view=embed_to_view(embed), allowed_mentions=discord.AllowedMentions.none())
                except Exception:
                    pass

    @commands.group(invoke_without_command=True, name="logging", aliases=["log"])
    @commands.has_permissions(administrator=True)
    async def logging(self, ctx):
        """Advanced Logging Commands"""
        return await ctx.send_help(ctx.command)

    @logging.command(name="setup")
    @commands.has_permissions(administrator=True)
    async def logging_setup(self, ctx):
        """Creates Kyrox logging category and log channels with private permissions"""
        guild = ctx.guild

        msg = await ctx.send(embed=discord.Embed(description="⏳ Setting up logging channels, this may take a moment...", color=0x2b2d31))

        overwrites = {
            guild.default_role: discord.PermissionOverwrite(view_channel=False),
            guild.me: discord.PermissionOverwrite(view_channel=True, send_messages=True)
        }

        category = discord.utils.get(guild.categories, name="Server Logs")
        if not category:
            category = await guild.create_category("Server Logs", overwrites=overwrites)

        for name, log_type in LOG_CHANNELS.items():
            channel = discord.utils.get(guild.text_channels, name=name)
            if not channel:
                channel = await guild.create_text_channel(name=name, category=category, overwrites=overwrites)
            await self.set_log_channel(guild.id, log_type, channel.id)

        await self.set_logging_enabled(guild.id, True)

        embed = discord.Embed(
            title="Setup Complete",
            description=(
                f"**Successfully created and configured {len(LOG_CHANNELS)} logging channels.**\n\n"
                f"All channels are nested under the `{category.name}` category. They are set to private so only administrators and the bot can view them.\n\n"
                f"Logging has been automatically **enabled**."
            ),
            color=0x2b2d31
        )
        embed.set_author(name=ctx.author.name, icon_url=ctx.author.display_avatar.url)
        await msg.edit(embed=embed)

    @logging.command(name="enable")
    @commands.has_permissions(administrator=True)
    async def logging_enable(self, ctx):
        """Enables the logging system"""
        await self.set_logging_enabled(ctx.guild.id, True)
        embed = discord.Embed(title="Logging Enabled", description="The logging system has been activated.", color=discord.Color.green())
        await ctx.send(embed=embed)

    @logging.command(name="disable")
    @commands.has_permissions(administrator=True)
    async def logging_disable(self, ctx):
        """Disables the logging system without removing channels"""
        await self.set_logging_enabled(ctx.guild.id, False)
        embed = discord.Embed(title="Logging Disabled", description="The logging system has been paused. No new logs will be sent until it is enabled again.", color=discord.Color.red())
        await ctx.send(embed=embed)

    @logging.command(name="remove")
    @commands.has_permissions(administrator=True)
    async def logging_remove(self, ctx):
        """Removes Kyrox logging channels and logging DB config"""
        guild = ctx.guild
        msg = await ctx.send(embed=discord.Embed(description="⏳ Removing logging channels...", color=0x2b2d31))

        col = await get_collection('log_channels')
        await col.delete_many({'guild_id': guild.id})
        
        await self.set_logging_enabled(guild.id, False)

        category = discord.utils.get(guild.categories, name="Server Logs")
        if category:
            for channel in category.channels:
                await channel.delete()
            await category.delete()
            
        old_category = discord.utils.get(guild.categories, name="kyrox-logging")
        if old_category:
            for channel in old_category.channels:
                await channel.delete()
            await old_category.delete()

        embed = discord.Embed(
            title="Cleanup Complete",
            description="All logging channels and configurations have been successfully removed.",
            color=0x2b2d31
        )
        await msg.edit(embed=embed)

    @commands.Cog.listener()
    async def on_message_delete(self, message):
        if message.guild and not message.author.bot:
            embed = discord.Embed(title="Message Deleted", color=discord.Color.red())
            embed.description = (
                f"**Channel :** {message.channel.name} ( {message.channel.mention} )\n"
                f"**Message ID :** {message.id}\n"
                f"**Message author :** {message.author.mention} ( {message.author} )\n"
                f"**Message created :** <t:{int(message.created_at.timestamp())}:R>\n\n"
                f"**Message**\n{message.content or '*No content*'}"
            )
            await self.send_log(message.guild, "message", embed)

    @commands.Cog.listener()
    async def on_message_edit(self, before, after):
        if before.guild and not before.author.bot and before.content != after.content:
            embed = discord.Embed(title="Message Edited", color=discord.Color.yellow())
            embed.description = (
                f"**Channel :** {before.channel.name} ( {before.channel.mention} )\n"
                f"**Message ID :** {before.id}\n"
                f"**Message author :** {before.author.mention} ( {before.author} )\n"
                f"**Message created :** <t:{int(before.created_at.timestamp())}:R>\n\n"
                f"**Before**\n{before.content or '*No content*'}\n\n"
                f"**After**\n{after.content or '*No content*'}"
            )
            await self.send_log(before.guild, "message", embed)

    @commands.Cog.listener()
    async def on_member_join(self, member):
        if member.bot:
            embed = discord.Embed(title="Bot Added", color=discord.Color.green())
            embed.description = (
                f"**Bot :** {member.mention} ( {member} )\n"
                f"**Bot ID :** {member.id}\n"
                f"**Account created :** <t:{int(member.created_at.timestamp())}:R>\n"
                f"**Total members :** {member.guild.member_count}"
            )
            if member.display_avatar:
                embed.set_thumbnail(url=member.display_avatar.url)
            await self.send_log(member.guild, "application", embed)
        else:
            embed = discord.Embed(title="User Joined", color=discord.Color.green())
            embed.description = (
                f"**Member :** {member.mention} ( {member} )\n"
                f"**User ID :** {member.id}\n"
                f"**Account created :** <t:{int(member.created_at.timestamp())}:R>\n"
                f"**Total members :** {member.guild.member_count}"
            )
            if member.display_avatar:
                embed.set_thumbnail(url=member.display_avatar.url)
            await self.send_log(member.guild, "join", embed)

    @commands.Cog.listener()
    async def on_member_remove(self, member):
        if member.bot:
            embed = discord.Embed(title="Bot Removed", color=discord.Color.red())
            embed.description = (
                f"**Bot :** {member.mention} ( {member} )\n"
                f"**Bot ID :** {member.id}\n"
                f"**Joined at :** <t:{int(member.joined_at.timestamp())}:R>\n"
                f"**Total members :** {member.guild.member_count}"
            )
            if member.display_avatar:
                embed.set_thumbnail(url=member.display_avatar.url)
            await self.send_log(member.guild, "application", embed)
        else:
            embed = discord.Embed(title="User Left", color=discord.Color.red())
            embed.description = (
                f"**Member :** {member.mention} ( {member} )\n"
                f"**User ID :** {member.id}\n"
                f"**Joined at :** <t:{int(member.joined_at.timestamp())}:R>\n"
                f"**Total members :** {member.guild.member_count}"
            )
            if member.display_avatar:
                embed.set_thumbnail(url=member.display_avatar.url)
            await self.send_log(member.guild, "leave", embed)

    @commands.Cog.listener()
    async def on_member_update(self, before, after):
        if len(before.roles) < len(after.roles):
            # Role added
            added_roles = [r for r in after.roles if r not in before.roles]
            for role in added_roles:
                embed = discord.Embed(title="Member Roles Updated", color=discord.Color.purple())
                embed.description = (
                    f"**Member :** {after.mention} ( {after} )\n"
                    f"**Role added :** {role.mention}"
                )
                if after.display_avatar:
                    embed.set_thumbnail(url=after.display_avatar.url)
                await self.send_log(after.guild, "role", embed)
                
                if role.permissions.administrator or role.permissions.ban_members or role.permissions.kick_members or role.permissions.manage_guild or role.permissions.manage_roles or role.permissions.manage_channels or role.permissions.manage_webhooks:
                    alert = discord.Embed(title="⚠️ High Risk Role Granted", color=discord.Color.red())
                    alert.description = (
                        f"**Member :** {after.mention} ( {after} )\n"
                        f"**Role added :** {role.mention}\n"
                        f"**Warning :** This role contains dangerous administrative permissions!"
                    )
                    if after.display_avatar:
                        alert.set_thumbnail(url=after.display_avatar.url)
                    await self.send_log(after.guild, "alert", alert)
        elif len(before.roles) > len(after.roles):
            # Role removed
            removed_roles = [r for r in before.roles if r not in after.roles]
            for role in removed_roles:
                embed = discord.Embed(title="Member Roles Updated", color=discord.Color.red())
                embed.description = (
                    f"**Member :** {after.mention} ( {after} )\n"
                    f"**Role removed :** {role.mention}"
                )
                if after.display_avatar:
                    embed.set_thumbnail(url=after.display_avatar.url)
                await self.send_log(after.guild, "role", embed)

    @commands.Cog.listener()
    async def on_raw_reaction_add(self, payload):
        if payload.guild_id and not payload.member.bot:
            guild = self.bot.get_guild(payload.guild_id)
            if not guild: return
            channel = guild.get_channel(payload.channel_id)
            embed = discord.Embed(title="Reaction Added", color=discord.Color.green())
            embed.description = (
                f"**Channel :** {channel.name} ( {channel.mention} )\n"
                f"**Message ID :** {payload.message_id}\n"
                f"**Message author :** {payload.member.mention} ( {payload.member} )\n"
                f"**Reaction :** {payload.emoji.name}"
            )
            await self.send_log(guild, "event", embed)

    @commands.Cog.listener()
    async def on_command_completion(self, ctx):
        if ctx.guild and not ctx.author.bot:
            embed = discord.Embed(title="Command Executed", color=discord.Color.blurple())
            embed.description = (
                f"**Channel :** {ctx.channel.name} ( {ctx.channel.mention} )\n"
                f"**Message ID :** {ctx.message.id}\n"
                f"**Message author :** {ctx.author.mention} ( {ctx.author} )\n"
                f"**Message created :** <t:{int(ctx.message.created_at.timestamp())}:R>\n\n"
                f"**Command**\n{ctx.message.content}"
            )
            await self.send_log(ctx.guild, "system", embed)

    @commands.Cog.listener()
    async def on_guild_channel_create(self, channel):
        embed = discord.Embed(title="Channel Created", color=discord.Color.green())
        embed.description = (
            f"**Channel :** {channel.name} ( {channel.mention} )\n"
            f"**Channel ID :** {channel.id}\n"
            f"**Category :** {channel.category.name if channel.category else 'None'}"
        )
        await self.send_log(channel.guild, "channel", embed)

    @commands.Cog.listener()
    async def on_guild_channel_delete(self, channel):
        embed = discord.Embed(title="Channel Deleted", color=discord.Color.red())
        embed.description = (
            f"**Channel :** {channel.name}\n"
            f"**Channel ID :** {channel.id}\n"
            f"**Category :** {channel.category.name if channel.category else 'None'}"
        )
        await self.send_log(channel.guild, "channel", embed)

    @commands.Cog.listener()
    async def on_guild_role_create(self, role):
        embed = discord.Embed(title="Role Created", color=discord.Color.green())
        embed.description = (
            f"**Role :** {role.name} ( {role.mention} )\n"
            f"**Role ID :** {role.id}"
        )
        await self.send_log(role.guild, "role", embed)

    @commands.Cog.listener()
    async def on_guild_role_delete(self, role):
        embed = discord.Embed(title="Role Deleted", color=discord.Color.red())
        embed.description = (
            f"**Role :** {role.name}\n"
            f"**Role ID :** {role.id}"
        )
        await self.send_log(role.guild, "role", embed)

    @commands.Cog.listener()
    async def on_member_ban(self, guild, user):
        embed = discord.Embed(title="Member Banned", color=discord.Color.red())
        embed.description = (
            f"**User :** {user.mention} ( {user} )\n"
            f"**User ID :** {user.id}"
        )
        if getattr(user, 'display_avatar', None):
            embed.set_thumbnail(url=user.display_avatar.url)
        await self.send_log(guild, "mod", embed)

    @commands.Cog.listener()
    async def on_member_unban(self, guild, user):
        embed = discord.Embed(title="Member Unbanned", color=discord.Color.green())
        embed.description = (
            f"**User :** {user.mention} ( {user} )\n"
            f"**User ID :** {user.id}"
        )
        if getattr(user, 'display_avatar', None):
            embed.set_thumbnail(url=user.display_avatar.url)
        await self.send_log(guild, "mod", embed)

    @commands.Cog.listener()
    async def on_webhooks_update(self, channel):
        embed = discord.Embed(title="Webhook Updated", color=discord.Color.blurple())
        embed.description = (
            f"**Channel :** {channel.name} ( {channel.mention} )\n"
            f"**Channel ID :** {channel.id}"
        )
        await self.send_log(channel.guild, "webhook", embed)

async def setup(bot):
    await bot.add_cog(Logging(bot))