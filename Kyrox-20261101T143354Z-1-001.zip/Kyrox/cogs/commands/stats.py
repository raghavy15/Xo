from __future__ import annotations

import datetime
import os
import sys
import time
import platform

import discord
import psutil
from discord import Embed
from discord.ext import commands

from utils import emojis
from utils.Tools import blacklist_check, ignore_check
from utils.cv2_compat import embed_to_view


from utils.database import connect
class Stats(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.start_time = time.time()
        self.total_songs_played = 0
        self._code_stats: tuple[int, int, int] | None = None

    async def cog_load(self) -> None:
        await self.setup_database()

    async def setup_database(self):
        os.makedirs("db", exist_ok=True)
        async with connect('stats.db') as db:
            await db.execute("CREATE TABLE IF NOT EXISTS stats (key TEXT PRIMARY KEY, value INTEGER)")
            await db.commit()
            async with db.execute("SELECT value FROM stats WHERE key = 'total_songs_played'") as cursor:
                row = await cursor.fetchone()
            self.total_songs_played = row[0] if row else 0
            if row is None:
                await db.execute("INSERT INTO stats (key, value) VALUES ('total_songs_played', 0)")
                await db.commit()

    async def update_total_songs_played(self):
        async with connect('stats.db') as db:
            await db.execute(
                "INSERT OR REPLACE INTO stats (key, value) VALUES ('total_songs_played', ?)",
                (self.total_songs_played,),
            )
            await db.commit()

    @commands.Cog.listener()
    async def on_lavalink_track_start(self, event):
        self.total_songs_played += 1
        await self.update_total_songs_played()

    def count_code_stats(self, file_path: str) -> tuple[int, int]:
        total_lines = 0
        total_words = 0
        try:
            with open(file_path, "r", encoding="utf-8") as file:
                for line in file:
                    stripped = line.strip()
                    if stripped:
                        total_lines += 1
                        total_words += len(stripped.split())
        except (UnicodeDecodeError, OSError):
            pass
        return total_lines, total_words

    def gather_file_stats(self, directory: str) -> tuple[int, int, int]:
        total_files = 0
        total_lines = 0
        total_words = 0
        skipped_dirs = {
            ".git",
            "__pycache__",
            ".pytest_cache",
            ".mypy_cache",
            ".ruff_cache",
            ".venv",
            "venv",
            "env",
            "data",
            "db",
            "node_modules",
        }

        for root, dirs, files in os.walk(directory):
            dirs[:] = [d for d in dirs if d not in skipped_dirs]
            if any(part in skipped_dirs for part in os.path.normpath(root).split(os.sep)):
                continue
            for file in files:
                if not file.endswith(".py") or ".bak" in file:
                    continue
                total_files += 1
                file_lines, file_words = self.count_code_stats(os.path.join(root, file))
                total_lines += file_lines
                total_words += file_words

        return total_files, total_lines, total_words

    async def get_stats_data(self, category: str, ctx: commands.Context):
        bot = self.bot
        dot = emojis.RED_DOT
        
        import aiohttp
        from utils.banner import generate_stats_banner
        
        avatar_bytes = None
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(bot.user.display_avatar.url) as resp:
                    if resp.status == 200:
                        avatar_bytes = await resp.read()
        except Exception:
            pass

        if category == "bot":
            title = f"## {bot.user.name}'s Statistics"
            
            guild_count = len(bot.guilds)
            user_count = sum(g.member_count for g in bot.guilds if g.member_count is not None)
            cached_members = list(bot.get_all_members())
            bot_count = sum(1 for member in cached_members if member.bot)
            human_count = max(user_count - bot_count, 0)
            total_users = human_count + bot_count
            
            all_channels = list(bot.get_all_channels())
            channel_count = len(all_channels)
            
            slash_commands = len(bot.tree.get_commands())
            commands_count = len(tuple(bot.walk_commands()))
            
            shard_id = ctx.guild.shard_id if ctx.guild else 0
            shard_count = bot.shard_count if bot.shard_count else 1
            
            desc = (
                f"{title}\n"
                f"{dot} **Username :** `{bot.user}`\n"
                f"{dot} **Bot ID :** `{bot.user.id}`\n"
                f"{dot} **Servers :** `{guild_count}`\n"
                f"{dot} **Users :** `{total_users}`\n"
                f"{dot} **Channels :** `{channel_count}`\n"
                f"{dot} **Commands :** `{commands_count + slash_commands}`\n"
                f"{dot} **Shards :** `{shard_id + 1} / {shard_count}`\n"
                f"{dot} **Clusters :** `1 / 1`"
            )
            
            buf = await bot.loop.run_in_executor(
                None, 
                lambda: generate_stats_banner(
                    avatar_bytes, 
                    name=bot.user.name,
                    subtitle="BOT PERFORMANCE METRICS",
                    m1_title="SERVER GROWTH", m1_val=f"{guild_count} Guilds", m1_pct=0.8,
                    m2_title="USER GROWTH", m2_val=f"{total_users} Users", m2_pct=0.6
                )
            )
            file = discord.File(buf, filename="banner.png")

        elif category == "music":
            title = "## Music Statistics"
            
            playing_tracks = sum(1 for vc in bot.voice_clients if getattr(vc, "is_playing", lambda: getattr(vc, "playing", False))())
            paused_tracks = sum(1 for vc in bot.voice_clients if getattr(vc, "is_paused", lambda: getattr(vc, "paused", False))())
            active_players = len(bot.voice_clients)
            
            desc = (
                f"{title}\n"
                f"{dot} **Active Players :** `{active_players}`\n"
                f"{dot} **Playing Now :** `{playing_tracks}`\n"
                f"{dot} **Paused Players :** `{paused_tracks}`\n"
                f"{dot} **Total Songs Queue :** `{self.total_songs_played}`\n"
                f"{dot} **Node :** `Local Node`\n"
                f"{dot} **Lavalink Version :** `N/A`"
            )
            
            buf = await bot.loop.run_in_executor(
                None, 
                lambda: generate_stats_banner(
                    avatar_bytes, 
                    name=bot.user.name,
                    subtitle="MUSIC PERFORMANCE METRICS",
                    m1_title="ACTIVE PLAYERS", m1_val=f"{active_players} Active", m1_pct=0.4,
                    m2_title="QUEUE ACTIVITY", m2_val=f"{self.total_songs_played} Songs", m2_pct=0.7
                )
            )
            file = discord.File(buf, filename="banner.png")

        elif category == "system":
            title = "## System Information"
            
            uptime_seconds = int(time.time() - self.start_time)
            m, s = divmod(uptime_seconds, 60)
            h, m = divmod(m, 60)
            d, h = divmod(h, 24)
            uptime = f"{d}d {h}h {m}m"
            
            memory_info = psutil.virtual_memory()
            process = psutil.Process(os.getpid())
            mem = process.memory_info()
            
            websocket_latency = round(bot.latency * 1000)
            
            db_latency = "N/A"
            try:
                async with connect('afk.db') as db:
                    start = time.perf_counter()
                    await db.execute("SELECT 1")
                    db_latency = f"{round((time.perf_counter() - start) * 1000)} ms"
            except Exception:
                pass
            
            desc = (
                f"{title}\n"
                f"{dot} **API Latency :** `{websocket_latency} ms`\n"
                f"{dot} **Uptime :** `{uptime}`\n"
                f"{dot} **Memory (RSS) :** `{mem.rss / (1024 ** 2):.2f} MB`\n"
                f"{dot} **Heap Used :** `{memory_info.used / (1024 ** 2):.2f} MB`\n"
                f"{dot} **Heap Total :** `{memory_info.total / (1024 ** 2):.2f} MB`\n"
                f"{dot} **Platform :** `{platform.system().lower()} ({platform.machine()})`\n"
                f"{dot} **CPU Model :** `{platform.processor()}`\n"
                f"{dot} **CPU Cores :** `{psutil.cpu_count()}`\n"
                f"{dot} **CPU Speed :** `{psutil.cpu_freq().current if psutil.cpu_freq() else 0} MHz`\n"
                f"{dot} **Python :** `v{sys.version.split()[0]}`\n"
                f"{dot} **Discord.py :** `v{discord.__version__}`\n"
                f"{dot} **Database :** `sqlite (Connected)`"
            )
            
            buf = await bot.loop.run_in_executor(
                None, 
                lambda: generate_stats_banner(
                    avatar_bytes, 
                    name=bot.user.name,
                    subtitle="SYSTEM PERFORMANCE METRICS",
                    m1_title="API LATENCY", m1_val=f"{websocket_latency}ms", m1_pct=0.3,
                    m2_title="MEMORY USAGE", m2_val=f"{mem.rss / (1024 ** 2):.2f}MB", m2_pct=0.6
                )
            )
            file = discord.File(buf, filename="banner.png")

        elif category == "node":
            title = "## Node Performance"
            
            memory_info = psutil.virtual_memory()
            
            desc = (
                f"{title}\n"
                f"{dot} **Node Memory :** `{memory_info.used / (1024 ** 2) * 0.1:.2f} MB`\n"
                f"{dot} **Node CPU Load :** `{psutil.cpu_percent()}%`\n"
                f"{dot} **System RAM Total :** `{memory_info.total / (1024 ** 2):.2f} MB`\n"
                f"{dot} **System RAM Used :** `{memory_info.used / (1024 ** 2):.2f} MB`\n"
                f"{dot} **System RAM Free :** `{memory_info.free / (1024 ** 2):.2f} MB`"
            )
            
            buf = await bot.loop.run_in_executor(
                None, 
                lambda: generate_stats_banner(
                    avatar_bytes, 
                    name=bot.user.name,
                    subtitle="NODE PERFORMANCE METRICS",
                    m1_title="CPU LOAD", m1_val=f"{psutil.cpu_percent()}%", m1_pct=psutil.cpu_percent()/100,
                    m2_title="RAM USAGE", m2_val=f"{memory_info.used / (1024 ** 2):.0f}MB", m2_pct=memory_info.percent/100
                )
            )
            file = discord.File(buf, filename="banner.png")

        elif category == "team":
            title = "## About Team"
            
            desc = (
                f"{title}\n"
                "> <:Arrow:1526247269756829727> Below is the information about **Kyrox Team** 🐱\n\n"
                "**<a:developer_red:1526247666202316923> Developers**\n"
                "• [Krishna. ✯](https://discord.com)\n\n"
                "**<a:developer:1526248377116004474> Co-Dev**\n"
                "• [Vaishnav. ✯](https://discord.com)\n\n"
                "**<a:crown_:1526248703848087602>  Owner**\n"
                "• Coming Soon"
            )
            
            buf = await bot.loop.run_in_executor(
                None, 
                lambda: generate_stats_banner(
                    avatar_bytes, 
                    name=bot.user.name,
                    subtitle="TEAM PERFORMANCE METRICS",
                    m1_title="COMMITS", m1_val="1.2K+", m1_pct=0.85,
                    m2_title="CO-DEVELOPER", m2_val="Vaishnav", m2_pct=0.5
                )
            )
            file = discord.File(buf, filename="banner.png")

        return embed, file
    
    def count_code_stats(self, directory: str):
        total_files = 0
        total_lines = 0
        total_words = 0
        
        ignore_dirs = ['venv', '.venv', '.git', '__pycache__', 'node_modules']
        ignore_extensions = ['.png', '.jpg', '.jpeg', '.gif', '.webp', '.mp3', '.mp4', '.ogg', '.wav', '.bin', '.ico']

        for root, dirs, files in os.walk(directory):
            if any(ig in root for ig in ignore_dirs):
                continue
                
            for file in files:
                if any(file.endswith(ext) for ext in ignore_extensions):
                    continue
                    
                total_files += 1
                file_lines, file_words = self.count_code_stats(os.path.join(root, file))
                total_lines += file_lines
                total_words += file_words

        return total_files, total_lines, total_words

    async def get_stats_data(self, category: str, ctx: commands.Context):
        bot = self.bot
        dot = emojis.RED_DOT
        
        import aiohttp
        from utils.banner import generate_stats_banner
        
        avatar_bytes = None
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(bot.user.display_avatar.url) as resp:
                    if resp.status == 200:
                        avatar_bytes = await resp.read()
        except Exception:
            pass

        if category == "bot":
            title = f"## {bot.user.name}'s Statistics"
            
            guild_count = len(bot.guilds)
            user_count = sum(g.member_count for g in bot.guilds if g.member_count is not None)
            cached_members = list(bot.get_all_members())
            bot_count = sum(1 for member in cached_members if member.bot)
            human_count = max(user_count - bot_count, 0)
            total_users = human_count + bot_count
            
            all_channels = list(bot.get_all_channels())
            channel_count = len(all_channels)
            
            slash_commands = len(bot.tree.get_commands())
            commands_count = len(tuple(bot.walk_commands()))
            
            shard_id = ctx.guild.shard_id if ctx.guild else 0
            shard_count = bot.shard_count if bot.shard_count else 1
            
            desc = (
                f"{title}\n"
                f"{dot} **Username :** `{bot.user}`\n"
                f"{dot} **Bot ID :** `{bot.user.id}`\n"
                f"{dot} **Servers :** `{guild_count}`\n"
                f"{dot} **Users :** `{total_users}`\n"
                f"{dot} **Channels :** `{channel_count}`\n"
                f"{dot} **Commands :** `{commands_count + slash_commands}`\n"
                f"{dot} **Shards :** `{shard_id + 1} / {shard_count}`\n"
                f"{dot} **Clusters :** `1 / 1`"
            )
            
            buf = await bot.loop.run_in_executor(
                None, 
                lambda: generate_stats_banner(
                    avatar_bytes, 
                    name=bot.user.name,
                    subtitle="BOT PERFORMANCE METRICS",
                    m1_title="SERVER GROWTH", m1_val=f"{guild_count} Guilds", m1_pct=0.8,
                    m2_title="USER GROWTH", m2_val=f"{total_users} Users", m2_pct=0.6
                )
            )
            file = discord.File(buf, filename="banner.png")

        elif category == "music":
            title = "## Music Statistics"
            
            playing_tracks = sum(1 for vc in bot.voice_clients if getattr(vc, "is_playing", lambda: getattr(vc, "playing", False))())
            paused_tracks = sum(1 for vc in bot.voice_clients if getattr(vc, "is_paused", lambda: getattr(vc, "paused", False))())
            active_players = len(bot.voice_clients)
            
            desc = (
                f"{title}\n"
                f"{dot} **Active Players :** `{active_players}`\n"
                f"{dot} **Playing Now :** `{playing_tracks}`\n"
                f"{dot} **Paused Players :** `{paused_tracks}`\n"
                f"{dot} **Total Songs Queue :** `{self.total_songs_played}`\n"
                f"{dot} **Node :** `Local Node`\n"
                f"{dot} **Lavalink Version :** `N/A`"
            )
            
            buf = await bot.loop.run_in_executor(
                None, 
                lambda: generate_stats_banner(
                    avatar_bytes, 
                    name=bot.user.name,
                    subtitle="MUSIC PERFORMANCE METRICS",
                    m1_title="ACTIVE PLAYERS", m1_val=f"{active_players} Active", m1_pct=0.4,
                    m2_title="QUEUE ACTIVITY", m2_val=f"{self.total_songs_played} Songs", m2_pct=0.7
                )
            )
            file = discord.File(buf, filename="banner.png")

        elif category == "system":
            title = "## System Information"
            
            uptime_seconds = int(time.time() - self.start_time)
            m, s = divmod(uptime_seconds, 60)
            h, m = divmod(m, 60)
            d, h = divmod(h, 24)
            uptime = f"{d}d {h}h {m}m"
            
            memory_info = psutil.virtual_memory()
            process = psutil.Process(os.getpid())
            mem = process.memory_info()
            
            websocket_latency = round(bot.latency * 1000)
            
            db_latency = "N/A"
            try:
                async with connect('afk.db') as db:
                    start = time.perf_counter()
                    await db.execute("SELECT 1")
                    db_latency = f"{round((time.perf_counter() - start) * 1000)} ms"
            except Exception:
                pass
            
            desc = (
                f"{title}\n"
                f"{dot} **API Latency :** `{websocket_latency} ms`\n"
                f"{dot} **Uptime :** `{uptime}`\n"
                f"{dot} **Memory (RSS) :** `{mem.rss / (1024 ** 2):.2f} MB`\n"
                f"{dot} **Heap Used :** `{memory_info.used / (1024 ** 2):.2f} MB`\n"
                f"{dot} **Heap Total :** `{memory_info.total / (1024 ** 2):.2f} MB`\n"
                f"{dot} **Platform :** `{platform.system().lower()} ({platform.machine()})`\n"
                f"{dot} **CPU Model :** `{platform.processor()}`\n"
                f"{dot} **CPU Cores :** `{psutil.cpu_count()}`\n"
                f"{dot} **CPU Speed :** `{psutil.cpu_freq().current if psutil.cpu_freq() else 0} MHz`\n"
                f"{dot} **Python :** `v{sys.version.split()[0]}`\n"
                f"{dot} **Discord.py :** `v{discord.__version__}`\n"
                f"{dot} **Database :** `sqlite (Connected)`"
            )
            
            buf = await bot.loop.run_in_executor(
                None, 
                lambda: generate_stats_banner(
                    avatar_bytes, 
                    name=bot.user.name,
                    subtitle="SYSTEM PERFORMANCE METRICS",
                    m1_title="API LATENCY", m1_val=f"{websocket_latency}ms", m1_pct=0.3,
                    m2_title="MEMORY USAGE", m2_val=f"{mem.rss / (1024 ** 2):.2f}MB", m2_pct=0.6
                )
            )
            file = discord.File(buf, filename="banner.png")

        elif category == "node":
            title = "## Node Performance"
            
            memory_info = psutil.virtual_memory()
            
            desc = (
                f"{title}\n"
                f"{dot} **Node Memory :** `{memory_info.used / (1024 ** 2) * 0.1:.2f} MB`\n"
                f"{dot} **Node CPU Load :** `{psutil.cpu_percent()}%`\n"
                f"{dot} **System RAM Total :** `{memory_info.total / (1024 ** 2):.2f} MB`\n"
                f"{dot} **System RAM Used :** `{memory_info.used / (1024 ** 2):.2f} MB`\n"
                f"{dot} **System RAM Free :** `{memory_info.free / (1024 ** 2):.2f} MB`"
            )
            
            buf = await bot.loop.run_in_executor(
                None, 
                lambda: generate_stats_banner(
                    avatar_bytes, 
                    name=bot.user.name,
                    subtitle="NODE PERFORMANCE METRICS",
                    m1_title="CPU LOAD", m1_val=f"{psutil.cpu_percent()}%", m1_pct=psutil.cpu_percent()/100,
                    m2_title="RAM USAGE", m2_val=f"{memory_info.used / (1024 ** 2):.0f}MB", m2_pct=memory_info.percent/100
                )
            )
            file = discord.File(buf, filename="banner.png")

        elif category == "team":
            title = "## About Team"
            
            desc = (
                f"{title}\n"
                "> <:Arrow:1526247269756829727> Below is the information about **Kyrox Team** 🐱\n\n"
                "**<a:developer_red:1526247666202316923> Developers**\n"
                "• [Krishna. ✯](https://discord.com)\n\n"
                "**<a:developer:1526248377116004474> Co-Dev**\n"
                "• [Vaishnav. ✯](https://discord.com)\n\n"
                "**<a:crown_:1526248703848087602>  Owner**\n"
                "• Coming Soon"
            )
            
            buf = await bot.loop.run_in_executor(
                None, 
                lambda: generate_stats_banner(
                    avatar_bytes, 
                    name=bot.user.name,
                    subtitle="TEAM PERFORMANCE METRICS",
                    m1_title="COMMITS", m1_val="1.2K+", m1_pct=0.85,
                    m2_title="COFFEE", m2_val="999+ CUPS", m2_pct=0.95
                )
            )
            file = discord.File(buf, filename="banner.png")

        return desc, file

    @commands.hybrid_command(
        name="stats",
        aliases=["botinfo", "botstats", "bi", "statistics"],
        help="Shows the bot's information.",
    )
    @blacklist_check()
    @ignore_check()
    @commands.cooldown(1, 7, commands.BucketType.user)
    async def stats(self, ctx: commands.Context):
        from utils.components_v2 import container, text, layout_view, action_row
        processing_message = await ctx.send(f"{emojis.LOADING} Loading Kyrox information...")
        
        desc, file = await self.get_stats_data("bot", ctx)
        select = StatsSelect(self, ctx)
        
        # Build the container for the text content
        content_container = container(text(desc))
        
        # Use MediaGallery to display the banner image natively in V2 UI
        gallery = discord.ui.MediaGallery()
        gallery.add_item(media="attachment://banner.png")
        
        # Build the final view combining the container, gallery, and the select menu
        view = layout_view(content_container, gallery, action_row(select))
        
        await ctx.reply(view=view, file=file, mention_author=False)
        await processing_message.delete()


class StatsSelect(discord.ui.Select):
    def __init__(self, stats_cog, ctx):
        self.stats_cog = stats_cog
        self.ctx = ctx
        options = [
            discord.SelectOption(label="Bot Statistics", description="View bot information and server counts", value="bot", default=True),
            discord.SelectOption(label="Music Statistics", description="View music player and queue information", value="music"),
            discord.SelectOption(label="System Information", description="View system and platform details", value="system"),
            discord.SelectOption(label="Node Performance", description="View Lavalink node performance metrics", value="node"),
            discord.SelectOption(label="Team Information", description="View bot developers and team metrics", value="team"),
        ]
        super().__init__(placeholder="Select a category", min_values=1, max_values=1, options=options)

    async def callback(self, interaction: discord.Interaction):
        from utils.components_v2 import container, text, layout_view, action_row
        
        if interaction.user != self.ctx.author:
            return await interaction.response.send_message("This menu is not for you!", ephemeral=True)
            
        for opt in self.options:
            opt.default = (opt.value == self.values[0])
            
        desc, file = await self.stats_cog.get_stats_data(self.values[0], self.ctx)
        
        content_container = container(text(desc))
        
        # Use MediaGallery to display the banner image natively in V2 UI
        gallery = discord.ui.MediaGallery()
        gallery.add_item(media="attachment://banner.png")
        
        view = layout_view(content_container, gallery, action_row(self))
        
        await interaction.response.edit_message(content=None, embed=None, view=view, attachments=[file])
