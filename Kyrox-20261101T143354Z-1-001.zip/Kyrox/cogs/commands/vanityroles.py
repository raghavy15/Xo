import aiohttp
import discord
from discord.ext import commands, tasks

from utils.Tools import *
from utils.cv2_compat import embed_to_view, embeds_to_view
from utils.database import get_collection

DB_PATH = "vanity.db"


class VanityRoles(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self._checker_started = False

    async def cog_load(self) -> None:
        pass

    async def cog_unload(self) -> None:
        self.vanity_checker.cancel()

    @commands.Cog.listener()
    async def on_ready(self):
        if not self._checker_started and not self.vanity_checker.is_running():
            self._checker_started = True
            self.vanity_checker.start()

    @commands.group(name="vanityroles", invoke_without_command=True)
    @blacklist_check()
    @ignore_check()
    async def vanityroles(self, ctx):
        await ctx.send("❗ Usage: `vanityroles setup <vanity> <@role> <#channel>`, `vanityroles show`, `vanityroles reset`")

    @vanityroles.command(name="setup")
    @blacklist_check()
    @ignore_check()
    async def setup(self, ctx, vanity: str, role: discord.Role, channel: discord.TextChannel):
        col = await get_collection('vanity_roles')
        await col.update_one(
            {'guild_id': ctx.guild.id, 'vanity': vanity.lower()},
            {'$set': {'role_id': role.id, 'log_channel_id': channel.id if channel else None, 'current_status': None}},
            upsert=True
        )
        embed = discord.Embed(
            title="✅ Vanity Role Setup",
            description=f"Vanity: `{vanity}`\nRole: {role.mention}\nLog Channel: {channel.mention}",
            color=discord.Color.green()
        )
        await ctx.send(view=embed_to_view(embed))

    @vanityroles.command(name="show")
    @blacklist_check()
    @ignore_check()
    async def show(self, ctx):
        col = await get_collection('vanity_roles')
        docs = await col.find({'guild_id': ctx.guild.id}).to_list(length=None)
        rows = [(doc.get('vanity'), doc.get('role_id'), doc.get('log_channel_id')) for doc in docs]

        if not rows:
            return await ctx.send("❌ No vanity role setups found.")

        embed = discord.Embed(title="🔧 Vanity Role Settings", color=discord.Color.blue())
        for vanity, role_id, log_channel_id in rows:
            role = ctx.guild.get_role(role_id)
            channel = ctx.guild.get_channel(log_channel_id)
            embed.add_field(
                name=f"Vanity: `{vanity}`",
                value=f"Role: {role.mention if role else role_id}\nLog: {channel.mention if channel else log_channel_id}",
                inline=False,
            )
        await ctx.send(view=embed_to_view(embed))

    @vanityroles.command(name="reset")
    @blacklist_check()
    @ignore_check()
    async def reset(self, ctx):
        col = await get_collection('vanity_roles')
        await col.delete_one({'guild_id': ctx.guild.id})
        await ctx.send("✅ All vanity role configurations have been reset.")

    @tasks.loop(seconds=15)
    async def vanity_checker(self):
        col = await get_collection('vanity_roles')
        docs = await col.find({}).to_list(length=None)
        rows = [(doc.get('guild_id'), doc.get('vanity'), doc.get('role_id'), doc.get('log_channel_id'), doc.get('current_status')) for doc in docs]

        for guild_id, vanity, role_id, log_channel_id, current_status in rows:
            guild = self.bot.get_guild(guild_id)
            if not guild:
                continue

            role = guild.get_role(role_id)
            log_channel = guild.get_channel(log_channel_id)

            try:
                async with aiohttp.ClientSession() as session:
                    async with session.get(f"https://discord.com/api/v10/invites/{vanity}") as response:
                        is_active = response.status == 200
            except Exception:
                continue

            if is_active and current_status != "active":
                await self.update_status(guild_id, vanity, "active")
                assigned = 0
                for member in guild.members:
                    if member.status != discord.Status.offline and role and role not in member.roles:
                        try:
                            await member.add_roles(role, reason="Vanity active")
                            assigned += 1
                        except Exception:
                            pass
                if log_channel:
                    await log_channel.send(
                        f"✅ Vanity `{vanity}` is now **active**. Role assigned to {assigned} members."
                    )

            elif not is_active and current_status == "active":
                await self.update_status(guild_id, vanity, None)
                removed = 0
                for member in guild.members:
                    if role and role in member.roles:
                        try:
                            await member.remove_roles(role, reason="Vanity inactive")
                            removed += 1
                        except Exception:
                            pass
                if log_channel:
                    await log_channel.send(
                        f"❌ Vanity `{vanity}` is now **inactive**. Role removed from {removed} members."
                    )

    async def update_status(self, guild_id, vanity, new_status):
        col = await get_collection('vanity_roles')
        await col.update_one(
            {'guild_id': guild_id, 'vanity': vanity},
            {'$set': {'current_status': new_status}}
        )


async def setup(bot):
    await bot.add_cog(VanityRoles(bot))