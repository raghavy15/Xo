from utils.database import get_anti_db
from utils import emojis

import discord
from discord.ext import commands
import asyncio
from utils.Tools import *
from utils.components_v2 import container, text, layout_view, action_row, button, info_panel, success_panel, error_panel, warning_panel


class Antinuke(commands.Cog):
  def __init__(self, bot):
    self.bot = bot

  async def cog_load(self) -> None:
    await self.initialize_db()

  async def initialize_db(self):
    self.db = await get_anti_db()
    await self.db.execute('''
        CREATE TABLE IF NOT EXISTS antinuke (
            guild_id INTEGER PRIMARY KEY,
            status BOOLEAN
        )
    ''')
    await self.db.commit()

  async def enable_limit_settings(self, guild_id):
    for action, limit in DEFAULT_LIMITS.items():
      await self.db.execute(
        'INSERT OR REPLACE INTO limit_settings (guild_id, action_type, action_limit, time_window) VALUES (?, ?, ?, ?)',
        (guild_id, action, limit, TIME_WINDOW),
      )
    await self.db.commit()

  async def disable_limit_settings(self, guild_id):
    await self.db.execute('DELETE FROM limit_settings WHERE guild_id = ?', (guild_id,))
    await self.db.commit()

  def get_dashboard_view(self, guild_name: str, is_activated: bool) -> discord.ui.LayoutView:
    status_text = f"**Current Status:** {emojis.ENABLED if is_activated else emojis.DISABLED1} {'Enabled' if is_activated else 'Disabled'}"
    desc = (
        "Boost your server security with Antinuke! It automatically bans any admins involved in suspicious activities, ensuring the safety of your whitelisted members. Strengthen your defenses – activate Antinuke today!\n\n"
        f"{status_text}"
    )
    
    actions = [
        button("Enable Antinuke", "anti_enable", style=discord.ButtonStyle.success, disabled=is_activated),
        button("Disable Antinuke", "anti_disable", style=discord.ButtonStyle.danger, disabled=not is_activated),
        button("View Modules & Punishments", "anti_modules", style=discord.ButtonStyle.secondary)
    ]
    
    return info_panel(
        description=desc,
        title=f"Antinuke Dashboard — {guild_name}",
        actions=actions
    )

  @commands.hybrid_command(name='antinuke', aliases=['antiwizz', 'anti'], help="Manage Anti-Nuke Module for the server")
  @blacklist_check()
  @ignore_check()
  @commands.cooldown(1, 4, commands.BucketType.user)
  @commands.max_concurrency(1, per=commands.BucketType.default, wait=False)
  @commands.guild_only()
  @commands.has_permissions(administrator=True)
  @security_manager_check()
  async def antinuke(self, ctx, option: str = None):
    # Backward compatibility for 'enable' and 'disable' if typed manually
    guild_id = ctx.guild.id

    async with self.db.execute('SELECT status FROM antinuke WHERE guild_id = ?', (guild_id,)) as cursor:
      row = await cursor.fetchone()

    async with self.db.execute(
            "SELECT owner_id FROM extraowners WHERE guild_id = ? AND owner_id = ?",
            (ctx.guild.id, ctx.author.id)
        ) as cursor:
            check = await cursor.fetchone()

    is_owner = ctx.author.id == ctx.guild.owner_id
    if not is_owner and not check:
      return await ctx.send(view=error_panel("Only Server Owner or Extra Owner can Run this Command!", title="Access Denied"))

    is_activated = row[0] if row else False

    # Standard dashboard invocation
    if option is None:
        await ctx.send(view=self.get_dashboard_view(ctx.guild.name, is_activated))
    elif option.lower() == 'enable':
        if is_activated:
            await ctx.send(view=warning_panel("Your server **already has Antinuke enabled.**", title="Already Enabled"))
        else:
            await ctx.send(view=info_panel("Please use the `!antinuke` dashboard to enable Antinuke interactively.", title="Dashboard Migration"))
    elif option.lower() == 'disable':
        if not is_activated:
            await ctx.send(view=warning_panel("Uhh, looks like your server hasn't enabled Antinuke.", title="Not Enabled"))
        else:
            await ctx.send(view=info_panel("Please use the `!antinuke` dashboard to disable Antinuke interactively.", title="Dashboard Migration"))
    elif option.lower() == 'config':
        if not is_activated:
            await ctx.send(view=warning_panel("Uhh, looks like your server hasn't enabled Antinuke.", title="Not Enabled"))
        else:
            config_msg = (
                "**Tip:** For optimal functionality of the AntiNuke Module, please ensure that my role has **Administration** permissions and is positioned at the **Top** of the roles list.\n\n"
                f"**{emojis.ICONSETTING} Modules Enabled**\n"
                f"> {emojis.ENABLED_160063} **Anti Ban**\n"
                f"> {emojis.ENABLED_160063} **Anti Kick**\n"
                f"> {emojis.ENABLED_160063} **Anti Bot**\n"
                f"> {emojis.ENABLED_160063} **Anti Channel Create/Delete/Update**\n"
                f"> {emojis.ENABLED_160063} **Anti Everyone/Here**\n"
                f"> {emojis.ENABLED_160063} **Anti Role Create/Delete/Update**\n"
                f"> {emojis.ENABLED_160063} **Anti Member Update**\n"
                f"> {emojis.ENABLED_160063} **Anti Guild Update**\n"
                f"> {emojis.ENABLED_160063} **Anti Integration**\n"
                f"> {emojis.ENABLED_160063} **Anti Webhook Create/Delete/Update**\n\n"
                f"**Additional Modules**\n"
                f"> {emojis.ENABLED_160063} **Anti Prune**\n"
                f"> {emojis.ENABLED_160063} **Auto Recovery**\n"
            )
            await ctx.send(view=info_panel(config_msg, title=f"Antinuke Configuration — {ctx.guild.name}"))
    else:
        await ctx.send(view=error_panel("Invalid Option. Please use `!antinuke` without arguments to access the dashboard.", title="Invalid Option"))


  @commands.Cog.listener()
  async def on_interaction(self, interaction: discord.Interaction):
    if interaction.type is not discord.InteractionType.component:
      return
    
    custom_id = interaction.data.get('custom_id')
    if not custom_id or not custom_id.startswith('anti_'):
        return

    guild_id = interaction.guild_id

    # check permissions
    async with self.db.execute(
            "SELECT owner_id FROM extraowners WHERE guild_id = ? AND owner_id = ?",
            (guild_id, interaction.user.id)
        ) as cursor:
            check = await cursor.fetchone()
            
    is_owner = interaction.user.id == interaction.guild.owner_id
    
    if custom_id in ['anti_enable', 'anti_disable']:
        if not is_owner and not check:
            await interaction.response.send_message(view=error_panel("Only Server Owner or Extra Owner can manage Antinuke settings!", title="Access Denied"), ephemeral=True)
            return

    if custom_id == 'anti_modules':
        desc = (
          "**For Changes Made by Unwhitelisted Admins/Mods**\n\n"
          "**Anti Ban:** Ban\n"
          "**Anti Kick:** Ban\n"
          "**Anti Bot:** Ban the bot Inviter\n"
          "**Anti Channel Create/Delete/Update:** Ban\n"
          "**Anti Everyone/Here:** Remove the message & 1 hour timeout\n"
          "**Anti Role Create/Delete/Update:** Ban\n"
          "**Anti Member Update:** Ban\n"
          "**Anti Guild Update:** Ban\n"
          "**Anti Integration:** Ban\n"
          "**Anti Webhook Create/Delete/Update:** Ban\n"
          "**Anti Prune:** Ban\n"
          "**Auto Recovery:** Automatically recover damaged channels, roles, and settings\n\n"
          "> **Note:** In the case of member updates, action will be taken only if the role contains dangerous permissions such as Ban Members, Administrator, Manage Guild, Manage Channels, Manage Roles, Manage Webhooks, or Mention Everyone"
        )
        await interaction.response.send_message(view=info_panel(desc, title="Punishment Types", footer="These punishment types are fixed and assigned as required to ensure guild security/protection"), ephemeral=True)
        return

    if custom_id == 'anti_disable':
        await self.db.execute('DELETE FROM antinuke WHERE guild_id = ?', (guild_id,))
        await self.db.commit()
        await self.disable_limit_settings(guild_id)
        
        await interaction.response.edit_message(view=self.get_dashboard_view(interaction.guild.name, False))
        await interaction.followup.send(view=success_panel(f"Successfully disabled Antinuke for **{interaction.guild.name}**."), ephemeral=True)
        return

    if custom_id == 'anti_enable':
        await interaction.response.defer()
        
        setup_desc = f"{emojis.TICK} | Initializing Quick Setup!"
        await interaction.edit_original_response(view=info_panel(setup_desc, title=f"Antinuke Setup {emojis.GEAR}"))
        
        if not interaction.guild.me.guild_permissions.administrator:
            setup_desc += f"\n{emojis.ICONS_WARNING} | Setup failed: Missing **Administrator** permission."
            await interaction.edit_original_response(view=error_panel(setup_desc, title="Setup Failed"))
            return

        setup_desc += f"\n{emojis.TICK} | Checking Kyrox's role position for optimal configuration..."
        await interaction.edit_original_response(view=info_panel(setup_desc, title=f"Antinuke Setup {emojis.GEAR}"))

        setup_desc += f"\n{emojis.TICK} | Crafting and configuring the Kyrox Supreme role..."
        await interaction.edit_original_response(view=info_panel(setup_desc, title=f"Antinuke Setup {emojis.GEAR}"))
        
        try:
          role = await interaction.guild.create_role(
            name="Kyrox Supreme",
            color=0x0ba7ff,
            permissions=discord.Permissions(administrator=True),
            hoist=False,
            mentionable=False,
            reason="Antinuke setup Role Creation"
          )
          await interaction.guild.me.add_roles(role)
        except discord.Forbidden:
          setup_desc += f"\n{emojis.ICONS_WARNING} | Setup failed: Insufficient permissions to create role."
          await interaction.edit_original_response(view=error_panel(setup_desc, title="Setup Failed"))
          return
        except discord.HTTPException as e:
          setup_desc += f"\n{emojis.ICONS_WARNING} | Setup failed: HTTPException: {e}\nCheck Guild **Audit Logs**."
          await interaction.edit_original_response(view=error_panel(setup_desc, title="Setup Failed"))
          return

        setup_desc += f"\n{emojis.TICK} | Ensuring precise placement of the Kyrox Supreme role..."
        await interaction.edit_original_response(view=info_panel(setup_desc, title=f"Antinuke Setup {emojis.GEAR}"))
        try:
          await interaction.guild.edit_role_positions(positions={role: 1})
        except discord.Forbidden:
          setup_desc += f"\n{emojis.ICONS_WARNING} | Setup failed: Insufficient permissions to move role."
          await interaction.edit_original_response(view=error_panel(setup_desc, title="Setup Failed"))
          return
        except discord.HTTPException as e:
          setup_desc += f"\n{emojis.ICONS_WARNING} | Setup failed: HTTPException: {e}."
          await interaction.edit_original_response(view=error_panel(setup_desc, title="Setup Failed"))
          return

        setup_desc += f"\n{emojis.TICK} | Safeguarding your changes..."
        await interaction.edit_original_response(view=info_panel(setup_desc, title=f"Antinuke Setup {emojis.GEAR}"))

        setup_desc += f"\n{emojis.TICK} | Activating the Antinuke Modules for enhanced security...!!"
        await interaction.edit_original_response(view=info_panel(setup_desc, title=f"Antinuke Setup {emojis.GEAR}"))

        await self.db.execute('INSERT OR REPLACE INTO antinuke (guild_id, status) VALUES (?, ?)', (guild_id, True))
        await self.db.commit()
        await self.enable_limit_settings(guild_id)
        
        # update the original message to the activated dashboard
        await interaction.edit_original_response(view=self.get_dashboard_view(interaction.guild.name, True))
        
        # Follow up with success summary
        success_msg = (
            "**Tip:** For optimal functionality of the AntiNuke Module, please ensure that my role has **Administration** permissions and is positioned at the **Top** of the roles list.\n\n"
            f"**{emojis.ICONSETTING} Modules Enabled**\n"
            f"> {emojis.ENABLED_160063} **Anti Ban**\n"
            f"> {emojis.ENABLED_160063} **Anti Kick**\n"
            f"> {emojis.ENABLED_160063} **Anti Bot**\n"
            f"> {emojis.ENABLED_160063} **Anti Channel Create/Delete/Update**\n"
            f"> {emojis.ENABLED_160063} **Anti Everyone/Here**\n"
            f"> {emojis.ENABLED_160063} **Anti Role Create/Delete/Update**\n"
            f"> {emojis.ENABLED_160063} **Anti Member Update**\n"
            f"> {emojis.ENABLED_160063} **Anti Guild Update**\n"
            f"> {emojis.ENABLED_160063} **Anti Integration**\n"
            f"> {emojis.ENABLED_160063} **Anti Webhook Create/Delete/Update**\n\n"
            f"**Additional Modules**\n"
            f"> {emojis.ENABLED_160063} **Anti Prune**\n"
            f"> {emojis.ENABLED_160063} **Auto Recovery**\n"
        )
        await interaction.followup.send(view=success_panel(success_msg, title="Successfully Enabled Antinuke", footer="Powered by Kyrox"), ephemeral=True)

async def setup(bot):
    await bot.add_cog(Antinuke(bot))
