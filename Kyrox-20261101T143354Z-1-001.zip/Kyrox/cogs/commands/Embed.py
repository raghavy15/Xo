from utils import emojis

import os
import discord
from discord.ext import commands
from discord.ui import View, Select, Button
import asyncio
from utils.Tools import *
import re


class VariableButton(Button):
    def __init__(self, author):
        super().__init__(label="Variables", style=discord.ButtonStyle.secondary)
        self.author = author

    async def callback(self, interaction: discord.Interaction):
        if interaction.user != self.author:
            await interaction.response.send_message("Only the command author can use this button.", ephemeral=True)
            return

        variables = {
            "{user}": "Mentions the user (e.g., @UserName).",
            "{user_avatar}": "The user's avatar URL.",
            "{user_name}": "The user's username.",
            "{user_id}": "The user's ID number.",
            "{user_nick}": "The user's nickname in the server.",
            "{user_joindate}": "The user's join date in the server.",
            "{user_createdate}": "The user's account creation date.",
            "{server_name}": "The server's name.",
            "{server_id}": "The server's ID number.",
            "{server_membercount}": "The server's total member count.",
            "{server_icon}": "The server's icon URL."
        }
        
        embed = discord.Embed(
            title="Available Placeholders",
            description="Use these placeholders in your embed:",
            color=discord.Color(0x000000)
        )
        for var, desc in variables.items():
            embed.add_field(name=var, value=desc, inline=False)
        embed.set_footer(text="Add placeholders directly when editing title, description, etc.")
        await interaction.response.send_message(embed=embed, ephemeral=True)

class Embed(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.client = bot

    @commands.hybrid_command(name="embed")
    @blacklist_check()
    @ignore_check()
    @commands.cooldown(1, 7, commands.BucketType.user)
    @commands.has_permissions(manage_messages=True)
    async def _embed(self, ctx):
        msgx = "Example embed. You can customize everything.\n*Respond within 30 seconds to avoid time out.*"
        embed = discord.Embed(title="Edit your Embed!", 
                              description="- Select Options what to edit from the below select menu.\n\nMust edit embed title & description to remove these instructions.", 
                              color=0x000000)
        interaction_user = ctx.author

        def chk(m):
            return m.channel.id == ctx.channel.id and m.author.id == ctx.author.id and not m.author.bot

        async def select_callback(interaction, value):
            if interaction.user.id != interaction_user.id:
                await interaction.response.send_message("Uh oh! That message doesn't belong to you.\nYou must run this command to interact with it.", ephemeral=True)
                return

            await interaction.response.defer()

            if value == "Title":
                await ctx.send("Please enter the **Title of the embed**:")
                try:
                    tit = await ctx.bot.wait_for("message", timeout=30, check=chk)
                    embed.title = tit.content
                    await msg.edit(embed=embed)
                except asyncio.TimeoutError:
                    await ctx.send("Timed Out")
            elif value == "Description":
                await ctx.send("Please enter the **Description of the embed**:")
                try:
                    desc = await ctx.bot.wait_for("message", timeout=30, check=chk)
                    embed.description = desc.content
                    await msg.edit(embed=embed)
                except asyncio.TimeoutError:
                    await ctx.send("Timed Out")
            elif value == "Color":
                await ctx.send("Please enter the color of the embed as a hexadecimal value (e.g., #FF0000 for red):")
                try:
                    col = await ctx.bot.wait_for("message", timeout=30, check=chk)
                    color = discord.Colour(int(col.content.strip("#"), 16))  # hex se int
                    embed._colour = color
                    await msg.edit(embed=embed)
                except ValueError:
                    await ctx.send("Invalid color format. Please retry with a valid hexadecimal color value.")
                except asyncio.TimeoutError:
                    await ctx.send("Timed Out")
            elif value == "Thumbnail":
                await ctx.send("Please enter the **URL of the thumbnail:**")
                try:
                    thumb = await ctx.bot.wait_for("message", timeout=30, check=chk)
                    if not thumb.content.startswith("http"):
                        raise ValueError("Invalid URL format")
                    embed.set_thumbnail(url=thumb.content)
                    await msg.edit(embed=embed)
                except ValueError as e:
                    await ctx.send(str(e))
                except asyncio.TimeoutError:
                    await ctx.send("Timed Out")
            elif value == "Image":
                await ctx.send("Please enter the **URL of the image:**")
                try:
                    img = await ctx.bot.wait_for("message", timeout=30, check=chk)
                    if not img.content.startswith("http"):
                        raise ValueError("Invalid URL format")
                    embed.set_image(url=img.content)
                    await msg.edit(embed=embed)
                except ValueError as e:
                    await ctx.send(str(e))
                except asyncio.TimeoutError:
                    await ctx.send("Timed Out")
            elif value == "Footer Text":
                await ctx.send("Please enter the **text of the footer:**")
                try:
                    foot = await ctx.bot.wait_for("message", timeout=30, check=chk)
                    embed.set_footer(text=foot.content)
                    await msg.edit(embed=embed)
                except asyncio.TimeoutError:
                    await ctx.send("Timed Out")
            elif value == "Footer Icon":
                await ctx.send("Please enter the **URL of the footer icon:**")
                try:
                    foot_icon = await ctx.bot.wait_for("message", timeout=30, check=chk)
                    if not foot_icon.content.startswith("http"):
                        raise ValueError("Invalid URL format")
                    embed.set_footer(text=embed.footer.text or "Footer", icon_url=foot_icon.content)
                    await msg.edit(embed=embed)
                except ValueError as e:
                    await ctx.send(str(e))
                except asyncio.TimeoutError:
                    await ctx.send("Timed Out")
            elif value == "Author Text":
                await ctx.send("Please enter the **author text:**")
                try:
                    auth_text = await ctx.bot.wait_for("message", timeout=30, check=chk)
                    embed.set_author(name=auth_text.content)
                    await msg.edit(embed=embed)
                except asyncio.TimeoutError:
                    await ctx.send("Timed Out")
            elif value == "Author Icon":
                await ctx.send("Please enter the **URL of the author icon:**")
                try:
                    auth_icon = await ctx.bot.wait_for("message", timeout=30, check=chk)
                    if not auth_icon.content.startswith("http"):
                        raise ValueError("Invalid URL format")
                    embed.set_author(name=embed.author.name or "Author", icon_url=auth_icon.content)
                    await msg.edit(embed=embed)
                except ValueError as e:
                    await ctx.send(str(e))
                except asyncio.TimeoutError:
                    await ctx.send("Timed Out")
            elif value == "Add Field":
                await ctx.send("**Enter Field title:**")
                try:
                    name = await ctx.bot.wait_for("message", timeout=30, check=chk)
                    await ctx.send("**Enter Field value:**")
                    value = await ctx.bot.wait_for("message", timeout=30, check=chk)
                    embed.add_field(name=name.content, value=value.content, inline=False)
                    await msg.edit(embed=embed)
                except asyncio.TimeoutError:
                    await ctx.send("Timed Out")

        options = ["Title", "Description", "Add Field", "Color", "Thumbnail", 
                   "Image", "Footer Text", "Footer Icon", "Author Text", "Author Icon"]
        edit_buttons = []
        for opt in options:
            btn = Button(label=opt, style=discord.ButtonStyle.secondary)
            def make_callback(val):
                async def cb(interaction):
                    await select_callback(interaction, val)
                return cb
            btn.callback = make_callback(opt)
            edit_buttons.append(btn)

        async def send_callback(interaction):
            if interaction.user.id != interaction_user.id:
                await interaction.response.send_message("Uh oh! That message doesn't belong to you.\nYou must run this command to interact with it.", ephemeral=True)
                return
            await interaction.response.defer()
            await ctx.send("Please mention the **channel** where you want to send this embed:")
            try:
                tit = await ctx.bot.wait_for("message", timeout=30, check=chk)
                chnl = tit.channel_mentions[0]

                # Format variables before sending
                placeholders = {
                    "user": ctx.author.mention,
                    "user_avatar": ctx.author.avatar.url if ctx.author.avatar else ctx.author.default_avatar.url,
                    "user_name": ctx.author.name,
                    "user_id": ctx.author.id,
                    "user_nick": ctx.author.display_name,
                    "user_joindate": ctx.author.joined_at.strftime("%a, %b %d, %Y") if hasattr(ctx.author, 'joined_at') and ctx.author.joined_at else "Unknown",
                    "user_createdate": ctx.author.created_at.strftime("%a, %b %d, %Y"),
                    "server_name": ctx.guild.name,
                    "server_id": ctx.guild.id,
                    "server_membercount": ctx.guild.member_count,
                    "server_icon": ctx.guild.icon.url if ctx.guild.icon else "https://cdn.discordapp.com/embed/avatars/0.png",
                    "timestamp": discord.utils.format_dt(ctx.message.created_at)
                }

                def safe_format(text):
                    if not text: return text
                    placeholders_lower = {k.lower(): v for k, v in placeholders.items()}
                    def replace_var(match):
                        var_name = match.group(1).lower()
                        return str(placeholders_lower.get(var_name, f"{{{var_name}}}"))
                    return re.sub(r"\{(\w+)\}", replace_var, text)

                final_embed = discord.Embed(
                    title=safe_format(embed.title),
                    description=safe_format(embed.description)
                )
                final_embed._colour = embed._colour
                if embed.footer and embed.footer.text:
                    final_embed.set_footer(text=safe_format(embed.footer.text), icon_url=safe_format(embed.footer.icon_url))
                if embed.author and embed.author.name:
                    final_embed.set_author(name=safe_format(embed.author.name), icon_url=safe_format(embed.author.icon_url))
                if embed.thumbnail and embed.thumbnail.url:
                    final_embed.set_thumbnail(url=safe_format(embed.thumbnail.url))
                if embed.image and embed.image.url:
                    final_embed.set_image(url=safe_format(embed.image.url))
                for field in embed.fields:
                    final_embed.add_field(name=safe_format(field.name), value=safe_format(field.value), inline=field.inline)

                await chnl.send(embed=final_embed)
                await ctx.send(embed=discord.Embed(title=f"{emojis.TICK} Success",
                                                   description="Sent the embed message to the mentioned channel",
                                                   color=0x000000))
            except asyncio.TimeoutError:
                await ctx.send("Timed Out")

        async def delete_callback(interaction):
            if interaction.user.id != interaction_user.id:
                await interaction.response.send_message("Uh oh! That message doesn't belong to you.\nYou must run this command to interact with it.", ephemeral=True)
                return
            await interaction.response.defer()
            await msg.delete()

        button_send = Button(label="Send Embed",  emoji=f"{emojis.TICK}", style=discord.ButtonStyle.success)
        button_send.callback = send_callback

        button_delete = Button(label="Cancel Setup",  emoji=f"{emojis.CROSSICON}", style=discord.ButtonStyle.danger)
        button_delete.callback = delete_callback

        view = View(timeout=180)
        for btn in edit_buttons:
            view.add_item(btn)
        view.add_item(button_send)
        view.add_item(button_delete)
        view.add_item(VariableButton(ctx.author))

        msg = await ctx.send(embed=embed, view=view)
        ctx.message = msg



