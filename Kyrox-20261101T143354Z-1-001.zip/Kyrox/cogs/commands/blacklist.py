from utils.database import get_collection
from utils import emojis

import asyncio
import discord
from discord.ext import commands
from discord.ext import menus
import os
from utils.Tools import *
from typing import Union
from utils.paginator import Paginator
from utils.cv2_compat import embed_to_view, embeds_to_view

 
class BlacklistWordSource(menus.ListPageSource):
    def __init__(self, data):
        super().__init__(data, per_page=4)

    async def format_page(self, menu, entries):
        embed = discord.Embed(
            title="Blacklist Word [7]",
            description="< > Duty | [ ] Optional",
            color=0x000000
        )
        for entry in entries:
            embed.add_field(name="",value=entry, inline=False)

        embed.set_footer(
            text='Users having Administrator can use Blacklisted Word',
            icon_url="https://cdn.discordapp.com/emojis/1238637578840969289.png?width=115&height=115"
        )
        return embed


DB_PATH = "blword.db"

 
async def create_blacklist_table():
    pass


async def create_bypass_table():
    pass


async def create_bypass_roles_table():
    pass


async def initialize_blacklist_tables() -> None:
    pass


class Blacklist(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    async def cog_load(self) -> None:
        await initialize_blacklist_tables()
        
############ FUNCTIONS ############
    async def is_word_blacklisted(self, guild_id, word):
        col = await get_collection('blacklist')
        return await col.find_one({"guild_id": guild_id, "word": word}) is not None
                

    async def add_word_to_blacklist(self, guild_id, word):
        col = await get_collection('blacklist')
        await col.update_one({"guild_id": guild_id, "word": word}, {"$set": {}}, upsert=True)
            

    async def remove_word_from_blacklist(self, guild_id, word):
        col = await get_collection('blacklist')
        await col.delete_many({"guild_id": guild_id, "word": word})
            

    async def get_blacklisted_words(self, guild_id):
        col = await get_collection('blacklist')
        docs = await col.find({"guild_id": guild_id}).to_list(length=None)
        return [doc["word"] for doc in docs]
                

    async def is_user_bypassed(self, guild_id, user_id):
        col = await get_collection('bypass')
        return await col.find_one({"guild_id": guild_id, "user_id": user_id}) is not None
                

    async def add_user_to_bypass(self, guild_id, user_id):
        col = await get_collection('bypass')
        await col.update_one({"guild_id": guild_id, "user_id": user_id}, {"$set": {}}, upsert=True)
            

    async def remove_user_from_bypass(self, guild_id, user_id):
        col = await get_collection('bypass')
        await col.delete_many({"guild_id": guild_id, "user_id": user_id})
            

    async def get_bypassed_users(self, guild_id):
        col = await get_collection('bypass')
        docs = await col.find({"guild_id": guild_id}).to_list(length=None)
        return [doc["user_id"] for doc in docs]
                

    async def is_role_bypassed(self, guild_id, role_id):
        col = await get_collection('bypass_roles')
        return await col.find_one({"guild_id": guild_id, "role_id": role_id}) is not None
                

    async def add_role_to_bypass(self, guild_id, role_id):
        col = await get_collection('bypass_roles')
        await col.update_one({"guild_id": guild_id, "role_id": role_id}, {"$set": {}}, upsert=True)
            

    async def remove_role_from_bypass(self, guild_id, role_id):
        col = await get_collection('bypass_roles')
        await col.delete_many({"guild_id": guild_id, "role_id": role_id})
            

    async def get_bypassed_roles(self, guild_id):
        col = await get_collection('bypass_roles')
        docs = await col.find({"guild_id": guild_id}).to_list(length=None)
        return [doc["role_id"] for doc in docs]


    async def remove_all_words_from_blacklist(self, guild_id):
        col = await get_collection('blacklist')
        await col.delete_many({"guild_id": guild_id})

    @commands.Cog.listener()
    async def on_message(self, message):
        if message.author.bot:
            return

        guild_id = str(message.guild.id)
        words = await self.get_blacklisted_words(guild_id)
        bypassed_users = await self.get_bypassed_users(guild_id)
        bypassed_roles = await self.get_bypassed_roles(guild_id)

        if message.author.guild_permissions.administrator or message.author.id in bypassed_users:
            return

        for role in message.author.roles:
            if role.id in bypassed_roles:
                return

        for word in words:
            if word in message.content.lower():
                await message.delete()
                warning_message = await message.channel.send(
                    f"{message.author.mention} watch your language, your message contains a blacklisted word!"
                )
                await warning_message.delete(delay=3)
                break

    @commands.group(name="blacklistword", aliases=["blword"], invoke_without_command=True)
    @blacklist_check()
    @ignore_check()
    @commands.cooldown(1, 3, commands.BucketType.user)
    async def blacklistword(self, ctx):
        commands_list = [
            "➜ `blacklistword add <word>` - Add a word to the blacklist.",
            "➜ `blacklistword remove <word>` - Remove a word from the blacklist.",
            "➜ `blacklistword reset` - Clear all blacklisted words for the guild.",
            "➜ `blacklistword config` - Show the list of blacklisted words for the guild.",
            "➜ `blacklistword bypass add <role>/<user>` - Add a role/user to the bypass list.",
            "➜ `blacklistword bypass remove <role>/<user>` - Remove a role/user from the bypass list.",
            "➜ `blacklistword bypass list` - Show the list of bypassed roles/users."
        ]

        paginator = Paginator(
            source=BlacklistWordSource(commands_list),
            ctx=ctx
        )

        await paginator.paginate()
    @blacklistword.command(name="add")
    @blacklist_check()
    @ignore_check()
    @commands.cooldown(1, 5, commands.BucketType.user)
    @commands.has_permissions(administrator=True)
    async def add(self, ctx, word: str):
        guild_id = str(ctx.guild.id)
        if len(await self.get_blacklisted_words(guild_id)) >= 30:
            await ctx.reply("The blacklist is full. Maximum 30 words allowed.")
            return
        if await self.is_word_blacklisted(guild_id, word.lower()):
            embed = discord.Embed(title=f"{emojis.CROSSICON} Access Denied",
                description=f"`{word}` is already in the blacklist.",
                color=discord.Color.from_rgb(0, 0, 0)
            )
            await ctx.reply(view = embed_to_view(embed))
            return

        await self.add_word_to_blacklist(guild_id, word.lower())
        embed = discord.Embed(title=f"{emojis.TICK}Success",
            description=f"Added `{word}` to the blacklist.",
            color=discord.Color.from_rgb(0, 0, 0)
        )
        await ctx.reply(view = embed_to_view(embed))

    @blacklistword.command(name="remove")
    @blacklist_check()
    @ignore_check()
    @commands.cooldown(1, 5, commands.BucketType.user)
    @commands.has_permissions(administrator=True)
    async def remove(self, ctx, word: str):
        guild_id = str(ctx.guild.id)
        if not await self.is_word_blacklisted(guild_id, word.lower()):
            embed = discord.Embed(title=f"{emojis.CROSSICON} Error",
                description=f"`{word}` is not in the blacklist.",
                color=discord.Color.from_rgb(0, 0, 0)
            )
            await ctx.reply(view = embed_to_view(embed))
            return

        await self.remove_word_from_blacklist(guild_id, word.lower())
        embed = discord.Embed(title=f"{emojis.TICK}Success",
            description=f"Removed `{word}` from the blacklist.",
            color=discord.Color.from_rgb(0, 0, 0)
        )
        await ctx.reply(view = embed_to_view(embed))

    @blacklistword.command(name="reset")
    @blacklist_check()
    @ignore_check()
    @commands.cooldown(1, 5, commands.BucketType.user)
    @commands.has_permissions(administrator=True)
    async def reset(self, ctx):
        guild_id = str(ctx.guild.id)
        words = await self.get_blacklisted_words(guild_id)

        if not words:
            embed = discord.Embed(title=f"{emojis.CROSSICON} Error",
                description="No words are currently blacklisted.",
                color=discord.Color.from_rgb(0, 0, 0)
            )
            await ctx.reply(view = embed_to_view(embed))
            return

        await self.remove_all_words_from_blacklist(guild_id)

        embed = discord.Embed(title=f"{emojis.TICK}Success",
            description="Cleared all blacklisted words.",
            color=discord.Color.from_rgb(0, 0, 0)
        )
        await ctx.reply(view = embed_to_view(embed))


    @blacklistword.command(name="config")
    @blacklist_check()
    @ignore_check()
    @commands.cooldown(1, 5, commands.BucketType.user)
    @commands.has_permissions(administrator=True)
    async def config(self, ctx):
        guild_id = str(ctx.guild.id)
        words = await self.get_blacklisted_words(guild_id)
        if not words:
            embed = discord.Embed(title=f"{emojis.CROSSICON} Error",
                description="No words are currently blacklisted.",
                color=discord.Color.from_rgb(0, 0, 0)
            )
            await ctx.reply(view = embed_to_view(embed))
            return

        embed = discord.Embed(
            title=f"Blacklisted Words for {ctx.guild.name}",
            description="\n".join(words),
            color=discord.Color.from_rgb(0, 0, 0)
        )
        await ctx.reply(view = embed_to_view(embed))

    @blacklistword.group(name="bypass", invoke_without_command=True)
    @blacklist_check()
    @ignore_check()
    @commands.cooldown(1, 5, commands.BucketType.user)
    @commands.has_permissions(administrator=True)
    async def bypass(self, ctx):
        embed = discord.Embed(
            title="Bypass User Commands",
            description=(
                "➜ `blacklistword bypass add <role>/<user>` - Add a role/user to the bypass list.\n\n"
                "➜ `blacklistword bypass remove <role>/<user>` - Remove a role/user from the bypass list.\n\n"
                "➜ `blacklistword bypass list` - Show the list of bypassed roles/users."
            ),
            color=discord.Color.from_rgb(0, 0, 0)
        )
        await ctx.send(view = embed_to_view(embed))


    @bypass.command(name="add")
    @blacklist_check()
    @ignore_check()
    @commands.cooldown(1, 5, commands.BucketType.user)
    @commands.has_permissions(administrator=True)
    async def bypass_add(self, ctx, target: Union[discord.Member, discord.Role]):
        guild_id = str(ctx.guild.id)
        if isinstance(target, discord.Member):
            if len(await self.get_bypassed_users(guild_id)) >= 30:
                await ctx.reply("The bypass list for users is full. Maximum 30 users allowed.")
                return
            if await self.is_user_bypassed(guild_id, target.id):
                embed = discord.Embed(
                    description=f"{emojis.CROSSICON} | `{target}` is already bypassed.",
                    color=discord.Color.from_rgb(0, 0, 0)
                )
                await ctx.reply(view = embed_to_view(embed))
                return
            await self.add_user_to_bypass(guild_id, target.id)
            embed = discord.Embed(title=f"{emojis.TICK}Success",
                description=f"Added `{target}` to the bypass list.",
                color=discord.Color.from_rgb(0, 0, 0)
            )
            await ctx.reply(view = embed_to_view(embed))

        elif isinstance(target, discord.Role):
            if len(await self.get_bypassed_roles(guild_id)) >= 30:
                await ctx.reply("The bypass list for roles is full. Maximum 30 roles allowed.")
                return
            if await self.is_role_bypassed(guild_id, target.id):
                embed = discord.Embed(title=f"{emojis.CROSSICON} Error",
                    description=f"`{target}` is already bypassed.",
                    color=discord.Color.from_rgb(0, 0, 0)
                )
                await ctx.reply(view = embed_to_view(embed))
                return
            await self.add_role_to_bypass(guild_id, target.id)
            embed = discord.Embed(title=f"{emojis.TICK}Success",
                description=f"Added `{target}` to the bypass list.",
                color=discord.Color.from_rgb(0, 0, 0)
            )
            await ctx.reply(view = embed_to_view(embed))


    
    @bypass.command(name="remove")
    @blacklist_check()
    @ignore_check()
    @commands.cooldown(1, 5, commands.BucketType.user)
    @commands.has_permissions(administrator=True)
    async def bypass_remove(self, ctx, target: Union[discord.Member, discord.Role]):
        guild_id = str(ctx.guild.id)
        if isinstance(target, discord.Member):
            if not await self.is_user_bypassed(guild_id, target.id):
                embed = discord.Embed(title=f"{emojis.CROSSICON} Error",
                    description=f"`{target}` is not bypassed.",
                    color=discord.Color.from_rgb(0, 0, 0)
                )
                await ctx.reply(view = embed_to_view(embed))
                return
            await self.remove_user_from_bypass(guild_id, target.id)
            embed = discord.Embed(title=f"{emojis.TICK}Success",
                description=f"Removed `{target}` from the bypass list.",
                color=discord.Color.from_rgb(0, 0, 0)
            )
            await ctx.reply(view = embed_to_view(embed))

        elif isinstance(target, discord.Role):
            if not await self.is_role_bypassed(guild_id, target.id):
                embed = discord.Embed(title=f"{emojis.CROSSICON} Error",
                    description=f"`{target}` is not bypassed.",
                    color=discord.Color.from_rgb(0, 0, 0)
                )
                await ctx.reply(view = embed_to_view(embed))
                return
            await self.remove_role_from_bypass(guild_id, target.id)
            embed = discord.Embed(title=f"{emojis.TICK}Success",
                description=f"Removed `{target}` from the bypass list.",
                color=discord.Color.from_rgb(0, 0, 0)
            )
            await ctx.reply(view = embed_to_view(embed))

    @bypass.command(name="list")
    @blacklist_check()
    @ignore_check()
    @commands.cooldown(1, 5, commands.BucketType.user)
    @commands.has_permissions(administrator=True)
    async def bypass_list(self, ctx):
        guild_id = str(ctx.guild.id)
        users = await self.get_bypassed_users(guild_id)
        roles = await self.get_bypassed_roles(guild_id)

        if not users and not roles:
            embed = discord.Embed(title=f"{emojis.CROSSICON} Error",
                description="No users or roles are currently bypassed.",
                color=discord.Color.from_rgb(0, 0, 0)
            )
            await ctx.send(view = embed_to_view(embed))
            return

        bypassed_users = [ctx.guild.get_member(user_id) for user_id in users if ctx.guild.get_member(user_id)]
        bypassed_roles = [ctx.guild.get_role(role_id) for role_id in roles if ctx.guild.get_role(role_id)]
        embed = discord.Embed(
            title=f"Bypassed Users and Roles for {ctx.guild.name}",
            color=discord.Color.from_rgb(0, 0, 0)
        )

        if bypassed_users:
            embed.add_field(name="Users", value=", ".join([user.name for user in bypassed_users]), inline=False)

        if bypassed_roles:
            embed.add_field(name="Roles", value=", ".join([role.name for role in bypassed_roles]), inline=False)

        await ctx.send(view = embed_to_view(embed))


    @add.error
    @remove.error
    @reset.error
    @config.error
    @bypass_add.error
    @bypass_remove.error
    async def command_error(self, ctx, error):
        if isinstance(error, commands.CommandError):
            if not isinstance(error, commands.CommandOnCooldown):
                embed = discord.Embed(
                    description=f"{emojis.CROSSICON} | An error occurred while processing the command. Make sure you have **Administrator** permissios.",
                    color=discord.Color.from_rgb(0, 0, 0)
                )
                await ctx.reply(view = embed_to_view(embed))