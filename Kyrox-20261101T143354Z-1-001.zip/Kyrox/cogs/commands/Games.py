import discord
from discord.ext import commands
import os
from core import Cog, Kyrox, Context
import games as games
from utils.Tools import *
from games import button_games as btn
import random
import asyncio



class Games(Cog):
    """Kyrox Games"""

    def __init__(self, client: Kyrox):
        self.client = client


