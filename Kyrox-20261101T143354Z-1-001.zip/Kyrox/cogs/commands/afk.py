from utils.database import get_collection
from utils import emojis
from utils.components_v2 import success_panel, error_panel, container, text, separator, action_row

import asyncio
import discord
from discord.ext import commands
import os
import time
from typing import Optional
from utils.Tools import *
from utils.cv2_compat import embed_to_view, embeds_to_view

black1 = 0
black2 = 0
black3 = 0



class BasicView(discord.ui.View):
    def __init__(self, ctx: commands.Context, timeout: Optional[int] = None):
        super().__init__(timeout=timeout)
        self.ctx = ctx

    async def interaction_check(self, interaction: discord.Interaction):
        if interaction.user.id != self.ctx.author.id:
            await interaction.response.send_message(
                view=error_panel(f"Only **{self.ctx.author}** can use this command. Use {self.ctx.prefix}**{self.ctx.command}** to run the command"),
                ephemeral=True,
            )
            return False
        return True


class afk(commands.Cog):

    def __init__(self, client, *args, **kwargs):
        self.client = client

    async def cog_load(self) -> None:
        pass



    async def cog_after_invoke(self, ctx):
        ctx.command.reset_cooldown(ctx)

    async def update_data(self, user, guild_id):
        col_afk = await get_collection('afk')
        if not await col_afk.find_one({"user_id": user.id}):
            await col_afk.insert_one({"user_id": user.id, "AFK": "False", "reason": "None", "time": 0, "mentions": 0, "dm": "False"})
        
        col_guild = await get_collection('afk_guild')
        if not await col_guild.find_one({"user_id": user.id, "guild_id": guild_id}):
            await col_guild.insert_one({"user_id": user.id, "guild_id": guild_id})

    async def time_formatter(self, seconds: float):
        minutes, seconds = divmod(int(seconds), 60)
        hours, minutes = divmod(minutes, 60)
        days, hours = divmod(hours, 24)
        tmp = ((str(days) + " days, ") if days else "") + \
              ((str(hours) + " hours, ") if hours else "") + \
              ((str(minutes) + " minutes, ") if minutes else "") + \
              ((str(seconds) + " seconds, ") if seconds else "")
        return tmp[:-2]

    @commands.Cog.listener()
    async def on_message(self, message):
        try:
            if message.author.bot or message.guild is None:
                return

            col_afk = await get_collection('afk')
            afk_doc = await col_afk.find_one({"user_id": message.author.id})
            afk_data = (afk_doc["AFK"], afk_doc["time"], afk_doc["mentions"], afk_doc["reason"]) if afk_doc else None

            if afk_data and afk_data[0] == 'True':
                col_guild = await get_collection('afk_guild')
                docs = await col_guild.find({"user_id": message.author.id}).to_list(length=None)
                guild_ids = [d["guild_id"] for d in docs]

                if message.guild.id in guild_ids or 0 in guild_ids:
                    meth = int(time.time()) - int(afk_data[1])
                    been_afk_for = await self.time_formatter(meth)
                    mentionz = afk_data[2]
                    await col_afk.update_one({"user_id": message.author.id}, {"$set": {"AFK": "False", "reason": "None"}})
                    if 0 in guild_ids:
                        await col_guild.delete_many({"user_id": message.author.id, "guild_id": 0})
                    else:
                        await col_guild.delete_many({"user_id": message.author.id, "guild_id": message.guild.id})
                    wlbat = discord.Embed(
                        description=f"Welcome back, {message.author.mention}. AFK removed\n You were away since `{been_afk_for or '0 seconds'}` | `{mentionz}` mentions"
                    )
                    try:
                        if mentionz > 0:
                            class PingsView(discord.ui.View):
                                def __init__(self, user_id):
                                    super().__init__(timeout=120)
                                    self.user_id = user_id

                                @discord.ui.button(label="Pings", style=discord.ButtonStyle.secondary, custom_id="afk_pings_btn")
                                async def pings_button(self, interaction: discord.Interaction, button: discord.ui.Button):
                                    if interaction.user.id != self.user_id:
                                        return await interaction.response.send_message("This button is not for you.", ephemeral=True)
                                        
                                    col_mentions = await get_collection('afk_mentions')
                                    docs = await col_mentions.find({"user_id": self.user_id}).to_list(length=None)
                                    rows = [(d["author_name"], d["jump_url"], d["time"]) for d in docs]
                                        
                                    if not rows:
                                        return await interaction.response.send_message("No pings found.", ephemeral=True)
                                        
                                    desc = ""
                                    for row in rows:
                                        desc += f"**{row[0]}** mentioned you in [this message]({row[1]}) <t:{row[2]}:R>\n"
                                        
                                    if len(desc) > 4000:
                                        desc = desc[:3990] + "..."
                                        
                                    embed = discord.Embed(title="Your Pings", description=desc, color=discord.Color.blurple())
                                    await interaction.response.send_message(embed=embed, ephemeral=True)
                            
                            view = PingsView(message.author.id)
                            await message.reply(view = embed_to_view(wlbat, view))
                        else:
                            await message.reply(view = embed_to_view(wlbat))
                    except discord.Forbidden:
                        print(f"(AFK module) Missing permissions to send messages in channel: {message.channel.id}")

            if message.mentions:
                col_afk = await get_collection('afk')
                col_guild = await get_collection('afk_guild')
                col_mentions = await get_collection('afk_mentions')
                for user_mention in message.mentions:
                    afk_doc = await col_afk.find_one({"user_id": user_mention.id})
                    afk_data = (afk_doc["AFK"], afk_doc["reason"], afk_doc["time"], afk_doc["mentions"], afk_doc["dm"]) if afk_doc else None

                    if afk_data and afk_data[0] == 'True':
                        docs = await col_guild.find({"user_id": user_mention.id}).to_list(length=None)
                        guild_ids = [d["guild_id"] for d in docs]

                        if message.guild.id in guild_ids or 0 in guild_ids:
                            reason = afk_data[1]
                            ok = afk_data[2]
                            wl = discord.Embed(description=f'**<@{user_mention.id}>** went AFK <t:{ok}:R> \n> **Reason**: {reason}', color=0x0c0606)
                            try:
                                await message.reply(view = embed_to_view(wl))
                            except discord.Forbidden:
                                print(f"(AFK module) Missing permissions to send messages to user: {user_mention.id}")

                            new_mentions = afk_data[3] + 1
                            await col_afk.update_one({"user_id": user_mention.id}, {"$set": {"mentions": new_mentions}})
                            await col_mentions.insert_one({"user_id": user_mention.id, "author_name": str(message.author), "jump_url": message.jump_url, "time": int(time.time())})

                            embed = discord.Embed(description=f'You were mentioned in **{message.guild.name}** by **{message.author}**', color=discord.Color.from_rgb(black1, black2, black3))
                            embed.add_field(name="Total mentions:", value=new_mentions, inline=False)
                            embed.add_field(name="Message:", value=message.content, inline=False)
                            embed.add_field(name="Jump Message:", value=f"[Jump to message]({message.jump_url})", inline=False)

                            if afk_data[4] == 'True':
                                try:
                                    await user_mention.send(view = embed_to_view(embed))
                                except discord.Forbidden:
                                    print(f"(AFK module) Missing permissions to send DMs to user: {user_mention.id}")

            if not message.author.bot:
                await self.update_data(message.author, message.guild.id)
        except Exception as e:
            print(f"Ignoring exception in on_message: {e}")

    @commands.hybrid_command(description="Sets your status as AFK (Away From Keyboard) with global/server scopes.")
    @blacklist_check()
    @ignore_check()
    @commands.guild_only()
    @commands.cooldown(1, 2, commands.BucketType.user)
    async def afk(self, ctx, *, reason=None):
        if not reason:
            reason = "I'm AFK"

        if any(invite in reason.lower() for invite in ['discord.gg', 'gg/']):
            return await ctx.send(view=error_panel(f"{emojis.ICONS_WARNING} | You can't advertise Serve Invite in the AFK reason"))

        header = text("### <a:GF_teddysleep:1526165624152129587> Going AFK?")
        info_text = (
            f"Choose whether you want to set your AFK status globally or only in this server.\n\n"
            f"<a:dorobald:1526165419298132039> **Reason:** `{reason}`"
        )
        footer_text = f"-# requested by {ctx.author.name} • <t:{int(time.time())}:t>"

        class AfkScopeView(discord.ui.LayoutView):
            def __init__(self, ctx, reason):
                super().__init__(timeout=60.0)
                self.ctx = ctx
                self.reason = reason
                self.value = None

                self.cont = container(
                    header,
                    separator(),
                    text(info_text),
                    separator(),
                    text(footer_text)
                )
                self.add_item(self.cont)

                self.global_btn = discord.ui.Button(label='Global AFK', style=discord.ButtonStyle.success)
                self.global_btn.callback = self.global_afk
                
                self.server_btn = discord.ui.Button(label='Server AFK', style=discord.ButtonStyle.primary)
                self.server_btn.callback = self.server_afk

                self.add_item(action_row(self.global_btn, self.server_btn))

            async def interaction_check(self, interaction: discord.Interaction):
                if interaction.user.id != self.ctx.author.id:
                    await interaction.response.send_message(
                        view=error_panel(f"Only **{self.ctx.author}** can use this command. Use {self.ctx.prefix}**{self.ctx.command}** to run the command"),
                        ephemeral=True,
                    )
                    return False
                return True

            async def global_afk(self, interaction: discord.Interaction):
                self.value = 'GLOBAL'
                await interaction.response.defer()
                self.stop()

            async def server_afk(self, interaction: discord.Interaction):
                self.value = 'SERVER'
                await interaction.response.defer()
                self.stop()

        view = AfkScopeView(ctx, reason)
        test = await ctx.reply(view=view, mention_author=False)
        await view.wait()

        if not view.value:
            for item in view.children:
                if isinstance(item, discord.ui.ActionRow):
                    for child in item.children:
                        child.disabled = True
            try:
                await test.edit(view=view)
            except:
                pass
            return
            
        is_global = view.value == 'GLOBAL'
        target_guild_id = 0 if is_global else ctx.guild.id

        col_guild = await get_collection('afk_guild')
        col_afk = await get_collection('afk')
        col_mentions = await get_collection('afk_mentions')
        await col_guild.delete_many({"user_id": ctx.author.id, "guild_id": target_guild_id})
        await col_afk.delete_many({"user_id": ctx.author.id})
        await col_mentions.delete_many({"user_id": ctx.author.id})
        
        await col_afk.update_one({"user_id": ctx.author.id}, {"$set": {"AFK": "True", "reason": reason, "time": int(time.time()), "mentions": 0, "dm": "False"}}, upsert=True)
        await col_guild.update_one({"user_id": ctx.author.id, "guild_id": target_guild_id}, {"$set": {"guild_id": target_guild_id}}, upsert=True)

        success_header = text("### <a:GF_teddysleep:1526165624152129587> AFK Status Set")
        success_info = text(
            f"<a:dorobald:1526165419298132039> **I've set your AFK status {'globally' if is_global else 'in this server'}!** \n\n"
            f"• **Reason:** `{reason}`"
        )
        success_cont = container(
            success_header,
            separator(),
            success_info,
            separator(),
            text(footer_text)
        )
        success_view = discord.ui.LayoutView()
        success_view.add_item(success_cont)
        
        try:
            await test.edit(view=success_view)
        except:
            pass


