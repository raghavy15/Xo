from utils.database import get_collection
from utils import emojis
from utils.components_v2 import success_panel, error_panel, info_panel

import asyncio
import discord
from discord.ext import commands
import os
from utils.Tools import *


class AutoResponder(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    async def cog_load(self) -> None:
        pass

    @commands.group(name="autoresponder", invoke_without_command=True, aliases=['ar'], help="Manage autoresponders in the server.")
    @blacklist_check()
    @ignore_check()
    @commands.cooldown(1, 5, commands.BucketType.user)
    async def _ar(self, ctx):
        if ctx.subcommand_passed is None:
            await ctx.send_help(ctx.command)
            ctx.command.reset_cooldown(ctx)

    @_ar.command(name="create", help="Create a new autoresponder.")
    @blacklist_check()
    @ignore_check()
    @commands.cooldown(1, 5, commands.BucketType.user)
    @commands.has_permissions(administrator=True)
    async def _create(self, ctx, name, *, message):
        name_lower = name.lower()
        col = await get_collection('autoresponder')
        data = await col.find_one({'guild_id': ctx.guild.id})
        
        autoresponses = data.get('autoresponses', {}) if data else {}
        
        if len(autoresponses) >= 20:
            return await ctx.reply(view=error_panel(
                f"You can't add more than 20 autoresponses in {ctx.guild.name}",
                title=f"{emojis.CROSSICON} Error!"
            ))

        if name_lower in autoresponses:
            return await ctx.reply(view=error_panel(
                f"The autoresponse with the name `{name}` already exists in {ctx.guild.name}",
                title=f"{emojis.CROSSICON} Error!"
            ))

        autoresponses[name_lower] = message
        await col.update_one({'guild_id': ctx.guild.id}, {'$set': {'autoresponses': autoresponses}}, upsert=True)
        
        await ctx.reply(view=success_panel(
            f"Created autoresponder `{name}` in {ctx.guild.name}",
            title=f"{emojis.TICK} Success"
        ))

    @_ar.command(name="delete", help="Delete an existing autoresponder.")
    @blacklist_check()
    @ignore_check()
    @commands.cooldown(1, 5, commands.BucketType.user)
    @commands.has_permissions(administrator=True)
    async def _delete(self, ctx, name):
        name_lower = name.lower()
        col = await get_collection('autoresponder')
        data = await col.find_one({'guild_id': ctx.guild.id})
        autoresponses = data.get('autoresponses', {}) if data else {}
        
        if name_lower not in autoresponses:
            return await ctx.reply(view=error_panel(
                f"No autoresponder found with the name `{name}` in {ctx.guild.name}",
                title=f"{emojis.CROSSICON} Error!"
            ))

        del autoresponses[name_lower]
        await col.update_one({'guild_id': ctx.guild.id}, {'$set': {'autoresponses': autoresponses}})
        
        await ctx.reply(view=success_panel(
            f"Deleted autoresponder `{name}` in {ctx.guild.name}",
            title=f"{emojis.TICK} Success"
        ))

    @_ar.command(name="edit", help="Edit an existing autoresponder.")
    @blacklist_check()
    @ignore_check()
    @commands.cooldown(1, 5, commands.BucketType.user)
    @commands.has_permissions(administrator=True)
    async def _edit(self, ctx, name, *, message):
        name_lower = name.lower()
        col = await get_collection('autoresponder')
        data = await col.find_one({'guild_id': ctx.guild.id})
        autoresponses = data.get('autoresponses', {}) if data else {}
        
        if name_lower not in autoresponses:
            return await ctx.reply(view=error_panel(
                f"No autoresponder found with the name `{name}` in {ctx.guild.name}",
                title=f"{emojis.CROSSICON} Error!"
            ))

        autoresponses[name_lower] = message
        await col.update_one({'guild_id': ctx.guild.id}, {'$set': {'autoresponses': autoresponses}})
        
        await ctx.reply(view=success_panel(
            f"Edited autoresponder `{name}` in {ctx.guild.name}",
            title=f"{emojis.TICK} Success"
        ))

    @_ar.command(name="config", help="List all autoresponders in the server.")
    @blacklist_check()
    @ignore_check()
    @commands.cooldown(1, 5, commands.BucketType.user)
    @commands.has_permissions(administrator=True)
    async def _config(self, ctx):
        col = await get_collection('autoresponder')
        data = await col.find_one({'guild_id': ctx.guild.id})
        autoresponses = data.get('autoresponses', {}) if data else {}
        
        if not autoresponses:
            return await ctx.reply(view=info_panel(
                f"There are no autoresponders in {ctx.guild.name}"
            ))

        fields = [(f"Autoresponder [{i}]", name) for i, name in enumerate(autoresponses.keys(), start=1)]
        await ctx.send(view=info_panel(
            "",
            title=f"Autoresponders in {ctx.guild.name}",
            fields=fields
        ))

    @commands.Cog.listener()
    async def on_message(self, message):
        if message.author == self.bot.user:
            return
            
        if not message.guild:
            return

        col = await get_collection('autoresponder')
        data = await col.find_one({'guild_id': message.guild.id})
        if not data:
            return
            
        autoresponses = data.get('autoresponses', {})
        content_lower = message.content.lower()
        
        if content_lower in autoresponses:
            await message.channel.send(autoresponses[content_lower])

async def setup(bot):
    await bot.add_cog(AutoResponder(bot))
