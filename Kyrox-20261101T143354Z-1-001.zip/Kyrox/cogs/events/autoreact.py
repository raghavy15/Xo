from utils.database import get_collection
import discord
from discord.ext import commands
import re
import asyncio

class AutoReactListener(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.rate_limited_users = set()

    async def get_triggers(self, guild_id):
        col = await get_collection('autoreact')
        data = await col.find_one({'guild_id': guild_id})
        return data.get('triggers', {}) if data else {}

    async def add_rate_limit(self, user_id):
        self.rate_limited_users.add(user_id)
        await asyncio.sleep(5)
        if user_id in self.rate_limited_users:
            self.rate_limited_users.remove(user_id)

    @commands.Cog.listener()
    async def on_message(self, message):
        if message.author.bot or not message.guild:
            return

        if message.author.id in self.rate_limited_users:
            return

        triggers = await self.get_triggers(message.guild.id)
        if not triggers:
            return

        content = message.content.strip().lower()
        if content in triggers:
            emojis = triggers[content]
            emoji_list = emojis.split()
            for emoji in emoji_list:
                try:
                    if re.match(r"<a?:\w+:\d+>", emoji):
                        emoji_obj = discord.PartialEmoji.from_str(emoji)
                    else:
                        emoji_obj = emoji

                    await message.add_reaction(emoji_obj)
                except discord.errors.NotFound:
                    continue
                except discord.errors.Forbidden:
                    continue
                except discord.errors.HTTPException:
                    continue
                
            await self.add_rate_limit(message.author.id)

async def setup(bot):
    await bot.add_cog(AutoReactListener(bot))
