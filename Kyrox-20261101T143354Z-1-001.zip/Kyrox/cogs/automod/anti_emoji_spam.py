from utils.database import connect
from utils import emojis

import discord
from discord.ext import commands
import re
from datetime import timedelta
import asyncio
from utils.cv2_compat import embed_to_view, embeds_to_view
from utils.automod_helpers import automod_gate, log_automod_action

class AntiEmojiSpam(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.emoji_threshold = 5  

    async def is_automod_enabled(self, guild_id):
        async with connect('automod.db') as db:
            cursor = await db.execute("SELECT enabled FROM automod WHERE guild_id = ?", (guild_id,))
            result = await cursor.fetchone()
            return result is not None and result[0] == 1

    async def is_anti_emoji_spam_enabled(self, guild_id):
        async with connect('automod.db') as db:
            cursor = await db.execute("SELECT punishment FROM automod_punishments WHERE guild_id = ? AND event = 'Anti emoji spam'", (guild_id,))
            result = await cursor.fetchone()
            return result is not None

    async def get_ignored_channels(self, guild_id):
        async with connect('automod.db') as db:
            cursor = await db.execute("SELECT id FROM automod_ignored WHERE guild_id = ? AND type = 'channel'", (guild_id,))
            return [row[0] for row in await cursor.fetchall()]

    async def get_ignored_roles(self, guild_id):
        async with connect('automod.db') as db:
            cursor = await db.execute("SELECT id FROM automod_ignored WHERE guild_id = ? AND type = 'role'", (guild_id,))
            return [row[0] for row in await cursor.fetchall()]

    async def get_punishment(self, guild_id):
        async with connect('automod.db') as db:
            cursor = await db.execute("SELECT punishment FROM automod_punishments WHERE guild_id = ? AND event = 'Anti emoji spam'", (guild_id,))
            result = await cursor.fetchone()
            return result[0] if result else None

    async def log_action(self, guild, user, channel, action, reason):
        async with connect('automod.db') as db:
            cursor = await db.execute("SELECT log_channel FROM automod_logging WHERE guild_id = ?", (guild.id,))
            log_channel_id = await cursor.fetchone()

        if log_channel_id and log_channel_id[0]:
            log_channel = guild.get_channel(log_channel_id[0])
            if log_channel:
                embed = discord.Embed(title="Automod Log: Anti Emoji Spam", color=0xff0000)
                embed.add_field(name="User", value=user.mention, inline=False)
                embed.add_field(name="Action", value=action, inline=False)
                embed.add_field(name="Channel", value=channel.mention, inline=False)
                embed.add_field(name="Reason", value=reason, inline=False)
                embed.set_footer(text=f"User ID: {user.id}")
                avatar_url = user.avatar.url if user.avatar else user.default_avatar.url
                embed.set_thumbnail(url=avatar_url)
                embed.timestamp=discord.utils.utcnow()
                await log_channel.send(view = embed_to_view(embed))

    @commands.Cog.listener()
    async def on_message(self, message):
        if message.author.bot:
            return

        gate = await automod_gate(message, 'Anti emoji spam')
        if gate is None:
            return

        guild = message.guild
        user = message.author
        channel = message.channel


        
        emoji_pattern = re.compile(
            r"<a?:[a-zA-Z0-9_]+:([0-9]+)>|"  #discord emojis
            r"([\U0001F600-\U0001F64F]|"         # Emoticons 
            r"[\U0001F300-\U0001F5FF]|"         # Miscellaneous Symbols and Pictographs
            r"[\U0001F680-\U0001F6FF]|"         # Transport and Map Symbols
            r"[\U0001F700-\U0001F77F]|"         # Alchemical Symbols
            r"[\U0001F780-\U0001F7FF]|"         # Geometric Shapes Extended
            r"[\U0001F800-\U0001F8FF]|"         # Supplemental Arrows-C
            r"[\U0001F900-\U0001F9FF]|"         # Supplemental Symbols and Pictographs
            r"[\U0001FA00-\U0001FAFF]|"         # Chess Symbols
            r"[\U00002700-\U000027BF]|"         # Miscellaneous Symbols
            r"[\U0001F1E6-\U0001F1FF]|"         # Regional Indicator Symbols
            r"[\U0001F004-\U0001F0CF]|"         # Mahjong Tiles and Playing Cards
            r"[\U0001F9B0-\U0001F9FF]"          # Additional Emoji
            r")"
        )
        

       

        emoji_count = len(emoji_pattern.findall(message.content))

        if emoji_count > self.emoji_threshold:
            punishment = gate.punishment
            action_taken = None
            reason = f"Emoji Spam ({emoji_count} emojis)"

            try:
                if punishment == "Mute":
                    timeout_duration = discord.utils.utcnow() + timedelta(minutes=1)
                    await user.edit(timed_out_until=timeout_duration, reason=reason)
                    action_taken = "Muted for 1 minute"
                elif punishment == "Kick":
                    await user.kick(reason=reason)
                    action_taken = "Kicked"
                elif punishment == "Ban":
                    await user.ban(reason=reason)
                    action_taken = "Banned"

                await message.delete()
                
                simple_embed = discord.Embed(title="Automod Anti Emoji Spam", color=0xff0000)
                simple_embed.description = f"{emojis.TICK} | {user.mention} has been successfully **{action_taken}** for **Spamming Emojis.**"
                
                simple_embed.set_footer(text="Use the “automod logging” command to get automod logs if it is not enabled.", icon_url=self.bot.user.display_avatar.url)
                await channel.send(view = embed_to_view(simple_embed), delete_after=30)

                
                await log_automod_action(
                    guild, user, channel, action_taken, reason,
                    title='Automod Log: Anti emoji spam',
                    log_channel_id=gate.log_channel_id,
                )

            except discord.Forbidden:
                pass
            except discord.HTTPException:
                pass
            except Exception:
                pass

    @commands.Cog.listener()
    async def on_rate_limit(self, message):
        await asyncio.sleep(10)

