﻿from utils import emojis

import discord
from discord.ext import commands
from discord import ui
from utils.Tools import bot_has_permissions
from utils.cv2_compat import embed_to_view, embeds_to_view, sync_panel_message

class LockUnlockView(ui.View):
    def __init__(self, channel, author, ctx):
        super().__init__(timeout=120)
        self.channel = channel
        self.author = author
        self.ctx = ctx  
        self.message = None  

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user != self.author:
            await interaction.response.send_message("You are not allowed to interact with this!", ephemeral=True)
            return False
        return True

    async def on_timeout(self):
        await sync_panel_message(self, skip_labels=("Delete",))

    @ui.button(label="Unlock", style=discord.ButtonStyle.success)
    async def unlock(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self.channel.set_permissions(interaction.guild.default_role, send_messages=True)
        await interaction.response.send_message(f"{self.channel.mention} has been unlocked.", ephemeral=True)

        embed = discord.Embed(
            description=f"{emojis.ICONS_CHANNEL} **Channel**: {self.channel.mention}\n{emojis.TICK} **Status**: Unlocked\n{emojis.COMMANDS}**Reason:** Unlock request by {self.author}",
            color=0x000000
        )
        embed.add_field(name=f"{emojis.OLYMPUS_STAFF} **Moderator:**", value=self.ctx.author.mention, inline=False)
        embed.set_author(name=f"Successfully Unlocked {self.channel.name}")
        await self.message.edit(view = embed_to_view(embed, view = self))

        await sync_panel_message(self, skip_labels=("Delete",))

    @ui.button(style=discord.ButtonStyle.gray, emoji=f"{emojis.DELETE}")
    async def delete(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.message.delete()


class Lock(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.color = discord.Color.from_rgb(0, 0, 0)

    @commands.hybrid_command(
        name="lock",
        help="Locks a channel to prevent sending messages.",
        usage="lock <channel>",
        aliases=["lockchannel"])
    @commands.has_permissions(manage_roles=True)
    @bot_has_permissions(manage_roles=True)
    async def lock_command(self, ctx, channel: discord.TextChannel = None):
        channel = channel or ctx.channel 
        if channel.permissions_for(ctx.guild.default_role).send_messages is False:
            embed = discord.Embed(
                description=f"**{emojis.ICONS_CHANNEL} Channel**: {channel.mention}\n{emojis.TICK} **Status**: Already Locked",
                color=self.color
            )
            embed.set_author(name=f"{channel.name} is Already Locked")
            embed.set_footer(text=f"Requested by {ctx.author}", icon_url=ctx.author.avatar.url)
            view = LockUnlockView(channel=channel, author=ctx.author, ctx=ctx)  
            message = await ctx.send(view = embed_to_view(embed, view = view))
            view.message = message
            return

        await channel.set_permissions(ctx.guild.default_role, send_messages=False)

        embed = discord.Embed(
            description=f"{emojis.ICONS_CHANNEL} **Channel**: {channel.mention}\n{emojis.TICK} **Status**: Locked\n{emojis.COMMANDS} **Reason:** Lock request by {ctx.author}",
            color=self.color
        )
        embed.add_field(name=f"{emojis.U_ADMIN} **Moderator:**", value=ctx.author.mention, inline=False)
        embed.set_author(name=f"Successfully Locked {channel.name}")
        embed.set_footer(text=f"Requested by {ctx.author}", icon_url=ctx.author.avatar.url)
        view = LockUnlockView(channel=channel, author=ctx.author, ctx=ctx)  
        message = await ctx.send(view = embed_to_view(embed, view = view))
        view.message = message



