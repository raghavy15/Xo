from utils import emojis

import discord
from discord.ext import commands, tasks
import asyncio
import datetime
import re
from typing import *
from utils.Tools import *
from discord.ui import Button, View
from typing import Union, Optional
from typing import Union, Optional
from io import BytesIO
import requests
import aiohttp
import time
from datetime import datetime, timezone, timedelta


time_regex = re.compile(r"(?:(\d{1,5})(h|s|m|d))+?")
time_dict = {"h": 3600, "s": 1, "m": 60, "d": 86400}


def convert(argument):
  args = argument.lower()
  matches = re.findall(time_regex, args)
  time = 0
  for key, value in matches:
    try:
      time += time_dict[value] * float(key)
    except KeyError:
      raise commands.BadArgument(
        f"{value} is an invalid time key! h|m|s|d are valid arguments")
    except ValueError:
      raise commands.BadArgument(f"{key} is not a number!")
  return round(time)

async def do_removal(ctx, limit, predicate, *, before=None, after=None):
  if limit > 2000:
      return await ctx.error(f"Too many messages to search given ({limit}/2000)")

  if before is None:
      before = ctx.message
  else:
      before = discord.Object(id=before)

  if after is not None:
      after = discord.Object(id=after)

  try:
      deleted = await ctx.channel.purge(limit=limit, before=before, after=after, check=predicate)
  except discord.Forbidden as e:
      return await ctx.error("I do not have permissions to delete messages.")
  except discord.HTTPException as e:
      return await ctx.error(f"Error: {e} (try a smaller search?)")

  spammers = Counter(m.author.display_name for m in deleted)
  deleted = len(deleted)
  messages = [f'{emojis.TICK} | {deleted} message{" was" if deleted == 1 else "s were"} removed.']
  if deleted:
      messages.append("")
      spammers = sorted(spammers.items(), key=lambda t: t[1], reverse=True)
      messages.extend(f"**{name}**: {count}" for name, count in spammers)

  to_send = "\n".join(messages)

  if len(to_send) > 2000:
      await ctx.send(f"{emojis.TICK} | Successfully removed {deleted} messages.", delete_after=7)
  else:
      await ctx.send(to_send, delete_after=7)
    

class Message(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.color = 0x000000

    @commands.group(invoke_without_command=True, name="purge", aliases=["clear", "c"], help="Purge messages from the channel.")
    @commands.has_permissions(manage_messages=True)
    @bot_has_permissions(manage_messages=True)
    @blacklist_check()
    @ignore_check()
    async def purge(self, ctx, limit: int = None):
        """Purge messages"""
        if limit is None:
            return await ctx.send_help(ctx.command)
            
        await ctx.message.delete(delay=0)
        await do_removal(ctx, limit, lambda e: True)

    @purge.command(name="user", help="Purge messages from a specific user.", aliases=["member"])
    @commands.has_permissions(manage_messages=True)
    @bot_has_permissions(manage_messages=True)
    @blacklist_check()
    @ignore_check()
    async def purge_user(self, ctx, member: discord.Member, limit: int = 10):
        """Purge messages from a specific user"""
        await ctx.message.delete(delay=0)
        await do_removal(ctx, limit, lambda e: e.author == member)

    @purge.command(name="bot", help="Purge messages from bots.", aliases=["bots"])
    @commands.has_permissions(manage_messages=True)
    @bot_has_permissions(manage_messages=True)
    @blacklist_check()
    @ignore_check()
    async def purge_bot(self, ctx, limit: int = 10):
        """Purge messages from bots"""
        await ctx.message.delete(delay=0)
        await do_removal(ctx, limit, lambda e: e.author.bot)

    @purge.command(name="embeds", help="Purge messages with embeds.", aliases=["embed"])
    @commands.has_permissions(manage_messages=True)
    @bot_has_permissions(manage_messages=True)
    @blacklist_check()
    @ignore_check()
    async def purge_embeds(self, ctx, limit: int = 10):
        """Purge messages with embeds"""
        await ctx.message.delete(delay=0)
        await do_removal(ctx, limit, lambda e: len(e.embeds) > 0)

    @purge.command(name="files", help="Purge messages with attachments.", aliases=["file", "attachments", "attachment"])
    @commands.has_permissions(manage_messages=True)
    @bot_has_permissions(manage_messages=True)
    @blacklist_check()
    @ignore_check()
    async def purge_files(self, ctx, limit: int = 10):
        """Purge messages with attachments"""
        await ctx.message.delete(delay=0)
        await do_removal(ctx, limit, lambda e: len(e.attachments) > 0)

    @purge.command(name="links", help="Purge messages with links.", aliases=["link"])
    @commands.has_permissions(manage_messages=True)
    @bot_has_permissions(manage_messages=True)
    @blacklist_check()
    @ignore_check()
    async def purge_links(self, ctx, limit: int = 10):
        """Purge messages with links"""
        await ctx.message.delete(delay=0)
        url_regex = re.compile(r"http[s]?://(?:[a-zA-Z]|[0-9]|[$-_@.&+]|[!*\\(\\),]|(?:%[0-9a-fA-F][0-9a-fA-F]))+")
        await do_removal(ctx, limit, lambda e: url_regex.search(e.content))

    @purge.command(name="mentions", help="Purge messages with user/role mentions.", aliases=["mention"])
    @commands.has_permissions(manage_messages=True)
    @bot_has_permissions(manage_messages=True)
    @blacklist_check()
    @ignore_check()
    async def purge_mentions(self, ctx, limit: int = 10):
        """Purge messages with mentions"""
        await ctx.message.delete(delay=0)
        await do_removal(ctx, limit, lambda e: len(e.mentions) > 0 or len(e.role_mentions) > 0)

async def setup(bot):
    await bot.add_cog(Message(bot))


