﻿from utils import emojis

import discord
from discord.ext import commands
from discord import ui
from utils.Tools import bot_has_permissions
from utils.cv2_compat import embed_to_view, embeds_to_view, sync_panel_message

class HideUnhideView(ui.View):
    def __init__(self, channel, author, ctx):
        super().__init__(timeout=120)
        self.channel = channel
        self.author = author
        self.ctx = ctx  
        self.message = None  

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user != self.author:
            await interaction.response.send_message("You are not allowed to interact with this!", ephemeral=True)
            return False
        return True

    async def on_timeout(self):
        await sync_panel_message(self, skip_labels=("Delete",))

    @ui.button(label="Hide", style=discord.ButtonStyle.danger)
    async def hide(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self.channel.set_permissions(interaction.guild.default_role, read_messages=False)
        await interaction.response.send_message(f"{self.channel.mention} has been hidden.", ephemeral=True)

        embed = discord.Embed(
            description=f" **Channel**: {self.channel.mention}\n **Status**: Hidden\n**Reason:** Hide request by {self.author}",
            color=0x000000
        )
        embed.add_field(name=" **Moderator:**", value=self.ctx.author.mention, inline=False)
        embed.set_author(name=f"Successfully Hidden {self.channel.name}")
        await self.message.edit(view = embed_to_view(embed, view = self))

        await sync_panel_message(self, skip_labels=("Delete",))

    @ui.button(style=discord.ButtonStyle.gray, emoji=f"{emojis.DELETE}")
    async def delete(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.message.delete()


class Unhide(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.color = discord.Color.from_rgb(0, 0, 0)

    @commands.hybrid_command(
        name="unhide",
        help="Unhides a channel to allow the default role (@everyone) to read messages.",
        usage="unhide <channel>",
        aliases=["unhidechannel"])
    @commands.has_permissions(manage_roles=True)
    @bot_has_permissions(manage_roles=True)
    async def unhide_command(self, ctx, channel: discord.TextChannel = None):
        channel = channel or ctx.channel 
        if channel.permissions_for(ctx.guild.default_role).read_messages:
            embed = discord.Embed(
                description=f"** Channel**: {channel.mention}\n **Status**: Already Unhidden",
                color=self.color
            )
            embed.set_author(name=f"{channel.name} is Already Unhidden")
            embed.set_footer(text=f"Requested by {ctx.author}", icon_url=ctx.author.avatar.url)
            view = HideUnhideView(channel=channel, author=ctx.author, ctx=ctx)  
            message = await ctx.send(view = embed_to_view(embed, view = view))
            view.message = message
            return

        await channel.set_permissions(ctx.guild.default_role, read_messages=True)

        embed = discord.Embed(
            description=f" **Channel**: {channel.mention}\n< **Status**: Unhidden\n **Reason:** Unhide request by {ctx.author}",
            color=self.color
        )
        embed.add_field(name=" **Moderator:**", value=ctx.author.mention, inline=False)
        embed.set_author(name=f"Successfully Unhidden {channel.name}")
        embed.set_footer(text=f"Requested by {ctx.author}", icon_url=ctx.author.avatar.url)
        view = HideUnhideView(channel=channel, author=ctx.author, ctx=ctx)  
        message = await ctx.send(view = embed_to_view(embed, view = view))
        view.message = message




