import re
import sys

file_path = r'c:\Users\vaish\OneDrive\Desktop\Codes\Kyrox\cogs\commands\music.py'
with open(file_path, 'r', encoding='utf-8') as f:
    content = f.read()

# Add import if missing
if "from utils import emojis" not in content:
    content = content.replace("from discord.ext import commands\n", "from discord.ext import commands\nfrom utils import emojis\n")

# Replace emoji kwarg in discord.ui.Button
replacements_kwargs = {
    'emoji="⏮"': 'emoji=emojis.get("rewind1")',
    'emoji="⏭"': 'emoji=emojis.get("skip")',
    'emoji="⏸"': 'emoji=emojis.get("icons_pause")',
    'emoji="▶"': 'emoji=emojis.get("icons_next")',
    'emoji="⏹"': 'emoji=emojis.get("musicstop_icons")',
    'emoji="🔁"': 'emoji=emojis.get("shuffle")',
    'emoji="🔂"': 'emoji=emojis.get("shuffle")',
    'emoji="🎛"': 'emoji=emojis.get("Gear")',
    'emoji="♾️"': 'emoji=emojis.get("shuffle")',
    'emoji="🔴"': 'emoji=emojis.get("red_dot")',
    'emoji="🟢"': 'emoji=emojis.get("enabled")',
}

for k, v in replacements_kwargs.items():
    content = content.replace(k, v)

# Replace inline string emojis
# We will use f-strings where possible, or just string concatenation.
# Since these are inside strings, we will replace the whole string with an f-string if it has variables,
# or add f if it doesn't.
def make_fstring(match):
    prefix = match.group(1)
    text = match.group(2)
    # If not already an f-string, make it one
    if not prefix.endswith('f'):
        prefix += 'f'
    # Replace icons
    text = text.replace('<:warning:1448951779353038949>', '{emojis.get("Warning")}')
    text = text.replace('❌', '{emojis.get("CrossIcon")}')
    text = text.replace('🔎', '{emojis.get("info")}')
    text = text.replace('🎛️', '{emojis.get("Gear")}')
    text = text.replace('🎚️', '{emojis.get("filder")}')
    text = text.replace('⚠️', '{emojis.get("Warning")}')
    text = text.replace('🔴', '{emojis.get("red_dot")}')
    text = text.replace('🟢', '{emojis.get("enabled")}')
    text = text.replace('♾️', '{emojis.get("shuffle")}')
    text = text.replace('🔂', '{emojis.get("shuffle")}')
    text = text.replace('🔁', '{emojis.get("shuffle")}')
    text = text.replace('⏸️', '{emojis.get("icons_pause")}')
    text = text.replace('▶️', '{emojis.get("icons_next")}')
    text = text.replace('⏹️', '{emojis.get("musicstop_icons")}')
    text = text.replace('⏭️', '{emojis.get("skip")}')
    text = text.replace('⏮️', '{emojis.get("rewind1")}')
    return f'{prefix}"{text}"'

# We find all double quoted strings containing specific emojis
pattern = r'([rfb]*)(".*?<:warning:1448951779353038949>.*?|.*?❌.*?|.*?🔎.*?|.*?🎛️.*?|.*?🎚️.*?|.*?⚠️.*?|.*?🔴.*?|.*?🟢.*?)'
# Actually, safer to just find all strings and conditionally replace
def string_replacer(match):
    s = match.group(0)
    has_emoji = any(x in s for x in ['<:warning:1448951779353038949>', '❌', '🔎', '🎛️', '🎚️', '⚠️', '🔴', '🟢', '♾️', '🔂', '🔁', '⏸️', '▶️', '⏹️', '⏭️', '⏮️'])
    if not has_emoji:
        return s
    
    quote = s[0]
    is_fstring = False
    inner = s
    if s.startswith('f"'):
        is_fstring = True
        inner = s[2:-1]
        quote = '"'
    elif s.startswith('"'):
        inner = s[1:-1]
        quote = '"'
    elif s.startswith("f'"):
        is_fstring = True
        inner = s[2:-1]
        quote = "'"
    elif s.startswith("'"):
        inner = s[1:-1]
        quote = "'"
        
    inner = inner.replace('<:warning:1448951779353038949>', '{emojis.get("Warning")}')
    inner = inner.replace('❌', '{emojis.get("CrossIcon")}')
    inner = inner.replace('🔎', '{emojis.get("info")}')
    inner = inner.replace('🎛️', '{emojis.get("Gear")}')
    inner = inner.replace('🎚️', '{emojis.get("filder")}')
    inner = inner.replace('⚠️', '{emojis.get("Warning")}')
    inner = inner.replace('🔴', '{emojis.get("red_dot")}')
    inner = inner.replace('🟢', '{emojis.get("enabled")}')
    inner = inner.replace('♾️', '{emojis.get("shuffle")}')
    inner = inner.replace('🔂', '{emojis.get("shuffle")}')
    inner = inner.replace('🔁', '{emojis.get("shuffle")}')
    inner = inner.replace('⏸️', '{emojis.get("icons_pause")}')
    inner = inner.replace('▶️', '{emojis.get("icons_next")}')
    inner = inner.replace('⏹️', '{emojis.get("musicstop_icons")}')
    inner = inner.replace('⏭️', '{emojis.get("skip")}')
    inner = inner.replace('⏮️', '{emojis.get("rewind1")}')
    
    return f'f{quote}{inner}{quote}'

# Use re to sub strings
content = re.sub(r'f?"(?:[^"\\]|\\.)*"', string_replacer, content)
content = re.sub(r"f?'(?:[^'\\]|\\.)*'", string_replacer, content)

# Wait, the MessageContainerView args in the file are mostly raw strings, this script will make them f-strings safely.

# For standalone single characters not matching above due to stripped variant:
content = content.replace('emoji="⏸️"', 'emoji=emojis.get("icons_pause")')
content = content.replace('emoji="▶️"', 'emoji=emojis.get("icons_next")')

with open(file_path, 'w', encoding='utf-8') as f:
    f.write(content)
print("Emojis replaced.")
