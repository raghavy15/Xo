﻿"""Rebrand Axon/Olympus identifiers to Kyrox across the codebase."""
from __future__ import annotations

import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SKIP_DIRS = {"__pycache__", ".git", "games", "terminals"}
TEXT_EXTENSIONS = {".py", ".md", ".sh", ".yml", ".json", ".txt"}

REPLACEMENTS = [
    ("from core.axon import axon", "from core.Kyrox import Kyrox"),
    ("from core import axon", "from core import Kyrox"),
    ("from core import Cog, axon, Context", "from core import Cog, Kyrox, Context"),
    ("Cog, axon, Context", "Cog, Kyrox, Context"),
    ("import axon, Cog", "import Kyrox, Cog"),
    ("axon, Cog", "Kyrox, Cog"),
    (": axon)", ": Kyrox)"),
    (": axon:", ": Kyrox:"),
    ("(bot: axon)", "(bot: Kyrox)"),
    ("(client: axon)", "(client: Kyrox)"),
    ("client = axon()", "client = Kyrox()"),
    ("bot = axon()", "bot = Kyrox()"),
    ("async def setup(bot: axon)", "async def setup(bot: Kyrox)"),
    ("from .axon.", "from .Kyrox."),
    ("cogs/axon", "cogs/Kyrox"),
    ("core.axon", "core.Kyrox"),
    ("class axon(", "class Kyrox("),

    ("_axon_neutral_policy", "_rem_neutral_policy"),
    ("Axon X", "Kyrox"),
    ("Olympus", "Kyrox"),
    ("olympus", "Kyrox"),
    ("modified version of Kyrox. Original project lineage includes Kyrox and Kyrox bot components", "Kyrox"),
]


def rebrand_file(path: Path) -> bool:
    if path.name == "rebrand_to_rem.py":
        return False
    if "words.txt" in str(path):
        return False

    try:
        text = path.read_text(encoding="utf-8")
    except UnicodeDecodeError:
        return False

    original = text
    for old, new in REPLACEMENTS:
        text = text.replace(old, new)

    if text == original:
        return False

    path.write_text(text, encoding="utf-8")
    print(f"rebranded: {path.relative_to(ROOT)}")
    return True


def main() -> None:
    count = 0
    for path in ROOT.rglob("*"):
        if not path.is_file():
            continue
        if path.suffix not in TEXT_EXTENSIONS:
            continue
        if any(part in SKIP_DIRS for part in path.parts):
            continue
        if rebrand_file(path):
            count += 1
    print(f"done â€” rebranded {count} files")


if __name__ == "__main__":
    main()
