import re
import sys

file_path = r'c:\Users\vaish\OneDrive\Desktop\Codes\Kyrox\cogs\commands\music.py'

with open(file_path, 'r', encoding='utf-8') as f:
    content = f.read()

# Replace MessageContainerView calls
# e.g. ctx.send(view=MessageContainerView("<:warning:1448951779353038949> No song is currently playing.", accent_color=0xFF9E9E))
# with ctx.send(view=music_toast("No song is currently playing.", "error"))

# Add imports for utils.music_panel
import_statement = """
from utils.music_panel import (
    guard_empty_queue, guard_no_results, guard_no_voice, guard_not_connected, guard_not_playing, guard_same_channel,
    inactivity_embed, kawaii_queue_page_source, lavalink_offline_embed, music_toast, now_playing_embed,
    platform_select_embed, player_embed, player_layout_view, queue_ended_embed, queue_entry_line, search_results_embed,
    track_added_embed, NowPlayingView
)
"""

if "utils.music_panel" not in content:
    content = content.replace("from lavalink.server import LoadType\n", f"from lavalink.server import LoadType\n{import_statement}")


# Redefine build_now_playing_view to use NowPlayingView
build_now_playing_replacement = """
async def build_now_playing_view(player, track, guild, client) -> tuple[discord.ui.LayoutView, discord.File]:
    requester_id = getattr(track, "requester", 0)
    requester = guild.get_member(int(requester_id)) if requester_id else None
    
    class DummyCtx:
        def __init__(self):
            self.guild = guild
            self.bot = client
            class Author:
                def __init__(self):
                    self.id = requester_id
                    self.name = requester.name if requester else "Unknown"
                    self.display_name = requester.display_name if requester else "Unknown"
            self.author = Author()

    source = (getattr(track, "source_name", "unknown") or "unknown").lower()
    
    view = NowPlayingView(
        track,
        player,
        DummyCtx(),
        source_name=source,
        requested_by=f"[{DummyCtx().author.name}](https://discord.com/users/{requester_id})",
        autoplay=False,
        queue_length=len(player.queue)
    )
    return view, None
"""

content = re.sub(
    r'async def build_now_playing_view\(.*?\).*?row1\.add_item\(AutoplayButton\(guild\.id\)\)\n\n    return view, file',
    build_now_playing_replacement.strip(),
    content,
    flags=re.DOTALL
)

# Fix play command enqueued embeds
content = re.sub(
    r'view = build_enqueued_view\((.*?), (.*?), (.*?)\)\n\s*await (ctx|interaction)\.send\(view=view\)',
    r'await \4.send(embed=track_added_embed(\1, requested_by=\2.display_name, queue_length=len(player.queue)))',
    content
)

content = re.sub(
    r'view = build_playlist_enqueued_view\((.*?)\)\n\s*await (ctx|interaction)\.send\(view=view\)',
    r'await \2.send(view=music_toast("Playlist added!", "success"))',
    content
)

# Convert MessageContainerView to music_toast wrapper dynamically inside the file.
msg_container_redef = """
def MessageContainerView(text, accent_color=0x5865F2, title=None, thumbnail=None, buttons=None, timeout=60.0):
    tone = "error" if accent_color == 0xFF9E9E else "info"
    if title:
        text = f"**{title}**\\n{text}"
    return music_toast(text, tone)
"""

# Replace the class definition with the function wrapper
content = re.sub(
    r'class MessageContainerView\(discord\.ui\.LayoutView\):.*?def __init__\(.*?\):.*?super\(\)\.__init__\(timeout=timeout\).*?self\.add_section\(\*\*container_ns\)',
    msg_container_redef.strip(),
    content,
    flags=re.DOTALL
)


with open(file_path, 'w', encoding='utf-8') as f:
    f.write(content)
print("Regex replacements applied!")
