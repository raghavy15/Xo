﻿import re

file_path = r'c:\Users\vaish\OneDrive\Desktop\Codes\Kyrox\cogs\commands\music.py'
with open(file_path, 'r', encoding='utf-8') as f:
    content = f.read()

def replace_mcv(match):
    text = match.group(1)
    args = match.group(2)
    tone = '"info"'
    if '0xFF9E9E' in args:
        tone = '"error"'
    return f'music_toast({text}, tone={tone})'

content = re.sub(r'MessageContainerView\((.*?),\s*(accent_color=.*?)\)', replace_mcv, content, flags=re.DOTALL)
content = re.sub(r'MessageContainerView\((.*?)\)', r'music_toast(\1, tone="info")', content, flags=re.DOTALL)

with open(file_path, 'w', encoding='utf-8') as f:
    f.write(content)
print('Done!')
