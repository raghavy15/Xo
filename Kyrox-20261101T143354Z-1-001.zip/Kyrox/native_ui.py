import re

file_path = r'c:\Users\vaish\OneDrive\Desktop\Codes\Kyrox\cogs\commands\music.py'
with open(file_path, 'r', encoding='utf-8') as f:
    content = f.read()

# Replace MessageContainerView(..., accent_color=...) with music_toast(..., tone=...)
def replace_mcv(match):
    text = match.group(1)
    args = match.group(2)
    tone = '"info"'
    if '0xFF9E9E' in args:
        tone = '"error"'
    return f'music_toast({text}, tone={tone})'

content = re.sub(r'MessageContainerView\((.*?),\s*(accent_color=.*?)\)', replace_mcv, content)
content = re.sub(r'MessageContainerView\((.*?)\)', r'music_toast(\1, tone="info")', content)

# Remove MessageContainerView wrapper definition
content = re.sub(r'def MessageContainerView\(.*?\):.*?return music_toast\(text, tone\)\n', '', content, flags=re.DOTALL)

with open(file_path, 'w', encoding='utf-8') as f:
    f.write(content)
print('Native UI replacements complete')
