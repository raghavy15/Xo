import os
import re

MUSIC_FILE = r"c:\Users\vaish\OneDrive\Desktop\Codes\Kyrox\cogs\commands\music.py"
OUT_DIR = r"c:\Users\vaish\OneDrive\Desktop\Codes\Kyrox\cogs\commands\Music"

if not os.path.exists(OUT_DIR):
    os.makedirs(OUT_DIR)

with open(MUSIC_FILE, 'r', encoding='utf-8') as f:
    content = f.read()

# Base imports for each command file
IMPORTS = """import random
import discord
from discord.ext import commands
from typing import Optional
import asyncio

from utils import emojis
from utils.music_panel import (
    music_toast, track_added_embed, MessageContainerView
)
from utils.music_utils import blacklist_check, ignore_check

import lavalink
from lavalink.server import LoadType

from helpers.lavalink_client import LavalinkVoiceClient, get_state

from .utils import (
    get_player, get_active_filters, set_active_filters, MusicFiltersHelper,
    PlatformSelectView, ContainerPaginator, build_lyrics_panel, sync_lyrics_loop
)

"""

# Regex to find commands. We look for `@commands.command` or `@commands.hybrid_command`
# and capture everything until the next `@commands.` or the end of the class.
# But wait, it's safer to split by `@commands.` and process chunks.
chunks = re.split(r'\n    @commands\.(command|hybrid_command)', content)

# chunks[0] contains everything before the first command. 
# We need to extract the helper methods in the `Music` class from chunks[0].
# The `Music` class starts at `class Music(commands.Cog):`
class_start = chunks[0].find("class Music(commands.Cog):")
helpers_code = chunks[0][class_start:]

# Write the core/events cog which holds the lavalink events and helper tasks
core_cog = IMPORTS + f"""
class MusicEvents(commands.Cog):
{helpers_code}

async def setup(client):
    from helpers.lavalink_client import setup_lavalink
    if not hasattr(client, 'lavalink'):
        await setup_lavalink(client)
    await client.add_cog(MusicEvents(client))
"""

with open(os.path.join(OUT_DIR, "events.py"), 'w', encoding='utf-8') as f:
    f.write(core_cog)

# Process the command chunks
# chunks is: [pre_code, "command", "rest_of_code", "hybrid_command", "rest_of_code", ...]
for i in range(1, len(chunks), 2):
    cmd_type = chunks[i]
    cmd_body = chunks[i+1]
    
    # Extract the command name from the name="..." or def name(
    name_match = re.search(r'name=["\']([^"\']+)["\']', cmd_body)
    if name_match:
        cmd_name = name_match.group(1)
    else:
        def_match = re.search(r'def\s+([a-zA-Z0-9_]+)', cmd_body)
        if def_match:
            cmd_name = def_match.group(1)
        else:
            continue
            
    # Clean up cmd_name for filename (e.g., 247 or 24/7 -> twenty_four_seven)
    filename = cmd_name.replace("/", "").replace("\\", "").lower()
    if filename == "247":
        filename = "twenty_four_seven"
    if filename == "search":
        filename = "search_cmd"
        
    class_name = filename.title().replace("_", "") + "Command"
    
    # Write the command to a file
    cog_code = IMPORTS + f"""
class {class_name}(commands.Cog):
    def __init__(self, client):
        self.client = client
        
    @commands.{cmd_type}{cmd_body}

async def setup(client):
    await client.add_cog({class_name}(client))
"""
    with open(os.path.join(OUT_DIR, f"{filename}.py"), 'w', encoding='utf-8') as f:
        f.write(cog_code)

print("Split complete!")
